/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.ts
// Description: Soluções e Explicações
// ==========================================

// updatePromptConfig.ts (Server Action)
'use server';

import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { db } from '@/lib/db'; // Exemplo de conexão com banco de dados

// 1. Definição do Schema de Validação com Zod
const PromptConfigSchema = z.object({
  model: z.string().min(1, "Modelo é obrigatório"),
  temperature: z.number().min(0.0).max(2.0, "Temperature deve estar entre 0.0 e 2.0"),
  maxTokens: z.number().int().positive().max(4096, "MaxTokens não pode exceder 4096"),
});

// Inferência de tipos automaticamente para uso no frontend
export type PromptConfigInput = z.infer<typeof PromptConfigSchema>;

export async function updatePromptConfig(prevState: any, formData: FormData) {
  // 2. Parsing e validação dos dados
  const validatedFields = PromptConfigSchema.safeParse({
    model: formData.get('model'),
    temperature: parseFloat(formData.get('temperature') as string),
    maxTokens: parseInt(formData.get('maxTokens') as string),
  });

  if (!validatedFields.success) {
    return {
      success: false,
      errors: validatedFields.error.flatten().fieldErrors,
      message: 'Campos inválidos. Verifique os dados inseridos.',
    };
  }

  try {
    // 3. Simulação de persistência no banco de dados
    await db.promptConfig.upsert({
      where: { model: validatedFields.data.model },
      update: {
        temperature: validatedFields.data.temperature,
        maxTokens: validatedFields.data.maxTokens,
      },
      create: validatedFields.data,
    });

    // 4. Revalidação do cache para garantir consistência
    // Invalida o cache da lista de configurações ativas
    revalidatePath('/admin/configurations'); 

    return {
      success: true,
      message: 'Configuração atualizada com sucesso!',
      errors: null,
    };
  } catch (error) {
    return {
      success: false,
      message: 'Erro interno ao salvar a configuração.',
      errors: null,
    };
  }
}
