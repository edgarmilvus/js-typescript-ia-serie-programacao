/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.ts
// Description: Soluções e Explicações
// ==========================================

// functionSchemas.ts
import { z } from 'zod';

// 1. Definição do Schema usando Zod para tipagem forte
const EventSchema = z.object({
  eventName: z.string().describe("Nome do evento"),
  eventDate: z.string().describe("Data do evento no formato ISO 8601 (YYYY-MM-DD)"),
  location: z.string().optional().describe("Local do evento"),
});

// Inferência da interface TypeScript automaticamente
export type EventArguments = z.infer<typeof EventSchema>;

// 2. Definição do Schema para a API da OpenAI (formato JSON Schema)
export const extractEventSchema = {
  name: "extract_event_details",
  description: "Extrai detalhes de um evento de um texto fornecido.",
  parameters: {
    type: "object",
    properties: {
      eventName: { type: "string", description: "Nome do evento" },
      eventDate: { type: "string", description: "Data do evento" },
      location: { type: "string", description: "Local do evento" },
    },
    required: ["eventName", "eventDate"],
  },
};
