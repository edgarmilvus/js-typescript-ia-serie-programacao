/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.ts
// Description: Soluções e Explicações
// ==========================================

// edge/generate-chat-response.ts
import { LangChain } from '@langchain/openai';
import { NextResponse } from 'next/server';

// Configuração específica para o Runtime Edge
export const config = {
  runtime: 'edge',
};

export async function POST(req: Request) {
  try {
    // 1. Parsing da entrada
    const { userPrompt } = await req.json();

    if (!userPrompt) {
      return new NextResponse(JSON.stringify({ error: "Prompt é obrigatório" }), { status: 400 });
    }

    // 2. Inicialização do cliente OpenAI via LangChain
    // Nota: Em Edge Functions, certifique-se de que a chave da API esteja no ambiente (process.env.OPENAI_API_KEY)
    const model = new LangChain({
      modelName: 'gpt-3.5-turbo',
      temperature: 0.7,
      // Apenas modelos 'gpt-3.5-turbo' e 'gpt-4' suportam function calling no momento, 
      // mas para geração simples, funciona bem.
    });

    // 3. Fallback de timeout (5 segundos)
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);

    // 4. Geração da resposta
    // Nota: Para Edge, evitamos chains complexas que dependem de módulos Node.js pesados.
    // Usamos a invocação direta do modelo.
    const response = await model.invoke(userPrompt, { signal: controller.signal });
    
    clearTimeout(timeoutId);

    // Retorno da resposta como texto puro
    return new NextResponse(response, { 
      status: 200,
      headers: { 'Content-Type': 'text/plain' }
    });

  } catch (error: any) {
    // 5. Tratamento de erros e Fallback
    console.error(error);
    
    // Verifica se o erro foi causado pelo abort do controller (timeout)
    if (error.name === 'AbortError' || error.message.includes('timeout')) {
      return new NextResponse(
        JSON.stringify({ error: "O tempo de resposta excedeu o limite. Tente novamente." }), 
        { status: 504 } // Gateway Timeout
      );
    }

    // Fallback genérico para outros erros (ex: API indisponível)
    return new NextResponse(
      JSON.stringify({ error: "Desculpe, ocorreu um erro ao processar sua solicitação." }), 
      { status: 500 }
    );
  }
}
