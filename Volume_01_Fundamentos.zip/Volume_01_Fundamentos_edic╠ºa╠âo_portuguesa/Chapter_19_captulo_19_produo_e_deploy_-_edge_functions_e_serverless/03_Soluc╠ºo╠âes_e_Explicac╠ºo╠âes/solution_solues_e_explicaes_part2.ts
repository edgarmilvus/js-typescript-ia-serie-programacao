/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part2.ts
// Description: Soluções e Explicações
// ==========================================

// PromptConfigForm.tsx (Componente Cliente)
'use client';

import { useFormState, useFormStatus } from 'react-dom';
import { updatePromptConfig, PromptConfigInput } from './updatePromptConfig';

// Componente de botão com estado de carregamento
function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <button type="submit" disabled={pending} className="bg-blue-600 text-white p-2 rounded disabled:opacity-50">
      {pending ? 'Salvando...' : 'Salvar Configuração'}
    </button>
  );
}

export function PromptConfigForm() {
  // Hook para gerenciar estado da Server Action
  const [state, formAction] = useFormState(updatePromptConfig, null);

  return (
    <form action={formAction} className="space-y-4 max-w-md">
      <div>
        <label htmlFor="model">Modelo</label>
        <input name="model" id="model" className="border p-1 w-full text-black" defaultValue="gpt-4" />
      </div>
      
      <div>
        <label htmlFor="temperature">Temperature</label>
        <input name="temperature" id="temperature" type="number" step="0.1" className="border p-1 w-full text-black" defaultValue="0.7" />
        {state?.errors?.temperature && <p className="text-red-500 text-sm">{state.errors.temperature}</p>}
      </div>

      <div>
        <label htmlFor="maxTokens">Max Tokens</label>
        <input name="maxTokens" id="maxTokens" type="number" className="border p-1 w-full text-black" defaultValue="2048" />
        {state?.errors?.maxTokens && <p className="text-red-500 text-sm">{state.errors.maxTokens}</p>}
      </div>

      <SubmitButton />
      
      {state?.message && (
        <p className={state.success ? "text-green-600" : "text-red-600"}>
          {state.message}
        </p>
      )}
    </form>
  );
}
