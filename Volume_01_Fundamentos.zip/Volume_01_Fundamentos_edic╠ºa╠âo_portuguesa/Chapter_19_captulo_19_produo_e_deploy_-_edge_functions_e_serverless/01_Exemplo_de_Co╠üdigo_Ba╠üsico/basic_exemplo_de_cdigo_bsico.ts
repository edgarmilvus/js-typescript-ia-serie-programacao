/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.ts
// Description: Exemplo de Código Básico
// ==========================================

// Arquivo: src/app/api/generate/route.ts
// Contexto: Edge Function para geração de texto via LangChain.js
// Runtime: Vercel Edge (ou equivalente)

import { NextRequest, NextResponse } from 'next/server'; // Framework Next.js para manipulação de requisições
import { ChatOpenAI } from '@langchain/openai'; // Integração com a OpenAI API
import { PromptTemplate } from '@langchain/core/prompts'; // Template de prompt para o LLM

/**
 * @description Configuração da Edge Function.
 * Define o runtime como 'edge' para otimizar latência e custo.
 * @type {import('next/server').EdgeRuntime}
 */
export const runtime = 'edge';

/**
 * @description Função principal da Edge Function.
 * Aceita requisições POST, valida o input e gera uma resposta usando LangChain.
 * @param {NextRequest} req - Objeto de requisição HTTP (padrão Next.js/Edge).
 * @returns {Promise<NextResponse>} Resposta JSON com o conteúdo gerado ou erro.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  // 1. Parsing do corpo da requisição (JSON).
  // O Edge Runtime não suporta `req.json()` nativamente de forma síncrona, usamos `req.text()` e `JSON.parse`.
  // Por baixo do capô: Isso evita buffering pesado, ideal para streams leves.
  const bodyText = await req.text();
  let input: { topic?: string };

  try {
    input = JSON.parse(bodyText);
  } catch (error) {
    // Tratamento de erro: JSON malformado retorna 400 imediatamente.
    // Evita consumo desnecessário de recursos da Edge Function (V8 Isolate).
    return NextResponse.json(
      { error: 'Corpo da requisição deve ser um JSON válido.' },
      { status: 400 }
    );
  }

  // 2. Validação de Input.
  // Garantimos que o campo 'topic' exista e não esteja vazio.
  // Isso previne "Hallucinations" ou erros de API se o prompt for vazio.
  if (!input.topic || typeof input.topic !== 'string' || input.topic.trim() === '') {
    return NextResponse.json(
      { error: 'O campo "topic" é obrigatório e deve ser uma string não vazia.' },
      { status: 400 }
    );
  }

  // 3. Inicialização do LLM (Large Language Model).
  // Usamos ChatOpenAI com modelo 'gpt-3.5-turbo' para baixa latência.
  // Nota: No Edge, a API Key deve vir de variáveis de ambiente (process.env.OPENAI_API_KEY).
  // O modelo é instanciado com 'maxTokens' baixo para controle de custo em produção.
  const model = new ChatOpenAI({
    model: 'gpt-3.5-turbo',
    temperature: 0.7, // Criatividade moderada
    maxTokens: 100,   // Limite de saída para evitar timeouts e custos altos
    streaming: false  // Desativado para simplicidade; em produção, ative para streaming de resposta
  });

  // 4. Definição do Prompt Template.
  // LangChain permite criar prompts reutilizáveis com variáveis (input.topic).
  // Isso separa a lógica de negócio do conteúdo do prompt.
  const prompt = PromptTemplate.fromTemplate(
    'Você é um assistente de IA conciso. Gere uma introdução de 2 frases sobre o tópico: {topic}.'
  );

  // 5. Cadeia de Execução (Chain).
  // Combinamos o prompt e o modelo. No LangChain, isso cria uma "RunnableSequence".
  // Por baixo do capô: O input é formatado, enviado para a API OpenAI, e a resposta é parseada.
  const chain = prompt.pipe(model);

  try {
    // 6. Invocação da IA.
    // Chamada assíncrona à OpenAI. No Edge Runtime, isso é executado em um Isolate leve.
    // O Vercel Edge Functions possuem um timeout padrão de 10s (configurável até 30s).
    const response = await chain.invoke({ topic: input.topic });

    // 7. Extração e Retorno da Resposta.
    // O output do LLM é um objeto AIMessage. Extraímos o conteúdo (texto).
    const generatedText = response.content;

    return NextResponse.json(
      { 
        topic: input.topic,
        result: generatedText 
      },
      { status: 200 }
    );
  } catch (error) {
    // 8. Tratamento de Erros de API.
    // Se a OpenAI falhar (ex: rate limit, API Key inválida), retorna 500.
    // Em produção, logue o erro (console.error) antes de retornar.
    console.error('Erro na geração de texto:', error);
    return NextResponse.json(
      { error: 'Falha ao gerar resposta da IA. Tente novamente.' },
      { status: 500 }
    );
  }
}
