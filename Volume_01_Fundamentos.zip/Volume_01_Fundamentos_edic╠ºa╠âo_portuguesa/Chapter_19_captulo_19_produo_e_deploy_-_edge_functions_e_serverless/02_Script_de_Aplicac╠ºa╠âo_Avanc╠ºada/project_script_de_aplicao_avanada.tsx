/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.tsx
// Description: Script de Aplicação Avançada
// ==========================================

// app/api/generate/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { ChatOpenAI } from '@langchain/openai';
import { AIMessageChunk } from '@langchain/core/messages';

// ---------------------------------------------------------------------
// 1. Configuração do Runtime e do Modelo
// ---------------------------------------------------------------------
// Definimos explicitamente o runtime como 'edge' para aproveitar a infraestrutura
// distribuída da borda (Vercel Edge, Cloudflare Workers, etc.).
// Isso reduz a latência ao executar a lógica próximo ao usuário final.
export const runtime = 'edge';

/**
 * Inicializa o modelo LLM (Large Language Model) com parâmetros otimizados para produção.
 * 
 * 'temperature': Controla a aleatoriedade. 0.2 é ideal para tarefas de geração
 * de texto factual ou respostas consistentes em um SaaS.
 * 'model': Especificamos uma versão otimizada para custo/performance (ex: gpt-3.5-turbo-0125).
 */
const llm = new ChatOpenAI({
  model: 'gpt-3.5-turbo-0125',
  temperature: 0.2,
  maxTokens: 500, // Limite de segurança para evitar custos excessivos em uma Edge Function
});

// ---------------------------------------------------------------------
// 2. Lógica da API Route (Serverless/Edge)
// ---------------------------------------------------------------------
/**
 * Manipula a requisição POST para gerar texto via streaming.
 * 
 * @param {NextRequest} req - A requisição HTTP entrante contendo o payload JSON.
 * @returns {Response} - Um objeto Response com um ReadableStream para o streaming de dados.
 */
export async function POST(req: NextRequest) {
  try {
    // Parse do corpo da requisição
    const { prompt } = await req.json();

    if (!prompt || typeof prompt !== 'string') {
      return new NextResponse(
        JSON.stringify({ error: 'Prompt é obrigatório e deve ser uma string.' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    // -----------------------------------------------------------------
    // 3. Integração com LangChain e Streaming
    // -----------------------------------------------------------------
    // O método .stream() do LangChain retorna um AsyncIterable.
    // Para compatibilidade com a API de Streams da Web (Web Streams API)
    // usada nas Edge Functions, convertemos este iterável em um ReadableStream.
    const stream = await llm.stream(prompt);

    // -----------------------------------------------------------------
    // 4. Criação do ReadableStream (Web Streams API)
    // -----------------------------------------------------------------
    // Este é o padrão para Edge Functions: retornar um Response com um stream.
    const readableStream = new ReadableStream({
      async start(controller) {
        try {
          // Iteramos sobre os chunks do modelo
          for await (const chunk of stream) {
            // 'chunk' é uma instância de AIMessageChunk
            // Usamos .content para acessar o texto gerado
            const content = (chunk as AIMessageChunk).content;
            
            // Codificamos o texto para bytes e enqueue no controller
            const encoder = new TextEncoder();
            const encodedContent = encoder.encode(content);
            controller.enqueue(encodedContent);
          }
          // Fecha o stream quando a geração termina
          controller.close();
        } catch (error) {
          // Em ambientes de borda, é crucial fechar o stream em caso de erro
          // para evitar conexões pendentes.
          controller.error(error);
        }
      },
    });

    // -----------------------------------------------------------------
    // 5. Retorno da Resposta
    // -----------------------------------------------------------------
    // Retornamos o stream diretamente. O cabeçalho 'Content-Type: text/plain; charset=utf-8'
    // informa ao cliente que estamos enviando texto fluxo contínuo.
    return new Response(readableStream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        // Cache-Control opcional: 'no-store' garante que cada requisição gere nova resposta
        'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
      },
    });

  } catch (error) {
    // Tratamento de erro robusto para ambientes Serverless
    console.error('Erro na Edge Function:', error);
    return new NextResponse(
      JSON.stringify({ error: 'Erro interno do servidor ao gerar texto.' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}
