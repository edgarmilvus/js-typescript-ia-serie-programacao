/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.ts
// Description: Script de Aplicação Avançada
// ==========================================

// app/api/chat/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { OpenAI } from 'openai';
import { streamText } from 'ai'; // Vercel AI SDK
import { z } from 'zod'; // Validação de schemas para ferramentas

// 1. CONFIGURAÇÃO E INICIALIZAÇÃO
// Inicializamos o cliente OpenAI. Em produção, a chave deve vir de variáveis de ambiente.
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

// 2. DEFINIÇÃO DAS FERRAMENTAS (TOOL CALLING)
// Definimos uma ferramenta que o modelo pode chamar se detectar que o usuário
// quer saber sobre o mercado financeiro. Isso demonstra a integração de lógica externa.
const tools = {
  buscar_cotacao_bolsa: {
    description: 'Busca a cotação atual de uma ação específica na bolsa de valores.',
    parameters: z.object({
      ticker: z.string().describe('O símbolo da ação, ex: AAPL, PETR4'),
    }),
    // A função execute é o código que roda no servidor quando o modelo decide chamar a ferramenta
    execute: async ({ ticker }: { ticker: string }) => {
      // Simulação de uma chamada a uma API externa de dados financeiros
      const precoMock = (Math.random() * 100 + 50).toFixed(2);
      return `A cotação atual de ${ticker} é R$ ${precoMock}.`;
    },
  },
};

/**
 * @description API Route principal que orquestra o fluxo RAG e Tool Calling.
 * @param request - O objeto de requisição HTTP do Next.js.
 * @returns StreamingResponse com a resposta gerada pelo modelo.
 */
export async function POST(request: NextRequest) {
  try {
    // 3. CAPTURA DOS DADOS DA REQUISIÇÃO
    // Em um app real, viria do formulário do cliente (React Hook Form, etc.)
    const { messages, documentContent } = await request.json();

    // 4. MÓDULO RAG: PROCESSAMENTO E RECUPERAÇÃO VETORIAL (SIMULADO)
    /**
     * Nota do Instrutor: Em um ambiente de produção, esta seção seria dividida:
     * 1. Processamento Offline: O documento seria dividido (chunking) e embeddings gerados
     *    armazenados no Pinecone ou ChromaDB.
     * 2. Recuperação Online: A query do usuário seria convertida em embedding e buscada no banco vetorial.
     * 
     * Para este script didêmico, simulamos a geração de embeddings e a similaridade de cosseno
     * para demonstrar a lógica de recuperação de contexto.
     */
    
    // Passo 4.1: Obter o embedding da última mensagem do usuário (a consulta)
    const embeddingResponse = await openai.embeddings.create({
      model: 'text-embedding-ada-002',
      input: messages[messages.length - 1].content,
    });
    const queryVector = embeddingResponse.data[0].embedding;

    // Passo 4.2: Dividir o documento de contexto (Chunking)
    // Divisão simples por parágrafos para simulação
    const chunks = documentContent.split('\n\n').filter((c: string) => c.length > 20);

    // Passo 4.3: Encontrar o trecho mais relevante (Simulação de Similaridade de Cosseno)
    // Calculamos a similaridade entre a query e cada chunk (aproximadamente)
    // Nota: Em produção, use bibliotecas como 'vector-node' ou cálculos matemáticos precisos.
    let retrievedContext = '';
    let maxSimilarity = -1;

    for (const chunk of chunks) {
      // Geração rápida de embedding do chunk (apenas para exemplo)
      const chunkEmbeddingRes = await openai.embeddings.create({
        model: 'text-embedding-ada-002',
        input: chunk,
      });
      const chunkVector = chunkEmbeddingRes.data[0].embedding;
      
      // Cálculo de Similaridade (Produto Escalar / Cosseno)
      // Simplificado para o exemplo
      const similarity = queryVector.reduce((acc, val, i) => acc + val * chunkVector[i], 0);
      
      if (similarity > maxSimilarity) {
        maxSimilarity = similarity;
        retrievedContext = chunk;
      }
    }

    // 5. CONSTRUÇÃO DO PROMPT ENRIQUECIDO (RAG)
    // Instruimos o modelo a usar o contexto recuperado para responder.
    const systemPrompt = `
      Você é um assistente de IA útil e preciso.
      
      CONTEXTO RECUPERADO DO DOCUMENTO DO USUÁRIO:
      "${retrievedContext}"

      INSTRUÇÕES:
      1. Use estritamente o contexto acima para responder à pergunta do usuário.
      2. Se o contexto não contiver a resposta, diga que não sabe baseado nos documentos fornecidos.
      3. Se a pergunta envolver cotações de bolsa de valores ou finanças, chame a ferramenta 'buscar_cotacao_bolsa'.
      4. Mantenha as respostas concisas e claras.
    `;

    // 6. CHAMADA AO MODELO COM TOOL CALLING (Vercel AI SDK)
    // O SDK lida com a lógica de decidir se chama a função ou gera texto diretamente.
    const result = await streamText({
      model: openai.chat('gpt-4-turbo-preview'),
      system: systemPrompt,
      messages: messages, // Histórico de conversa
      tools: tools, // Definição das ferramentas disponíveis
      maxTokens: 500,
    });

    // 7. RETORNO DO STREAMING
    // Retorna a resposta como um stream para o cliente (React Client Component)
    return result.toAIStreamResponse();

  } catch (error) {
    console.error('Erro na API RAG:', error);
    return NextResponse.json(
      { error: 'Falha no processamento da solicitação.' },
      { status: 500 }
    );
  }
}
