/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.ts
// Description: Exemplo de Código Básico
// ==========================================

// app/api/chat/route.ts
import { openai } from '@ai-sdk/openai'; // Importa o provedor OpenAI
import { streamText, tool } from 'ai'; // Importa as funções principais do Vercel AI SDK
import { z } from 'zod'; // Biblioteca de validação de esquema

// Permitimos o streaming de resposta
export const dynamic = 'force-dynamic';

// 1. DEFINIÇÃO DA FERRAMENTA (TOOL)
// Usamos Zod para definir a estrutura dos dados que a ferramenta espera.
// Isso ajuda o modelo a entender quais parâmetros deve extrair da conversa.
const scheduleTool = tool({
  description: 'Agenda uma demonstração de produto para o cliente.',
  parameters: z.object({
    date: z.string().describe('A data da demonstração no formato YYYY-MM-DD'),
    time: z.string().describe('O horário da demonstração (ex: 14:00)'),
    productName: z.string().describe('Nome do produto que será demonstrado').optional(),
  }),
  // A função que será executada quando o modelo decidir chamar esta ferramenta.
  execute: async ({ date, time, productName }) => {
    // Simulação de uma chamada de banco de dados ou API externa
    console.log(`[LOG DO SERVIDOR] Agendando demonstração: ${productName || 'Produto Padrão'} em ${date} às ${time}`);
    
    return {
      success: true,
      message: `Agendamento confirmado para ${date} às ${time}.`,
      bookingId: `BK-${Math.floor(Math.random() * 10000)}`,
    };
  },
});

// 2. ROTA DA API (ENDPOINT)
export async function POST(req: Request) {
  // Extrai as mensagens do corpo da requisição enviada pelo frontend
  const { messages } = await req.json();

  // Configura o fluxo de texto com streaming
  const result = await streamText({
    model: openai('gpt-4o-mini'), // Modelo a ser utilizado
    messages, // Histórico de conversa
    
    // Definição das ferramentas disponíveis para este modelo
    tools: {
      scheduleDemo: scheduleTool,
    },

    // Instrução do sistema para guiar o comportamento do modelo
    system: `
      Você é um assistente de suporte técnico proativo. 
      Seu objetivo é agendar demonstrações de produtos para os clientes.
      Se o usuário expressar interesse em ver uma demonstração, você deve usar a ferramenta 'scheduleDemo'.
      Se os dados estiverem incompletos, pergunte ao usuário pela data e horário antes de chamar a ferramenta.
      Se a ferramenta for executada com sucesso, informe o ID do agendamento ao usuário.
    `,
  });

  // Transforma o resultado em um stream de resposta para o cliente
  return result.toAIStreamResponse();
}
