/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico_part2.tsx
// Description: Exemplo de Código Básico
// ==========================================

// app/components/ChatComponent.tsx
'use client'; // Indica que este é um componente de cliente (Client Component)

import { useChat } from '@ai-sdk/react'; // Hook principal do Vercel AI SDK

export default function ChatComponent() {
  // Hook que gerencia o estado do chat, entrada do usuário e envio de mensagens
  const { messages, input, handleInputChange, handleSubmit, isLoading, error } = useChat({
    api: '/api/chat', // Aponta para nossa rota de backend definida acima
  });

  return (
    <div className="flex flex-col w-full max-w-md mx-auto p-4 border rounded-lg shadow-sm">
      <h2 className="text-xl font-bold mb-4 text-center">Chat com Agendamento</h2>

      {/* Área de Exibição das Mensagens */}
      <div className="flex flex-col gap-3 mb-4 h-80 overflow-y-auto">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`p-3 rounded-lg max-w-[80%] ${
              message.role === 'user'
                ? 'self-end bg-blue-100 text-blue-900'
                : 'self-start bg-gray-100 text-gray-900'
            }`}
          >
            {/* Renderiza o conteúdo da mensagem. 
                Se for uma mensagem de ferramenta (tool), pode ser processada diferentemente, 
                mas o SDK geralmente retorna o resultado da tool na mensagem assistant. */}
            <p className="text-sm whitespace-pre-wrap">
              {message.content || (message.toolInvocations ? '[Função executada com sucesso]' : '')}
            </p>
            
            {/* Exemplo visual simples de quando uma ferramenta é chamada */}
            {message.toolInvocations && (
              <div className="mt-2 p-2 bg-green-100 text-green-800 text-xs rounded border border-green-200">
                <strong>Ferramenta Acionada:</strong> Agendamento
              </div>
            )}
          </div>
        ))}
        
        {/* Indicador de carregamento (piscante) */}
        {isLoading && (
          <div className="self-start p-3 bg-gray-100 rounded-lg animate-pulse">
            <span className="text-sm text-gray-500">Digitando...</span>
          </div>
        )}

        {error && (
          <div className="self-center p-2 text-red-600 text-sm bg-red-50 rounded">
            Erro: {error.message}
          </div>
        )}
      </div>

      {/* Formulário de Entrada */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Ex: Quero agendar uma demo para amanhã às 10h..."
          className="flex-1 p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
          disabled={isLoading} // Desabilita durante o processamento
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Enviar
        </button>
      </form>
    </div>
  );
}
