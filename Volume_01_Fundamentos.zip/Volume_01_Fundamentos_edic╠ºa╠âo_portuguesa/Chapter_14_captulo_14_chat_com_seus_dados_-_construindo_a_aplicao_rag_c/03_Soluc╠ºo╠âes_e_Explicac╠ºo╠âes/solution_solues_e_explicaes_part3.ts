/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.ts
// Description: Soluções e Explicações
// ==========================================

// lib/documentProcessor.ts
import { RecursiveCharacterTextSplitter } from "langchain/text_splitter";

interface ProcessedChunk {
  content: string;
  metadata: {
    source: string;
    chunkIndex: number;
    length: number;
  };
}

/**
 * Processa um documento de texto bruto em chunks otimizados.
 * @param rawText - O texto completo do documento.
 * @param fileName - Nome do arquivo para metadados.
 * @returns Array de chunks processados com metadados.
 */
export async function processDocument(
  rawText: string,
  fileName: string
): Promise<ProcessedChunk[]> {
  // Configuração do splitter: 
  // - chunk_size: 1000 tokens
  // - chunk_overlap: 200 tokens
  const splitter = new RecursiveCharacterTextSplitter({
    chunkSize: 1000,
    chunkOverlap: 200,
    separators: ["\n\n", "\n", " ", ""], // Tenta dividir por parágrafos primeiro
  });

  const docs = await splitter.createDocuments([rawText]);

  // Mapeia os documentos para a estrutura desejada com metadados enriquecidos
  const processedChunks: ProcessedChunk[] = docs.map((doc, index) => ({
    content: doc.pageContent,
    metadata: {
      source: fileName,
      chunkIndex: index,
      length: doc.pageContent.length,
      // Adicionar mais metadados aqui se necessário (ex: extraído do texto)
    },
  }));

  return processedChunks;
}

// Exemplo de uso (simulado):
/*
const fs = require('fs');
const texto = fs.readFileSync('manual_api.txt', 'utf-8');
const chunks = await processDocument(texto, 'manual_api.txt');
// Agora 'chunks' está pronto para ser enviado ao banco vetorial.
*/
