/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.ts
// Description: Soluções e Explicações
// ==========================================

// lib/retrieval.ts (Simulação da SDK do ChromaDB)

// Tipagem para os parâmetros de busca
interface RetrievalQuery {
  embedding: number[];
  filters: string[]; // Ex: ["Segurança", "API"]
  collectionName: string;
}

// Interface simulada do objeto de documento retornado
interface RetrievedDocument {
  content: string;
  metadata: { category: string };
  score: number; // Similaridade de cosseno
}

/**
 * Simula a busca vetorial com filtragem de metadados.
 * Em um cenário real, isso usaria a SDK oficial do Chroma ou Pinecone.
 */
export async function retrieveContext(params: RetrievalQuery): Promise<RetrievedDocument[]> {
  const { embedding, filters, collectionName } = params;

  // 1. Definir a lógica de filtro (WHERE clause)
  // Se filters estiver vazio, retorna todos os documentos.
  // Se tiver itens, aplica lógica OR (qualquer um dos metadados).
  let whereClause: any = null;
  
  if (filters.length > 0) {
    // Exemplo de estrutura para ChromaDB: { "$or": [{ "category": "Segurança" }, { "category": "API" }] }
    whereClause = {
      "$or": filters.map(filter => ({ "category": filter }))
    };
  }

  // 2. Estrutura da Query Vetorial
  // Nota: A API do ChromaDB aceita queryEmbeddings e where simultaneamente.
  const queryRequest = {
    queryEmbeddings: [embedding],
    where: whereClause, // Aplicação do filtro
    nResults: 3, // Top 3
  };

  console.log("Executando query com filtro:", JSON.stringify(queryRequest, null, 2));

  // SIMULAÇÃO DE RETORNO (pois não temos o banco real rodando)
  // Em produção: const collection = await chroma.getCollection({ name: collectionName });
  // const result = await collection.query(queryRequest);
  
  const mockResults: RetrievedDocument[] = [
    {
      content: "A autenticação deve ser feita via OAuth2.",
      metadata: { category: "Segurança" },
      score: 0.92
    },
    {
      content: "O endpoint /auth/login requer o header 'Authorization'.",
      metadata: { category: "API" },
      score: 0.89
    }
  ];

  // Filtragem simulada se o banco não aplicasse o 'where' automaticamente
  // (Apenas para demonstração lógica)
  return mockResults.filter(doc => 
    filters.length === 0 || filters.includes(doc.metadata.category)
  );
}
