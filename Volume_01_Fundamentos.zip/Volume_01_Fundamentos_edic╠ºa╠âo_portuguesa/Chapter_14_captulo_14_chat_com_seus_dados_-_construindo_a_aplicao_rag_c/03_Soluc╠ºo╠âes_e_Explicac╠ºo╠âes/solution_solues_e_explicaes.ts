/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.ts
// Description: Soluções e Explicações
// ==========================================

// pages/api/chat.ts (Backend - API Route)
import { NextRequest } from 'next/server';
import { OpenAIStream, StreamingTextResponse } from 'ai';
import OpenAI from 'openai';
import { ChromaClient } from 'chromadb';

// Inicialização do cliente OpenAI (deve vir de variáveis de ambiente)
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Simulação de cliente ChromaDB para o exercício
const chroma = new ChromaClient({ path: "http://localhost:8000" });

export async function POST(req: NextRequest) {
  try {
    const { messages, fileContent } = await req.json();
    const userMessage = messages[messages.length - 1].content;

    // 1. (Simplificado) Se houver fileContent, processar e indexar seria aqui.
    // Para este exercício, assumimos que os dados já estão indexados.

    // 2. Recuperar contexto vetorial
    const embedding = await openai.embeddings.create({
      model: "text-embedding-ada-002",
      input: userMessage,
    });

    const collection = await chroma.getCollection({ name: "meus-documentos" });
    
    // Busca vetorial no ChromaDB
    const result = await collection.query({
      queryEmbeddings: [embedding.data[0].embedding],
      nResults: 3,
    });

    const context = result.documents[0].map((doc: any) => doc).join("\n\n---\n\n");

    // 3. Construir Prompt
    const systemPrompt = `
      Você é um assistente técnico especializado.
      Responda exclusivamente com base no contexto fornecido abaixo.
      Se a resposta não estiver no contexto, diga "Não tenho informações sobre isso nos documentos fornecidos".
      
      Contexto:
      ${context}
    `;

    // 4. Gerar Resposta via Stream
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: systemPrompt },
        ...messages // Inclui histórico
      ],
      stream: true,
    });

    // Transforma o stream da OpenAI em um stream de resposta HTTP
    const stream = OpenAIStream(response);
    return new StreamingTextResponse(stream);

  } catch (error) {
    console.error(error);
    return new Response("Erro ao processar a solicitação", { status: 500 });
  }
}
