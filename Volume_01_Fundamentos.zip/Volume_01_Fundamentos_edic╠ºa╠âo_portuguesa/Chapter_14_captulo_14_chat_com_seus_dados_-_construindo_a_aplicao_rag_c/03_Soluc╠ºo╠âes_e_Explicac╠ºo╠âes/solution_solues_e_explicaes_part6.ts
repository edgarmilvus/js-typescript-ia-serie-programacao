/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part6.ts
// Description: Soluções e Explicações
// ==========================================

// actions/feedback.ts (Server Actions)
"use server";

import { revalidatePath } from "next/cache";

// Simulação de banco de dados em memória
// Em produção, isso seria uma query para o Prisma/PostgreSQL
const feedbackLog: Array<{
  messageId: string;
  rating: boolean; // true = like, false = dislike
  contextUsed: string;
  timestamp: Date;
}> = [];

/**
 * Server Action para submeter feedback do usuário sobre uma resposta do chat.
 * @param messageId - ID da mensagem assistente.
 * @param rating - Avaliação (true para positivo, false para negativo).
 * @param contextUsed - O contexto vetorial que gerou a resposta (para análise).
 */
export async function submitFeedback(
  messageId: string,
  rating: boolean,
  contextUsed: string
) {
  try {
    // 1. Validação Básica
    if (!messageId || typeof rating !== 'boolean') {
      throw new Error("Dados de feedback inválidos.");
    }

    // 2. Simulação de Armazenamento Seguro
    // Em um cenário real, aqui haveria verificação de autenticação do usuário
    // para evitar spam (ex: validar session do NextAuth).
    const newEntry = {
      messageId,
      rating,
      contextUsed,
      timestamp: new Date(),
    };

    feedbackLog.push(newEntry);
    
    console.log("Feedback recebido e armazenado:", newEntry);
    console.log("Taxa de aprovação atual:", calculateApprovalRate());

    // 3. Invalidar cache se necessário (ex: para atualizar dashboard de stats)
    revalidatePath('/dashboard');

    return { success: true, message: "Feedback registrado." };
  } catch (error) {
    console.error("Erro ao registrar feedback:", error);
    return { success: false, message: "Falha ao registrar feedback." };
  }
}

// Função auxiliar para cálculo simulado
function calculateApprovalRate() {
  if (feedbackLog.length === 0) return "0%";
  const likes = feedbackLog.filter(f => f.rating).length;
  return `${((likes / feedbackLog.length) * 100).toFixed(1)}%`;
}
