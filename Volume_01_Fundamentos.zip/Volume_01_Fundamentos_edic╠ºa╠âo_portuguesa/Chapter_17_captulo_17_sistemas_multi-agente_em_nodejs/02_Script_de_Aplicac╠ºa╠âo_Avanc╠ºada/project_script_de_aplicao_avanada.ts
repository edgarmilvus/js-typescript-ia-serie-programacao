/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.ts
// Description: Script de Aplicação Avançada
// ==========================================

// app/api/chat/support/route.ts
// Importações necessárias para a construção do sistema multi-agente
import { ChatOpenAI } from "@langchain/openai";
import { ChatPromptTemplate, MessagesPlaceholder } from "@langchain/core/prompts";
import { StateGraph, END, MessageGraph } from "@langchain/langgraph";
import { ToolNode } from "@langchain/langgraph/prebuilt";
import { ToolMessage } from "@langchain/core/messages";
import { z } from "zod";

/**
 * PASSO 1: DEFINIÇÃO DE FERRAMENTAS (TOOLS)
 * 
 * Cada agente precisa de capacidades específicas. Aqui simulamos ferramentas
 * que interagiriam com bancos de dados ou APIs externas (ex: Stripe, Jira).
 * Em um app real, essas funções fariam requisições HTTP.
 */

// Ferramenta 1: Verifica diagnóstico técnico
const diagnosticTool = async ({ problema }: { problema: string }) => {
  console.log(`[Ferramenta Diagnóstico] Analisando: ${problema}`);
  // Simulação de busca em base de conhecimento
  if (problema.includes("lentidão")) {
    return JSON.stringify({ solucao: "Limpar cache do navegador e verificar latência da API." });
  }
  return JSON.stringify({ solucao: "Reiniciar aplicação." });
};

// Ferramenta 2: Verifica status de faturamento
const billingTool = async ({ email }: { email: string }) => {
  console.log(`[Ferramenta Faturamento] Consultando conta: ${email}`);
  // Simulação de chamada a API de pagamentos
  return JSON.stringify({ status: "Ativo", metodo: "Cartão de crédito terminado em 4242" });
};

// Ferramenta 3: Cria ticket de escalonamento
const escalatorTool = async ({ detalhes }: { detalhes: string }) => {
  console.log(`[Ferramenta Escalonamento] Criando ticket: ${detalhes}`);
  // Simulação de criação de tarefa no Jira/Trello
  return JSON.stringify({ ticketId: "SUP-2024-889", status: "Aberto" });
};

/**
 * PASSO 2: AGENTES ESPECIALISTAS
 * 
 * Definimos agentes que usam o LLM para decidir qual ferramenta usar
 * baseado na entrada recebida do supervisor.
 */

const createAgent = (role: string, tools: any[]) => {
  const model = new ChatOpenAI({ model: "gpt-3.5-turbo", temperature: 0 });
  
  // Prompt específico para cada agente
  const prompt = ChatPromptTemplate.fromMessages([
    ["system", `Você é um agente especialista em: ${role}. Responda de forma objetiva e técnica.`],
    new MessagesPlaceholder("messages"),
  ]);

  // Bind das ferramentas ao modelo
  const boundModel = model.bindTools(tools);

  // Função do agente: recebe estado, formata prompt e invoca modelo
  const agentNode = async (state: any) => {
    const response = await prompt.invoke(state.messages);
    const result = await boundModel.invoke(response);
    return { messages: [result] };
  };

  return agentNode;
};

// Instancia os agentes com suas respectivas ferramentas
const analystAgent = createAgent("Diagnóstico Técnico", [
  { name: "diagnosticar_problema", schema: z.object({ problema: z.string() }), func: diagnosticTool }
]);

const billingAgent = createAgent("Faturamento", [
  { name: "verificar_conta", schema: z.object({ email: z.string() }), func: billingTool }
]);

const escalatorAgent = createAgent("Escalonamento", [
  { name: "criar_ticket", schema: z.object({ detalhes: z.string() }), func: escalatorTool }
]);

/**
 * PASSO 3: SUPERVISOR (ROTEADOR)
 * 
 * O cérebro do sistema. Decide para qual agente a mensagem deve ir ou se o fluxo deve terminar.
 * Ele não executa tarefas, apenas redireciona o tráfego.
 */
const createSupervisor = () => {
  const model = new ChatOpenAI({ model: "gpt-3.5-turbo", temperature: 0 });
  
  const systemPrompt = `
    Você é um supervisor de equipe de suporte. Você recebe uma consulta do cliente e deve direcioná-la para o agente correto.
    Agentes disponíveis: 
    1. analyst (problemas técnicos, erros de software)
    2. billing (pagamentos, assinaturas)
    3. escalator (problemas complexos que precisam de ticket humano)
    4. ${END} (se o problema foi resolvido ou é irrelevante)

    Responda apenas com o nome do próximo agente (analyst, billing, escalator ou ${END}).
    `;

  const prompt = ChatPromptTemplate.fromMessages([
    ["system", systemPrompt],
    new MessagesPlaceholder("messages"),
  ]);

  const supervisorNode = async (state: any) => {
    const response = await prompt.invoke(state);
    const result = await model.invoke(response);
    // O LLM retorna o nome do destino, retornamos como string
    return { next: result.content as string };
  };

  return supervisorNode;
};

const supervisor = createSupervisor();

/**
 * PASSO 4: CONSTRUÇÃO DO GRAFO DE ESTADO (LANGGRAPH)
 * 
 * Montamos o grafo que define as conexões entre os nós.
 */
const workflow = new StateGraph({
  channels: {
    messages: { 
      value: (x: any[], y: any) => (y ? x.concat(y) : x), 
      default: () => [] 
    },
    next: { value: (x: string, y?: string) => y ?? x, default: () => "" }
  }
});

// Adiciona nós dos agentes e do supervisor
workflow.addNode("analyst", analystAgent);
workflow.addNode("billing", billingAgent);
workflow.addNode("escalator", escalatorAgent);
workflow.addNode("supervisor", supervisor);

// Define a lógica de transição
// O supervisor é o ponto de entrada principal
workflow.setEntryPoint("supervisor");

// Conexões condicionais baseadas na saída do supervisor
workflow.addConditionalEdges(
  "supervisor",
  (x: { next: string }) => x.next, // Usa o campo 'next' para decidir
  {
    analyst: "analyst",
    billing: "billing",
    escalator: "escalator",
    [END]: END
  }
);

// Quando um agente termina, ele sempre volta para o supervisor para reavaliar
workflow.addEdge("analyst", "supervisor");
workflow.addEdge("billing", "supervisor");
workflow.addEdge("escalator", "supervisor");

const app = workflow.compile();

/**
 * PASSO 5: EXECUÇÃO DA APLICAÇÃO (API ROUTE)
 * 
 * Endpoint da API Next.js que recebe a consulta do usuário e executa o grafo.
 */
export async function POST(req: Request) {
  const { message } = await req.json();

  // Estado inicial do grafo com a mensagem do usuário
  const initialInputs = { messages: [{ role: "user", content: message }] };

  console.log("--- INÍCIO DO FLUXO MULTI-AGENTE ---");
  
  // Executa o grafo passo a passo
  const stream = await app.stream(initialInputs, { recursionLimit: 10 });
  
  const conversationLog: any[] = [];

  // Processa o stream de eventos para visualização
  for await (const step of stream) {
    const nodeName = Object.keys(step)[0];
    const state = step[nodeName];
    
    // Filtra apenas mensagens relevantes para a resposta final
    if (state.messages && state.messages.length > 0) {
      const lastMsg = state.messages[state.messages.length - 1];
      // Ignora mensagens de ferramentas (ToolMessage) na resposta visual final
      if (!(lastMsg instanceof ToolMessage)) {
        conversationLog.push({
          agent: nodeName,
          content: lastMsg.content
        });
      }
    }
    
    // Se chegou ao fim, para
    if (nodeName === "__end__") break;
  }

  console.log("--- FIM DO FLUXO ---");

  return Response.json({
    status: "success",
    conversation: conversationLog,
    summary: "Processamento concluído com colaboração de agentes."
  });
}

/**
 * EXEMPLO DE USO (Simulação de Execução):
 * 
 * Input do Usuário: "Meu sistema está lento e meu cartão de crédito expirou."
 * 
 * 1. Supervisor recebe a mensagem -> Analisa -> Decide ir para 'analyst'.
 * 2. Analyst analisa "lentidão" -> Invoca ferramenta de diagnóstico -> Retorna solução técnica.
 * 3. Analyst devolve mensagem ao Supervisor.
 * 4. Supervisor vê a mensagem e a consulta original -> Decide ir para 'billing'.
 * 5. Billing verifica conta -> Invoca ferramenta de pagamento -> Retorna status.
 * 6. Billing devolve mensagem ao Supervisor.
 * 7. Supervisor decide que o fluxo deve terminar (END).
 * 
 * Resultado Final: O usuário recebe uma resposta consolidada com a solução técnica e o status do pagamento.
 */
