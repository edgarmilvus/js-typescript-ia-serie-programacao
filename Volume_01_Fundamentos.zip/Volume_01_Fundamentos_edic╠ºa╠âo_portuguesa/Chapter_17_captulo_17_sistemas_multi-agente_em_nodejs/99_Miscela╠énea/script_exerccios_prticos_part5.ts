/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_exerccios_prticos_part5.ts
// Description: Exercícios Práticos
// ==========================================

// Arquivo: src/graph/codeGeneratorGraph.ts
import { StateGraph, END } from "@langchain/langgraph";
import { BaseMessage } from "@langchain/core/messages";

// 1. Definição da Interface e Tipos
interface Artifact {
  filename: string;
  content: string;
}

interface CodeAgentState {
  messages: BaseMessage[];
  pending_tasks: string[]; // Ex: ["Criar User Model", "Criar Auth Controller"]
  generated_files: Artifact[];
}

// 2. Reducers Personalizados
// O reducer garante que novos arquivos sejam adicionados à lista existente
const filesReducer = (existing: Artifact[] = [], newFiles: Artifact | Artifact[]) => {
  const filesToAdd = Array.isArray(newFiles) ? newFiles : [newFiles];
  return [...existing, ...filesToAdd];
};

const tasksReducer = (existing: string[] = [], newTasks: string[] | null) => {
  if (!newTasks) return existing;
  // Remove a tarefa concluída (assumindo que newTasks contém as atualizações)
  // Lógica simplificada: substitui a lista
  return newTasks;
};

// 3. Configuração do Grafo
export const createCodeGraph = () => {
  const workflow = new StateGraph<CodeAgentState>({
    channels: {
      messages: {
        value: (x: BaseMessage[], y: BaseMessage[]) => (y ? [...x, ...y] : x),
        default: () => []
      },
      pending_tasks: {
        value: tasksReducer,
        default: () => []
      },
      generated_files: {
        value: filesReducer,
        default: () => []
      }
    }
  });

  // 4. Definição dos Nós (Implementação Simulada)

  // Nó Decompositor: Pega a primeira tarefa, gera arquivo, atualiza estado
  const taskDecomposer = async (state: CodeAgentState) => {
    console.log("Processando tarefas pendentes:", state.pending_tasks);
    
    if (state.pending_tasks.length === 0) {
      // Se não houver tarefas, sinaliza para ir para o final
      return { pending_tasks: null, next: "finalize" };
    }

    const currentTask = state.pending_tasks[0];
    const remainingTasks = state.pending_tasks.slice(1);
    
    // Simulação de geração de código
    const newArtifact: Artifact = {
      filename: `${currentTask.replace(/\s+/g, '_')}.ts`,
      content: `// Código gerado para: ${currentTask}\nexport const handler = () => {};`
    };

    return {
      generated_files: [newArtifact],
      pending_tasks: remainingTasks,
      next: "supervisor_loop" // Sinal para o condicional
    };
  };

  // Nó Finalizador: Compila o resultado
  const finalizer = async (state: CodeAgentState) => {
    const summary = `Projeto finalizado com ${state.generated_files.length} arquivos.`;
    return { messages: [{ role: "assistant", content: summary }] as BaseMessage[] };
  };

  // Adiciona nós ao grafo
  workflow.addNode("task_decomposer", taskDecomposer);
  workflow.addNode("finalizer", finalizer);

  // 5. Lógica de Controle (O Desafio Interativo)
  
  // Ponto de entrada
  workflow.setEntryPoint("task_decomposer");

  // Condicionais baseadas no retorno do decomposer
  workflow.addConditionalEdges(
    "task_decomposer",
    (state: any) => {
      // Se 'next' for 'finalize', vai para END (ou nó final)
      if (state.next === "finalize") return "finalizer";
      // Caso contrário, volta para o decomposer (loop)
      return "task_decomposer";
    }
  );

  // Conexão do finalizador para o END
  workflow.addEdge("finalizer", END);

  return workflow.compile();
};
