/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_exerccios_prticos_part3.tsx
// Description: Exercícios Práticos
// ==========================================

// Arquivo: src/components/MultiAgentVisualizer.tsx
import React, { useState, useEffect } from 'react';

// Tipagem estrita para o estado do agente
interface AgentNode {
  id: string;
  label: string;
  status: 'idle' | 'active' | 'completed' | 'error';
}

interface AgentState {
  nodes: AgentNode[];
  activeNodeId: string | null;
}

// Hook de Simulação (Desafio Interativo)
const useAgentSimulation = (): AgentState => {
  const [state, setState] = useState<AgentState>({
    nodes: [
      { id: 'supervisor', label: 'Supervisor', status: 'idle' },
      { id: 'billing', label: 'Agente Faturamento', status: 'idle' },
      { id: 'tech', label: 'Agente Técnico', status: 'idle' },
    ],
    activeNodeId: null
  });

  useEffect(() => {
    const sequence = [
      { active: 'supervisor', completed: [] },
      { active: 'billing', completed: ['supervisor'] },
      { active: 'supervisor', completed: ['billing'] },
      { active: null, completed: ['supervisor'] }, // Finalizado
    ];

    let step = 0;
    const interval = setInterval(() => {
      if (step >= sequence.length) {
        clearInterval(interval);
        return;
      }

      const currentStep = sequence[step];
      
      setState(prev => {
        const newNodes = prev.nodes.map(node => {
          if (currentStep.completed.includes(node.id)) {
            return { ...node, status: 'completed' };
          }
          if (node.id === currentStep.active) {
            return { ...node, status: 'active' };
          }
          if (node.status === 'active' && node.id !== currentStep.active) {
            return { ...node, status: 'idle' }; // Reseta nós anteriores
          }
          return node;
        });

        return {
          nodes: newNodes,
          activeNodeId: currentStep.active
        };
      });

      step++;
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return state;
};

// Componente Visual
export const MultiAgentVisualizer: React.FC = () => {
  const agentState = useAgentSimulation();

  return (
    <div style={{ display: 'flex', gap: '20px', padding: '20px', fontFamily: 'sans-serif' }}>
      {agentState.nodes.map(node => (
        <div
          key={node.id}
          style={{
            padding: '15px',
            border: '2px solid #ccc',
            borderRadius: '8px',
            minWidth: '120px',
            textAlign: 'center',
            transition: 'all 0.3s ease',
            backgroundColor: '#f9f9f9',
            // Lógica de estilo condicional
            borderColor: node.status === 'active' ? '#ff4444' : node.status === 'completed' ? '#00C851' : '#ccc',
            boxShadow: node.status === 'active' ? '0 0 10px rgba(255, 68, 68, 0.5)' : 'none',
            transform: node.status === 'active' ? 'scale(1.05)' : 'scale(1)'
          }}
        >
          <div style={{ fontWeight: 'bold' }}>{node.label}</div>
          <div style={{ fontSize: '0.8em', marginTop: '5px', color: '#666' }}>
            Status: {node.status.toUpperCase()}
          </div>
        </div>
      ))}
    </div>
  );
};
