/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_exerccios_prticos_part2.ts
// Description: Exercícios Práticos
// ==========================================

// Arquivo: src/tools/parallelTools.ts
import { Tool } from "@langchain/core/tools";
import { z } from "zod";

// 1. Definição das Ferramentas (Mock para simulação)
export class WeatherTool extends Tool {
  name = "weather_api";
  description = "Obtém a previsão do tempo para uma cidade específica.";

  async _call(input: string): Promise<string> {
    // Simulação de delay de rede
    await new Promise(resolve => setTimeout(resolve, 500)); 
    return JSON.stringify({ city: input, temp: 22, condition: "Ensolarado" });
  }
}

export class FlightTool extends Tool {
  name = "flight_api";
  description = "Obtém preços de voos.";

  async _call(input: string): Promise<string> {
    // Simulação de falha aleatória ou forçada para o desafio
    const shouldFail = true; // Altere para false para testar sucesso
    if (shouldFail) {
      throw new Error("API de Voços indisponível (Erro 503)");
    }
    return JSON.stringify({ price: 450, airline: "LATAM" });
  }
}

// 2. Nó de Agente com Execução Paralela
export const parallelAgentNode = async (state: any) => {
  const weatherTool = new WeatherTool();
  const flightTool = new FlightTool();

  const city = "Paris"; // Extraído do state.messages anteriormente via LLM ou NLU
  
  try {
    // Execute as ferramentas em paralelo
    const [weatherResult, flightResult] = await Promise.allSettled([
      weatherTool.invoke(city),
      flightTool.invoke(city)
    ]);

    let responseText = "Aqui está a informação solicitada:\n";

    // Tratamento de resultados (Pattern Matching / Guard Clauses)
    if (weatherResult.status === "fulfilled") {
      const weatherData = JSON.parse(weatherResult.value);
      responseText += `Clima em ${weatherData.city}: ${weatherData.temp}°C, ${weatherData.condition}.\n`;
    } else {
      console.error("Erro ao buscar clima:", weatherResult.reason);
    }

    if (flightResult.status === "fulfilled") {
      const flightData = JSON.parse(flightResult.value);
      responseText += `Preço médio de voo: $${flightData.price}.`;
    } else {
      // Lógica de fallback
      console.warn("Erro ao buscar voços (paralelo):", flightResult.reason.message);
      responseText += "Infelizmente, não consegui consultar os preços de voo no momento.";
    }

    return { messages: [{ role: "assistant", content: responseText }] };

  } catch (error) {
    console.error("Erro crítico no nó paralelo:", error);
    return { messages: [{ role: "assistant", content: "Ocorreu um erro inesperado." }] };
  }
};
