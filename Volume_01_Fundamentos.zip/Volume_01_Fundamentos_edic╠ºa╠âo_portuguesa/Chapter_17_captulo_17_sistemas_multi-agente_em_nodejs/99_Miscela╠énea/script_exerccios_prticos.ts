/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_exerccios_prticos.ts
// Description: Exercícios Práticos
// ==========================================

// Arquivo: src/agents/supervisor.ts
import { ChatOpenAI } from "@langchain/openai";
import { StateGraph, END, MessageGraph } from "@langchain/langgraph";
import { HumanMessage, SystemMessage } from "@langchain/core/messages";

// Defina o tipo do Estado do Grafo
type AgentState = {
  messages: HumanMessage[];
  next?: string;
};

// 1. Defina o prompt do Supervisor
const supervisorSystemPrompt = `
Você é um supervisor gerenciando um sistema de suporte ao cliente com dois agentes:
- "faturamento": Lida com pagamentos, reembolsos e faturas.
- "suporte_tecnico": Resolve problemas de login, bugs e erros técnicos.
- "finalizar": Usado quando o problema está resolvido ou a conversa não tem relação com o sistema.

Analise a última mensagem do usuário e determine qual agente deve atuar.
Responda estritamente em JSON: { "next": "faturamento" | "suporte_tecnico" | "finalizar" }
`;

// 2. Crie a função do Supervisor Node
export const createSupervisorNode = () => {
  const model = new ChatOpenAI({ model: "gpt-4o-mini" });

  return async (state: AgentState): Promise<{ next: string }> => {
    const messages = [
      new SystemMessage(supervisorSystemPrompt),
      ...state.messages
    ];

    const response = await model.invoke(messages);
    
    // Parse da resposta (assumindo que o LLM retorna JSON válido)
    // Nota: Em produção, useja um parser de output robusto (ex: JsonOutputToolsParser)
    try {
      const content = response.content as string;
      const parsed = JSON.parse(content);
      return { next: parsed.next };
    } catch (e) {
      // Fallback caso o LLM falhe em retornar JSON
      return { next: "finalizar" };
    }
  };
};

// 3. Estrutura do Grafo (Lógica de Montagem)
export const buildGraph = () => {
  const workflow = new StateGraph<AgentState>({
    channels: {
      messages: {
        value: (x: HumanMessage[], y: HumanMessage[]) => (y ? [...x, ...y] : x),
        default: () => []
      },
      next: {
        value: (x: string, y: string) => y || x,
        default: () => ""
      }
    }
  });

  // Adicione os nós dos agentes (Worker Agents)
  // Supondo que temos nodes `billingNode` e `techNode` definidos em outro arquivo
  // workflow.addNode("faturamento", billingNode);
  // workflow.addNode("suporte_tecnico", techNode);
  
  // Adicione o nó do Supervisor
  workflow.addNode("supervisor", createSupervisorNode());

  // Defina o ponto de entrada
  workflow.setEntryPoint("supervisor");

  // Adicione condicionais baseadas na saída do supervisor
  // workflow.addConditionalEdges("supervisor", ...);

  return workflow.compile();
};
