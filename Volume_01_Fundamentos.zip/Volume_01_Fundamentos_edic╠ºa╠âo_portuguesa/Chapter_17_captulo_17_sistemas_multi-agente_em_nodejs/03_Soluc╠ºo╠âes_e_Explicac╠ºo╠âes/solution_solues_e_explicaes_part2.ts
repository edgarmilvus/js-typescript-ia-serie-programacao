/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part2.ts
// Description: Soluções e Explicações
// ==========================================

// Arquivo: src/tools/parallelTools.ts
import { Tool } from "@langchain/core/tools";

// 1. Definição das Ferramentas (Mock)
export class WeatherTool extends Tool {
  name = "weather_api";
  description = "Obtém a previsão do tempo para uma cidade específica.";

  async _call(input: string): Promise<string> {
    // Simulação de delay de rede
    await new Promise(resolve => setTimeout(resolve, 500)); 
    return JSON.stringify({ city: input, temp: 22, condition: "Ensolarado" });
  }
}

export class FlightTool extends Tool {
  name = "flight_api";
  description = "Obtém preços de voos.";

  async _call(input: string): Promise<string> {
    // Simulação de falha forçada para o desafio
    const shouldFail = true; 
    if (shouldFail) {
      throw new Error("API de Voços indisponível (Erro 503)");
    }
    return JSON.stringify({ price: 450, airline: "LATAM" });
  }
}

// 2. Nó de Agente com Execução Paralela
export const parallelAgentNode = async (state: any) => {
  const weatherTool = new WeatherTool();
  const flightTool = new FlightTool();

  // Extração básica de cidade (simulação)
  const city = "Paris"; 
  
  console.log("Iniciando execução paralela de ferramentas...");

  try {
    // Promise.allSettled espera que todas as promessas sejam resolvidas (sucesso ou falha)
    const results = await Promise.allSettled([
      weatherTool.invoke(city),
      flightTool.invoke(city)
    ]);

    let responseText = "Aqui está a informação solicitada:\n";
    let hasError = false;

    // Processamento do resultado do Clima (Índice 0)
    if (results[0].status === "fulfilled") {
      const weatherData = JSON.parse(results[0].value);
      responseText += `Clima em ${weatherData.city}: ${weatherData.temp}°C, ${weatherData.condition}.\n`;
    } else {
      console.error("Erro ao buscar clima:", results[0].reason);
      responseText += "Dados climáticos indisponíveis.\n";
    }

    // Processamento do resultado de Voos (Índice 1)
    if (results[1].status === "fulfilled") {
      const flightData = JSON.parse(results[1].value);
      responseText += `Preço médio de voo: $${flightData.price}.`;
    } else {
      // Lógica de graceful degradation (degradação graciosa)
      console.warn("Erro ao buscar voços:", results[1].reason.message);
      responseText += "Infelizmente, não consegui consultar os preços de voo no momento.";
      hasError = true;
    }

    // Retorna o estado atualizado com a mensagem do assistente
    return { 
      messages: [{ role: "assistant", content: responseText }],
      has_error: hasError 
    };

  } catch (error) {
    console.error("Erro crítico no nó paralelo:", error);
    return { messages: [{ role: "assistant", content: "Ocorreu um erro inesperado no sistema." }] };
  }
};
