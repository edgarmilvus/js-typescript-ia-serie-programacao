/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.ts
// Description: Soluções e Explicações
// ==========================================

digraph ArquiteturaMultiAgente {
    // Configurações globais do grafo
    rankdir=TB; // Top to Bottom
    splines=ortho; // Linhas retas/ortogonais para limpeza
    nodesep=0.8; // Separação entre nós
    ranksep=1.0; // Separação entre ranks

    // --- Definição de Estilos Globais ---
    node [fontname="Arial", fontsize=10];
    edge [color="#555555", arrowhead=vee];

    // --- Nós Principais (Fora do Pool) ---

    // Supervisor (Estilo Box, Cor Lightblue)
    supervisor [shape=box, style=filled, fillcolor="#ADD8E6", label="Supervisor\n(Orquestrador)"];

    // Validacao Humana (Estilo Diamond, Cor Gold)
    validation [shape=diamond, style=filled, fillcolor="#FFD700", label="Validação\nHumana"];

    // --- Agrupamento dos Workers (Cluster) ---
    subgraph cluster_0 {
        // Estilo do cluster (caixa externa)
        style=filled;
        color="#EEEEEE";
        label="Pool de Agentes (Workers)";
        fontname="Arial-Bold";
        
        // Nós dos Workers (Estilo Ellipse, Cor Lightgrey)
        node [shape=ellipse, style=filled, fillcolor="#D3D3D3"];
        
        worker_busca [label="Agente Busca"];
        worker_analise [label="Agente Análise"];
        worker_resumo [label="Agente Resumo"];
    }

    // --- Definição das Conexões (Fluxo) ---

    // 1. Supervisor aponta para os Workers (Decisão)
    // Nota: Em um LLM, isso é condicional, mas visualmente mostramos as possibilidades
    supervisor -> worker_busca [label="Consulta Base"];
    supervisor -> worker_analise [label="Análise Profunda"];
    supervisor -> worker_resumo [label="Síntese Final"];

    // 2. Workers apontam de volta para Supervisor (Iteração)
    // Usamos constraint=false para permitir layout flexível
    worker_busca -> supervisor [constraint=false, style=dashed, label="Dados Coletados"];
    worker_analise -> supervisor [constraint=false, style=dashed, label="Insights"];

    // 3. Fluxo para Validação Humana
    // O Worker de Resumo pode ir para validação se a confiança for baixa
    worker_resumo -> validation [label="Confiança Baixa"];

    // 4. Validação volta para o Supervisor
    validation -> supervisor [label="Aprovação/Revisão"];
}
