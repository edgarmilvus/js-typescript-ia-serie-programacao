/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part5.ts
// Description: Soluções e Explicações
// ==========================================

// Arquivo: src/graph/codeGeneratorGraph.ts
import { StateGraph, END } from "@langchain/langgraph";
import { BaseMessage, HumanMessage } from "@langchain/core/messages";

// 1. Definição da Interface e Tipos
interface Artifact {
  filename: string;
  content: string;
}

interface CodeAgentState {
  messages: BaseMessage[];
  pending_tasks: string[]; // Tarefas a serem executadas
  generated_files: Artifact[]; // Artefatos produzidos
}

// 2. Reducers Personalizados
// Reducer para arquivos: Anexa novos arquivos à lista existente
const filesReducer = (existing: Artifact[] = [], newFiles: Artifact | Artifact[]) => {
  const filesToAdd = Array.isArray(newFiles) ? newFiles : [newFiles];
  return [...existing, ...filesToAdd];
};

// Reducer para tarefas: Atualiza a lista (removendo a concluída ou adicionando novas)
const tasksReducer = (existing: string[] = [], newTasks: string[] | null) => {
  if (newTasks === null) return existing; // Se null, mantém o estado atual
  return newTasks;
};

// 3. Nós do Grafo

// Nó Decompositor (Task Decomposer)
const taskDecomposer = async (state: CodeAgentState) => {
  console.log(`[Decompositor] Tarefas restantes: ${state.pending_tasks.length}`);
  
  // Se não houver tarefas, sinaliza para finalizar
  if (state.pending_tasks.length === 0) {
    return { 
      pending_tasks: null, 
      messages: [new HumanMessage("Todas as tarefas foram concluídas.")] 
    };
  }

  // Pega a primeira tarefa (FIFO)
  const currentTask = state.pending_tasks[0];
  
  // Simulação de geração de código
  const newArtifact: Artifact = {
    filename: `${currentTask.replace(/\s+/g, '_').toLowerCase()}.ts`,
    content: `// Código gerado para: ${currentTask}\nexport const handler = () => { console.log('${currentTask}'); };`
  };

  // Cria nova lista de tarefas removendo a atual processada
  const remainingTasks = state.pending_tasks.slice(1);

  return {
    generated_files: [newArtifact],
    pending_tasks: remainingTasks,
    messages: [new HumanMessage(`Arquivo gerado: ${newArtifact.filename}`)]
  };
};

// Nó Finalizador
const finalizer = async (state: CodeAgentState) => {
  const summary = `Projeto finalizado. Total de arquivos gerados: ${state.generated_files.length}.`;
  console.log(`[Finalizador] ${summary}`);
  
  // Poderia compilar os arquivos aqui
  return { 
    messages: [new HumanMessage(summary)] 
  };
};

// 4. Construção do Grafo com Loop Iterativo
export const createCodeGraph = () => {
  const workflow = new StateGraph<CodeAgentState>({
    channels: {
      messages: {
        value: (x: BaseMessage[], y: BaseMessage[]) => (y ? [...x, ...y] : x),
        default: () => []
      },
      pending_tasks: {
        value: tasksReducer,
        default: () => [] // Inicializa vazio se não fornecido
      },
      generated_files: {
        value: filesReducer,
        default: () => []
      }
    }
  });

  // Adiciona nós
  workflow.addNode("task_decomposer", taskDecomposer);
  workflow.addNode("finalizer", finalizer);

  // Define ponto de entrada
  workflow.setEntryPoint("task_decomposer");

  // Lógica de Loop (Desafio Interativo)
  // O decompositor retorna para si mesmo se houver tarefas pendentes, ou vai para o final
  workflow.addConditionalEdges(
    "task_decomposer",
    (state: CodeAgentState) => {
      // Se pending_tasks estiver vazio (verificado no nó e retornado como null/manter vazio)
      // Nota: Precisamos verificar o estado atualizado retornado
      if (state.pending_tasks.length === 0) {
        return "finalizer";
      }
      // Caso contrário, continue o loop
      return "task_decomposer";
    }
  );

  // Conexão do finalizador para o fim do grafo
  workflow.addEdge("finalizer", END);

  return workflow.compile();
};

// 5. Script de Teste (Simulação)
export const runCodeGraphTest = async () => {
  const graph = createCodeGraph();
  
  // Estado inicial com tarefas
  const initialState: CodeAgentState = {
    messages: [new HumanMessage("Criar uma API simples")],
    pending_tasks: ["Criar User Model", "Criar Auth Controller", "Criar Route Config"],
    generated_files: []
  };

  console.log("--- Iniciando Graph Code Generator ---");
  let currentState = initialState;

  // Executa o grafo iterativamente (simulando o loop do LangGraph)
  // Nota: O LangGraph compila o loop, aqui simulamos a passagem de estado para demonstrar a lógica
  // Num ambiente real, chamariamos graph.invoke(initialState)
  
  // Simulação visual do loop:
  for (let i = 0; i < 5; i++) {
     if (currentState.pending_tasks.length === 0) break;
     console.log(`\nIteração ${i+1}: Processando '${currentState.pending_tasks[0]}'`);
     // Na prática, o graph.invoke faria isso automaticamente
     // Aqui apenas ilustramos o fluxo que o código acima controla
  }
};
