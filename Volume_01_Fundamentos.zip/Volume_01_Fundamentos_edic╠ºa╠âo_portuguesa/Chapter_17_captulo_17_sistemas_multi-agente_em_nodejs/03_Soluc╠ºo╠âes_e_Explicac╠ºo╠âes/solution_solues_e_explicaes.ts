/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.ts
// Description: Soluções e Explicações
// ==========================================

// Arquivo: src/agents/supervisor.ts
import { ChatOpenAI } from "@langchain/openai";
import { StateGraph, END, MessageGraph } from "@langchain/langgraph";
import { HumanMessage, SystemMessage, BaseMessage } from "@langchain/core/messages";

// 1. Definição do Estado e Tipos
type AgentState = {
  messages: BaseMessage[];
  next?: string;
  round_count?: number; // Contador para evitar loops infinitos
};

// 2. Prompt do Supervisor
const supervisorSystemPrompt = `
Você é um supervisor gerenciando um sistema de suporte ao cliente com dois agentes:
- "faturamento": Lida com pagamentos, reembolsos e faturas.
- "suporte_tecnico": Resolve problemas de login, bugs e erros técnicos.
- "finalizar": Usado quando o problema está resolvido ou a conversa não tem relação com o sistema.

Analise a última mensagem do usuário e determine qual agente deve atuar.
Responda estritamente em JSON: { "next": "faturamento" | "suporte_tecnico" | "finalizar" }
`;

// 3. Nó do Supervisor
export const createSupervisorNode = () => {
  const model = new ChatOpenAI({ model: "gpt-4o-mini", temperature: 0 });

  return async (state: AgentState): Promise<{ next: string }> => {
    // Incrementa o contador de rodadas
    const currentRound = (state.round_count || 0) + 1;
    
    // Verificação de segurança contra loops infinitos
    if (currentRound > 3) {
      console.log("Limite de rodadas atingido. Forçando finalização.");
      return { next: "finalizar" };
    }

    const messages = [
      new SystemMessage(supervisorSystemPrompt),
      ...state.messages
    ];

    const response = await model.invoke(messages);
    
    try {
      const content = response.content as string;
      // Tenta extrair o JSON da resposta
      const jsonMatch = content.match(/\{.*\}/);
      if (!jsonMatch) throw new Error("JSON não encontrado");
      
      const parsed = JSON.parse(jsonMatch[0]);
      return { next: parsed.next };
    } catch (e) {
      console.error("Erro no parsing do supervisor:", e);
      return { next: "finalizar" };
    }
  };
};

// 4. Nós Simulados dos Agentes (Workers)
const billingNode = async (state: AgentState) => {
  const lastMsg = state.messages[state.messages.length - 1].content;
  const response = `[Faturamento] Processando sua fatura sobre: "${lastMsg}". Pagamento confirmado.`;
  return { messages: [new HumanMessage(response)] };
};

const techNode = async (state: AgentState) => {
  const lastMsg = state.messages[state.messages.length - 1].content;
  const response = `[Suporte Técnico] Analisando problema: "${lastMsg}". Tente limpar o cache.`;
  return { messages: [new HumanMessage(response)] };
};

// 5. Construção do Grafo
export const buildGraph = () => {
  const workflow = new StateGraph<AgentState>({
    channels: {
      messages: {
        value: (x: BaseMessage[], y: BaseMessage[]) => (y ? [...x, ...y] : x),
        default: () => []
      },
      next: {
        value: (x: string, y: string) => y || x,
        default: () => ""
      },
      round_count: {
        value: (x: number = 0, y: number) => y !== undefined ? y : x,
        default: () => 0
      }
    }
  });

  // Adiciona nós
  workflow.addNode("supervisor", createSupervisorNode());
  workflow.addNode("faturamento", billingNode);
  workflow.addNode("suporte_tecnico", techNode);

  // Define entrada
  workflow.setEntryPoint("supervisor");

  // Conexões condicionais do supervisor
  workflow.addConditionalEdges(
    "supervisor",
    (state: AgentState) => {
      if (state.next === "faturamento") return "faturamento";
      if (state.next === "suporte_tecnico") return "suporte_tecnico";
      return END;
    }
  );

  // Os workers sempre retornam ao supervisor para análise do próximo passo
  workflow.addEdge("faturamento", "supervisor");
  workflow.addEdge("suporte_tecnico", "supervisor");

  return workflow.compile();
};
