/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.tsx
// Description: Soluções e Explicações
// ==========================================

// Arquivo: src/components/MultiAgentVisualizer.tsx
import React, { useState, useEffect } from 'react';

// 1. Tipagem Estrita
interface AgentNode {
  id: string;
  label: string;
  status: 'idle' | 'active' | 'completed' | 'error';
}

interface AgentState {
  nodes: AgentNode[];
  activeNodeId: string | null;
}

// 2. Hook Customizado de Simulação
const useAgentSimulation = (): AgentState => {
  const [state, setState] = useState<AgentState>({
    nodes: [
      { id: 'supervisor', label: 'Supervisor', status: 'idle' },
      { id: 'billing', label: 'Agente Faturamento', status: 'idle' },
      { id: 'tech', label: 'Agente Técnico', status: 'idle' },
    ],
    activeNodeId: null
  });

  useEffect(() => {
    // Sequência de estados simulados (Ciclo de Vida da Requisição)
    const sequence = [
      { active: 'supervisor', completed: [] },
      { active: 'billing', completed: ['supervisor'] },
      { active: 'supervisor', completed: ['billing'] },
      { active: null, completed: ['supervisor'] }, // Finalizado
    ];

    let step = 0;
    const interval = setInterval(() => {
      if (step >= sequence.length) {
        clearInterval(interval);
        return;
      }

      const currentStep = sequence[step];
      
      setState(prev => {
        // Mapeia os nós para atualizar seus status baseados no passo atual
        const newNodes = prev.nodes.map(node => {
          // Se o nó foi completado nesta etapa, muda para 'completed'
          if (currentStep.completed.includes(node.id)) {
            return { ...node, status: 'completed' };
          }
          // Se é o nó ativo, muda para 'active'
          if (node.id === currentStep.active) {
            return { ...node, status: 'active' };
          }
          // Se era ativo mas não é mais, reseta para idle (ou mantém completed se já tiver sido)
          if (node.status === 'active' && node.id !== currentStep.active) {
             return { ...node, status: 'idle' };
          }
          return node;
        });

        return {
          nodes: newNodes,
          activeNodeId: currentStep.active
        };
      });

      step++;
    }, 2000); // Atualiza a cada 2 segundos

    return () => clearInterval(interval);
  }, []);

  return state;
};

// 3. Componente Visual
export const MultiAgentVisualizer: React.FC = () => {
  const agentState = useAgentSimulation();

  return (
    <div style={{ display: 'flex', gap: '20px', padding: '20px', fontFamily: 'sans-serif', justifyContent: 'center' }}>
      {agentState.nodes.map(node => (
        <div
          key={node.id}
          style={{
            padding: '15px',
            border: '2px solid #ccc',
            borderRadius: '8px',
            minWidth: '140px',
            textAlign: 'center',
            transition: 'all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1)',
            backgroundColor: '#f9f9f9',
            // Lógica de Estilo Condicional
            borderColor: 
              node.status === 'active' ? '#ff4444' : 
              node.status === 'completed' ? '#00C851' : '#ccc',
            boxShadow: 
              node.status === 'active' ? '0 0 15px rgba(255, 68, 68, 0.6)' : 'none',
            transform: 
              node.status === 'active' ? 'scale(1.1)' : 'scale(1)',
            opacity: node.status === 'idle' ? 0.7 : 1
          }}
        >
          <div style={{ fontWeight: 'bold', marginBottom: '5px' }}>{node.label}</div>
          <div style={{ fontSize: '0.8em', color: '#666', textTransform: 'uppercase' }}>
            {node.status}
          </div>
        </div>
      ))}
    </div>
  );
};
