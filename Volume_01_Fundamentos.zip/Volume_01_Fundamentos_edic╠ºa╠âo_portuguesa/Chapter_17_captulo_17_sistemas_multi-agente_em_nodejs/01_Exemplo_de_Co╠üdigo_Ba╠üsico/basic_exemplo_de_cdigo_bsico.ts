/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.ts
// Description: Exemplo de Código Básico
// ==========================================

/**
 * SISTEMA MULTI-AGENTE: HELLO WORLD ASYNC TOOL HANDLING
 * Contexto: API Web para consulta de dados meteorológicos.
 * Objetivo: Demonstrar como o Supervisor coordena a execução de uma ferramenta
 * bloqueante sem travar o event loop do Node.js.
 */

// 1. Definição de Tipos (TypeScript)
// Garante segurança de tipos na comunicação entre Agentes e Ferramentas.
interface AgentResponse {
    success: boolean;
    data?: string;
    error?: string;
}

// 2. Simulação de Ferramenta Externa (Async Tool)
// Em um cenário real, isso seria uma chamada HTTP (fetch) ou consulta SQL.
// O uso de 'Promise' e 'setTimeout' simula o atraso de rede (latência).
const fetchWeatherData = async (city: string): Promise<string> => {
    console.log(`[Ferramenta] Iniciando consulta para: ${city}...`);
    
    // Simula uma operação de I/O que leva 2 segundos (ex: API externa).
    // O código não para aqui; o event loop pode processar outras requisições.
    await new Promise(resolve => setTimeout(resolve, 2000));

    const weatherData = `22°C, Nublado em ${city}`;
    console.log(`[Ferramenta] Dados recebidos: ${weatherData}`);
    
    return weatherData;
};

/**
 * 3. Agente Supervisor (Orquestrador)
 * Recebe a requisição, decide qual ferramenta usar e aguarda o resultado.
 * 
 * @param city - A cidade solicitada pelo usuário.
 * @returns Promise<AgentResponse> - O resultado processado.
 */
const supervisorAgent = async (city: string): Promise<AgentResponse> => {
    try {
        // [CRÍTICO ASYNC/AWAIT] 
        // O 'await' aqui pausa a execução desta função específica (supervisorAgent),
        // mas NÃO bloqueia o servidor Node.js inteiro.
        const weatherInfo = await fetchWeatherData(city);

        // Processamento pós-ferramenta (Tomada de decisão do Agente)
        if (weatherInfo.includes("Nublado")) {
            return {
                success: true,
                data: `Relatório: ${weatherInfo}. Recomendação: Leve um casaco.`
            };
        }

        return {
            success: true,
            data: `Relatório: ${weatherInfo}.`
        };

    } catch (error) {
        // Tratamento de erro robusto para falhas na ferramenta externa
        return {
            success: false,
            error: `Falha na consulta meteorológica: ${error}`
        };
    }
};

// 4. Simulação de Entrada de Web App (Main Execution)
// Esta função simula um endpoint HTTP sendo chamado.
const main = async () => {
    console.log("--- Iniciando Sistema Multi-Agente ---");
    
    const startTime = Date.now();
    
    // Chamada ao agente supervisor
    const result = await supervisorAgent("São Paulo");
    
    const duration = (Date.now() - startTime) / 1000;

    console.log("\n--- Resultado Final ---");
    console.log("Status:", result.success ? "SUCESSO" : "ERRO");
    console.log("Resposta:", result.data || result.error);
    console.log(`Tempo total de execução: ${duration}s (Aguardou a Promise sem bloquear o loop)`);
};

// Executa o fluxo (em um ambiente real, isso seria disparado por um HTTP Request)
main();
