/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada_part2.ts
// Description: Script de Aplicação Avançada
// ==========================================

// app/actions/summarize.ts
"use server";

import OpenAI from "openai";

/**
 * Server Action: Executa no servidor (ou Edge Runtime).
 * Recebe o texto bruto e retorna um ReadableStream processado.
 * 
 * NOTA DE SEGURANÇA: Em produção, proteja esta ação com autenticação (ex: NextAuth).
 */
export async function summarizeChatAction(inputText: string) {
  // 1. Inicialização do Cliente OpenAI
  // As chaves de API devem estar em variáveis de ambiente (process.env.OPENAI_API_KEY)
  const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY!,
  });

  // 2. Definição do Prompt
  const systemPrompt = `
    Você é um assistente de suporte ao cliente especializado.
    Tarefa: Resuma a conversa abaixo em português.
    Requisitos:
    1. Identifique o problema principal do cliente.
    2. Atribua um nível de urgência (Baixa, Média, Alta).
    3. Formate a saída em Markdown.
    4. Seja conciso.
    
    Transcrição:
  `;

  try {
    // 3. Chamada à API com Streaming Habilitado
    const stream = await openai.chat.completions.create({
      model: "gpt-3.5-turbo", // Ou gpt-4-turbo-preview
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: inputText },
      ],
      stream: true, // HABILITA O STREAMING (Crucial para baixa latência percebida)
      temperature: 0.3,
    });

    // 4. Criação do ReadableStream personalizado para o cliente
    // O SDK da OpenAI retorna um AsyncIterable. Precisamos convertê-lo para um Stream padrão do Web.
    const customStream = new ReadableStream({
      async start(controller) {
        try {
          // Iteração sobre os chunks recebidos da API da OpenAI
          for await (const chunk of stream) {
            const content = chunk.choices[0]?.delta?.content;
            if (content) {
              // Codifica o texto para bytes e enfila no controller
              controller.enqueue(new TextEncoder().encode(content));
            }
          }
          controller.close();
        } catch (error) {
          controller.error(error);
        }
      },
    });

    // 5. Retorna o stream para o Client Component
    return customStream;

  } catch (error) {
    console.error("Erro na API OpenAI:", error);
    // Lança um erro que será capturado pelo Client Component
    throw new Error("Falha ao conectar com o serviço de IA.");
  }
}
