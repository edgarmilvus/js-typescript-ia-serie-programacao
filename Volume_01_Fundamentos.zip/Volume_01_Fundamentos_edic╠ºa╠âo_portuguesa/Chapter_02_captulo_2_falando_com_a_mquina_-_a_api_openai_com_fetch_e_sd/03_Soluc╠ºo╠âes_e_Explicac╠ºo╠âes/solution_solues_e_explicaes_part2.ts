/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part2.ts
// Description: Soluções e Explicações
// ==========================================

// chatManager.ts
import OpenAI from 'openai';
import { ChatCompletionMessageParam } from 'openai/resources/chat/completions';

// Configuração da chave via ambiente (process.env.OPENAI_API_KEY)
const openai = new OpenAI();

export class ChatManager {
  private historicoMensagens: ChatCompletionMessageParam[] = [];
  private readonly TOKEN_LIMIT = 1000; // Limite fictício baseado em caracteres

  constructor(systemPrompt?: string) {
    if (systemPrompt) {
      this.adicionarMensagem('system', systemPrompt);
    }
  }

  // Função auxiliar para estimar tokens (simplificada: 4 caracteres = 1 token)
  private estimarTokens(texto: string): number {
    return Math.ceil(texto.length / 4);
  }

  public adicionarMensagem(role: 'user' | 'assistant' | 'system', content: string): void {
    this.historicoMensagens.push({ role, content });
  }

  private gerenciarLimiteTokens(): void {
    let totalTokens = this.historicoMensagens.reduce((acc, msg) => {
      return acc + (msg.content ? this.estimarTokens(msg.content) : 0);
    }, 0);

    // Enquanto exceder o limite e houver mensagens para remover (preservando 'system')
    while (totalTokens > this.TOKEN_LIMIT && this.historicoMensagens.length > 1) {
      // Encontra o índice da primeira mensagem que não seja 'system'
      const indexToRemove = this.historicoMensagens.findIndex((msg, idx) => idx > 0 && msg.role !== 'system');
      
      if (indexToRemove === -1) break; // Proteção

      const removida = this.historicoMensagens.splice(indexToRemove, 1)[0];
      if (removida && removida.content) {
        totalTokens -= this.estimarTokens(removida.content);
      }
    }
  }

  public async enviarMensagemUsuario(conteudo: string): Promise<string> {
    // Adiciona a mensagem do usuário
    this.adicionarMensagem('user', conteudo);

    // Gerencia o limite de tokens ANTES de enviar
    this.gerenciarLimiteTokens();

    try {
      const completion = await openai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: this.historicoMensagens,
      });

      const resposta = completion.choices[0].message;
      
      // Adiciona a resposta ao histórico
      if (resposta.content) {
        this.adicionarMensagem('assistant', resposta.content);
      }

      return resposta.content || 'Não foi possível gerar uma resposta.';
    } catch (error) {
      console.error('Erro ao enviar mensagem:', error);
      throw error;
    }
  }

  // Método para limpar o histórico se necessário
  public limparHistorico(): void {
    this.historicoMensagens = [];
  }
}
