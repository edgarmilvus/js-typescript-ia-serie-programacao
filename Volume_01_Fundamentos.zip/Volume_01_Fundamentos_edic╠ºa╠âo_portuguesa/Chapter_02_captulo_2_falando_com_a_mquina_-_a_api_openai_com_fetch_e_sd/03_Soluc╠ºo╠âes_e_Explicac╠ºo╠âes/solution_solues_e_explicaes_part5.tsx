/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part5.tsx
// Description: Soluções e Explicações
// ==========================================

// app/FormClient.tsx
'use client';

import { useFormState } from 'react-dom';
import { enviarPerguntaAction } from './actions';

const initialState = {
  message: null,
  error: null,
};

export default function FormClient({ action }: { action: any }) {
  const [state, formAction] = useFormState(action, initialState);

  return (
    <div>
      <form action={formAction} className="flex gap-2 mb-4">
        <input type="text" name="mensagem" className="border p-2 text-black flex-1" placeholder="Pergunte algo..." />
        <button type="submit" className="bg-blue-500 text-white p-2 rounded">Enviar</button>
      </form>

      {state?.message && (
        <div className="p-4 bg-gray-100 rounded mt-4">
          <strong>Resposta:</strong>
          <p>{state.message}</p>
        </div>
      )}
      
      {state?.error && <p className="text-red-500 mt-2">{state.error}</p>}
    </div>
  );
}
