/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.ts
// Description: Soluções e Explicações
// ==========================================

// types.ts
export type Message = {
  role: 'user' | 'assistant' | 'system';
  content: string;
};

export type OpenAIResponse = {
  id: string;
  object: string;
  created: number;
  model: string;
  choices: Array<{
    index: number;
    message: Message;
    finish_reason: string;
  }>;
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
};

// openaiService.ts
import { Message, OpenAIResponse } from './types';

const API_URL = 'https://api.openai.com/v1/chat/completions';
const API_KEY = process.env.OPENAI_API_KEY; // Certifique-se de definir no .env

export async function chamarOpenAIFetch(prompt: string): Promise<string> {
  if (!API_KEY) throw new Error('API Key não definida');

  // Validação simples de entrada
  if (!prompt || typeof prompt !== 'string') {
    throw new Error('Prompt deve ser uma string não vazia');
  }

  const payload = {
    model: 'gpt-3.5-turbo',
    messages: [{ role: 'user', content: prompt }],
  };

  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_KEY}`,
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errorBody = await response.text();
      throw new Error(`Erro na API: ${response.status} - ${errorBody}`);
    }

    const data = (await response.json()) as OpenAIResponse;
    
    // Verificação de segurança para garantir que a estrutura existe
    if (!data.choices || data.choices.length === 0 || !data.choices[0].message.content) {
      throw new Error('Resposta inválida da API (sem conteúdo)');
    }

    return data.choices[0].message.content;
  } catch (error) {
    if (error instanceof Error) {
      console.error('Erro na chamada OpenAI:', error.message);
      throw error;
    } else {
      throw new Error('Erro desconhecido ao chamar a API');
    }
  }
}

// Versão modificada para aceitar histórico
export async function chamarOpenAIFetchComHistorico(messages: Message[]): Promise<string> {
  if (!API_KEY) throw new Error('API Key não definida');

  // Validação do histórico
  if (!Array.isArray(messages) || messages.length === 0) {
    throw new Error('Histórico deve ser um array de mensagens não vazio');
  }

  // Garantir integridade básica: alternância de roles (opcional, mas recomendado)
  // A API aceita qualquer ordem, mas para contexto humano, verificamos se não são todos do mesmo tipo consecutivos
  // (Exemplo simplificado de validação)

  const payload = {
    model: 'gpt-3.5-turbo',
    messages: messages,
  };

  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_KEY}`,
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errorBody = await response.text();
      throw new Error(`Erro na API: ${response.status} - ${errorBody}`);
    }

    const data = (await response.json()) as OpenAIResponse;
    
    if (!data.choices || data.choices.length === 0 || !data.choices[0].message.content) {
      throw new Error('Resposta inválida da API');
    }

    return data.choices[0].message.content;
  } catch (error) {
    console.error('Erro na chamada OpenAI:', error);
    throw error;
  }
}
