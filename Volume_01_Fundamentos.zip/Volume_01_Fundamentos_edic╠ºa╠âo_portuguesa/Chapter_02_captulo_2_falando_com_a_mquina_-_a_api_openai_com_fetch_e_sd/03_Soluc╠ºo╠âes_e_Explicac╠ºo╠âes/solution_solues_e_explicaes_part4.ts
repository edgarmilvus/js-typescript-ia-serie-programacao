/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.ts
// Description: Soluções e Explicações
// ==========================================

// app/actions.ts
'use server';

import OpenAI from 'openai';
import { revalidatePath } from 'next/cache';

const openai = new OpenAI();

// Simulação de banco de dados
async function obterContextoUsuario(id: string): Promise<string> {
  // Simulando uma chamada assíncrona a um DB
  await new Promise(resolve => setTimeout(resolve, 100));
  return `Contexto do usuário ${id}: Prefere respostas em português e gosta de detalhes técnicos.`;
}

export async function enviarPerguntaAction(prevState: any, formData: FormData) {
  const mensagem = formData.get('mensagem') as string;
  const userId = 'user_123'; // Simulação de ID logado

  if (!mensagem) {
    return { error: 'Mensagem não pode ser vazia' };
  }

  try {
    // 1. Obter contexto do banco de dados
    const contextoDB = await obterContextoUsuario(userId);
    
    // 2. Construir o prompt enriquecido
    const promptCompleto = `${contextoDB}\n\nUsuário pergunta: ${mensagem}`;

    // 3. Chamar a OpenAI
    const completion = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: 'Você é um assistente útil.' },
        { role: 'user', content: promptCompleto }
      ],
      stream: true, // Importante para streaming
    });

    // 4. Processar o stream e retornar o texto completo
    // Nota: Para Server Actions simples, retornamos o texto completo.
    // Para streaming real via Server Actions, precisaríamos de um ReadableStream, 
    // mas o uso padrão de 'useFormState' geralmente espera um resultado completo.
    let fullResponse = '';
    for await (const chunk of completion) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        fullResponse += content;
      }
    }

    revalidatePath('/'); // Revalida o cache se necessário
    
    return { message: fullResponse, status: 'success' };
  } catch (error) {
    console.error(error);
    return { error: 'Falha ao processar a requisição' };
  }
}

// app/page.tsx
import { enviarPerguntaAction } from './actions';
import FormClient from './FormClient';

export default async function Page() {
  // Pré-carregamento de dados no Server Component
  const initialData = await obterContextoUsuario('initial_load');

  return (
    <div className="p-8">
      <h1>Chat com Contexto de Banco de Dados</h1>
      <p className="mb-4 text-gray-600">Contexto inicial carregado: {initialData}</p>
      
      {/* Componente Client que usa a Server Action */}
      <FormClient action={enviarPerguntaAction} />
    </div>
  );
}
