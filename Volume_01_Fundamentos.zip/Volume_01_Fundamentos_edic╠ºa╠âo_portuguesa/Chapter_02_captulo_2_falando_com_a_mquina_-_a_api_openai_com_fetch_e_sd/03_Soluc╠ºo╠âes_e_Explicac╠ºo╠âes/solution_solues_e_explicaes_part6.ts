/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part6.ts
// Description: Soluções e Explicações
// ==========================================

// validation.ts
import { z } from 'zod';

// Schema para a mensagem individual
const MessageSchema = z.object({
  role: z.enum(['system', 'user', 'assistant']),
  content: z.string().nullable(), // Content pode ser nulo em chunks de stream
});

// Schema para o objeto de escolha
const ChoiceSchema = z.object({
  index: z.number(),
  message: MessageSchema,
  finish_reason: z.string().nullable(),
});

// Schema principal para a resposta da OpenAI
const OpenAIResponseSchema = z.object({
  id: z.string(),
  object: z.string(),
  created: z.number(),
  model: z.string(),
  choices: z.array(ChoiceSchema),
  usage: z.object({
    prompt_tokens: z.number(),
    completion_tokens: z.number(),
    total_tokens: z.number(),
  }).optional(),
});

// Definição de erro customizado
export class ValidationError extends Error {
  details: any;
  constructor(message: string, details: any) {
    super(message);
    this.name = 'ValidationError';
    this.details = details;
  }
}

// Função segura com tratamento de "length"
export async function chamadaSeguraOpenAI(input: any): Promise<{ content: string; finishReason: string | null }> {
  try {
    // 1. Validar o input (opcional, mas boa prática)
    // 2. Realizar a chamada (simulação de input aqui é o resultado da API)
    
    // Parse do schema
    const parsedData = OpenAIResponseSchema.parse(input);

    const choice = parsedData.choices[0];
    const content = choice.message.content;
    const finishReason = choice.finish_reason;

    if (!content) {
      throw new ValidationError('Conteúdo da mensagem está vazio', { choice });
    }

    // 3. Tratamento específico para finish_reason: "length"
    if (finishReason === 'length') {
      // Lançar um erro controlado ou retornar com aviso
      // Aqui optamos por retornar com um aviso explícito para o chamador lidar
      return {
        content: content + "\n\n[AVISO: A resposta foi truncada devido ao limite de tokens.]",
        finishReason: 'length'
      };
    }

    return {
      content,
      finishReason
    };

  } catch (error) {
    if (error instanceof z.ZodError) {
      // Erro de validação do schema
      throw new ValidationError('Resposta da API inválida estruturalmente', error.errors);
    }
    // Re-lança outros erros (ex: erros de rede)
    throw error;
  }
}

// Exemplo de uso (simulado)
const respostaMock = {
  id: 'chatcmpl-123',
  object: 'chat.completion',
  created: 1677646421,
  model: 'gpt-3.5-turbo',
  choices: [{
    index: 0,
    message: {
      role: 'assistant',
      content: 'Esta é uma resposta longa que foi cortada...'
    },
    finish_reason: 'length' // O cenário do desafio
  }],
  usage: { prompt_tokens: 10, completion_tokens: 50, total_tokens: 60 }
};

// Testando a função
(async () => {
  try {
    const resultado = await chamadaSeguraOpenAI(respostaMock);
    console.log('Resultado:', resultado);
  } catch (e) {
    console.error(e);
  }
})();
