/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.tsx
// Description: Soluções e Explicações
// ==========================================

// components/ChatInterface.tsx
'use client';

import { useChat } from 'ai/react';

export default function ChatInterface() {
  // Configuração do hook useChat
  const { messages, input, handleInputChange, handleSubmit, isLoading, error } = useChat({
    api: '/api/chat', // Endpoint da API que será criado no próximo exercício
    // Desafio interativo: Enviar um system prompt inicial
    // Nota: O useChat não envia automaticamente um system prompt na primeira mensagem.
    // Uma abordagem comum é enviar o system prompt no body da requisição inicial.
    body: {
      initialSystemPrompt: 'Você deve responder de forma concisa e técnica.'
    }
  });

  return (
    <div className="flex flex-col w-full max-w-md py-24 mx-auto stretch">
      <div className="space-y-4 mb-4">
        {messages.map((m) => (
          <div key={m.id} className="whitespace-pre-wrap">
            <strong className="block text-sm text-gray-600">
              {m.role === 'user' ? 'Usuário: ' : 'Assistente: '}
            </strong>
            <div className="p-2 rounded bg-gray-100 text-black">
              {m.content}
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="text-gray-500 animate-pulse">Carregando...</div>
        )}

        {error && (
          <div className="text-red-500">Erro: {error.message}</div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Digite sua mensagem..."
          className="flex-1 p-2 border border-gray-300 rounded text-black"
          disabled={isLoading}
        />
        <button 
          type="submit" 
          className="p-2 bg-blue-500 text-white rounded disabled:bg-blue-300"
          disabled={isLoading}
        >
          Enviar
        </button>
      </form>
    </div>
  );
}
