/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.ts
// Description: Exemplo de Código Básico
// ==========================================

// app/api/chat/route.ts
// Este arquivo representa um endpoint de API no Next.js App Router.
// Ele lida com requisições HTTP POST para gerar texto usando a OpenAI.

import { NextResponse } from 'next/server'; // Framework Next.js para respostas HTTP.
import OpenAI from 'openai'; // SDK oficial da OpenAI.

/**
 * Inicializa o cliente da OpenAI.
 * CRÍTICO: A chave API deve ser armazenada em variáveis de ambiente (.env.local).
 * O SDK busca automaticamente a variável OPENAI_API_KEY.
 */
const openai = new OpenAI();

/**
 * @description Função principal para lidar com a requisição POST.
 * @param {Request} request - O objeto de requisição HTTP contendo o corpo JSON.
 * @returns {Promise<NextResponse>} - Uma resposta JSON ou erro.
 */
export async function POST(request: Request) {
  try {
    // 1. Parse do corpo da requisição para extrair o prompt do usuário.
    const { prompt } = await request.json();

    // Validação básica: Garante que o prompt não esteja vazio.
    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json(
        { error: 'Prompt inválido ou ausente.' },
        { status: 400 }
      );
    }

    // 2. Chamada assíncrona para a API da OpenAI.
    // Configuração básica do modelo 'gpt-3.5-turbo'.
    const completion = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: 'Você é um assistente útil.' },
        { role: 'user', content: prompt },
      ],
      temperature: 0.7, // Controla a criatividade (0.0 a 2.0).
      max_tokens: 150,  // Limite de palavras/tokens na resposta.
    });

    // 3. Extração do conteúdo da resposta.
    const responseContent = completion.choices[0]?.message?.content;

    // 4. Retorno da resposta para o cliente (frontend).
    return NextResponse.json(
      { 
        success: true, 
        message: responseContent 
      },
      { status: 200 }
    );

  } catch (error) {
    // Tratamento de erros (ex: timeout, falha de autenticação, limites de uso).
    console.error('Erro na API OpenAI:', error);
    
    return NextResponse.json(
      { 
        error: 'Falha ao processar a requisição com a IA.' 
      },
      { status: 500 }
    );
  }
}
