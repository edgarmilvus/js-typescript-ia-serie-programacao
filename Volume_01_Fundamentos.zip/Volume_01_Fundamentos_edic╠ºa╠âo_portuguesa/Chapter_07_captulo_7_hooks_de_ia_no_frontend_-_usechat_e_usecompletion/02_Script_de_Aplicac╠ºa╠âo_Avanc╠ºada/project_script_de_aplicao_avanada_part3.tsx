/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada_part3.tsx
// Description: Script de Aplicação Avançada
// ==========================================

// app/components/SupportDashboard.tsx
'use client';

import { useChat } from '@ai-sdk/react';
import { useCompletion } from '@ai-sdk/react';
import { useState } from 'react';

/**
 * Dashboard de Suporte Híbrido.
 * Combina Chat Interativo (useChat) e Sumarização de Logs (useCompletion).
 */
export default function SupportDashboard() {
  // --- ESTADO LOCAL ---
  const [activeTab, setActiveTab] = useState<'chat' | 'summary'>('chat');
  const [rawLogs, setRawLogs] = useState<string>('');

  // --- HOOK 1: useChat (Conversação) ---
  // Gerencia mensagens, input do usuário e streaming de resposta.
  // O hook lida automaticamente com o acúmulo de mensagens (history).
  const {
    messages: chatMessages,
    input: chatInput,
    handleInputChange: handleChatChange,
    handleSubmit: handleChatSubmit,
    isLoading: isChatLoading,
    error: chatError,
    addMetadata, // Função específica para injetar metadados na sessão
  } = useChat({
    api: '/api/chat',
    // Inicializa com uma mensagem de boas-vindas ou contexto
    initialMessages: [
      { role: 'system', content: 'Bem-vindo ao suporte técnico.' },
      { role: 'assistant', content: 'Olá! Como posso ajudar com os logs de hoje?' }
    ],
    // Callback opcional para quando a stream termina
    onFinish: (message) => {
      console.log('Mensagem final recebida:', message);
    }
  });

  // --- HOOK 2: useCompletion (Geração de Texto) ---
  // Otimizado para geração única de texto baseado em um prompt.
  const {
    completion: summaryResult,
    input: summaryInput,
    handleInputChange: handleSummaryChange,
    handleSubmit: handleSummarySubmit,
    isLoading: isSummaryLoading,
    error: summaryError,
  } = useCompletion({
    api: '/api/summarize',
  });

  // --- HANDLERS AVANÇADOS ---

  /**
   * Envia metadados personalizados para o chat antes de enviar a mensagem.
   * Isso ajuda o modelo a entender o contexto do usuário (ex: Plano Enterprise).
   */
  const handleChatSubmitWithContext = (e: React.FormEvent) => {
    e.preventDefault();
    // Adiciona metadados de contexto da sessão
    addMetadata({ 
      systemContext: 'Módulo de Pagamentos', 
      userId: 'user_12345' 
    });
    handleChatSubmit(e);
  };

  /**
   * Prepara o resumo carregando um exemplo de log para facilitar o teste.
   */
  const loadExampleLog = () => {
    const exampleLog = `
      [ERROR] 2023-10-27 10:05:00 - PaymentGateway.ts:45
      Exception: NullReferenceException on object 'transaction'.
      StackTrace: at ProcessPayment() line 45.
      Context: User ID 998 attempting payment via Stripe.
    `;
    setRawLogs(exampleLog);
    // Atualiza o input do hook de completion implicitamente se necessário,
    // mas aqui vamos controlar via estado local e setar no submit.
  };

  const handleSummarySubmitWrapper = (e: React.FormEvent) => {
    e.preventDefault();
    // Passa o texto dos logs (poderia vir de um textarea separado)
    handleSummarySubmit(e, { data: { textToSummarize: rawLogs } });
  };

  return (
    <div className="flex h-screen bg-gray-50 p-8">
      {/* Sidebar de Navegação */}
      <div className="w-64 bg-white rounded-lg shadow-sm p-4 mr-6 flex flex-col gap-2">
        <h2 className="text-xl font-bold text-gray-800 mb-4">Painel de IA</h2>
        <button 
          onClick={() => setActiveTab('chat')}
          className={`p-3 rounded text-left ${activeTab === 'chat' ? 'bg-blue-50 text-blue-700 font-semibold' : 'hover:bg-gray-100'}`}
        >
          🗨️ Chat de Suporte
        </button>
        <button 
          onClick={() => setActiveTab('summary')}
          className={`p-3 rounded text-left ${activeTab === 'summary' ? 'bg-blue-50 text-blue-700 font-semibold' : 'hover:bg-gray-100'}`}
        >
          📄 Sumarizador de Logs
        </button>
      </div>

      {/* Área Principal */}
      <div className="flex-1 bg-white rounded-lg shadow-sm flex flex-col overflow-hidden">
        
        {/* --- SEÇÃO 1: CHAT --- */}
        {activeTab === 'chat' && (
          <div className="flex flex-col h-full">
            <div className="p-4 border-b bg-gray-50 flex justify-between items-center">
              <h3 className="font-semibold">Conversa com IA</h3>
              {isChatLoading && <span className="text-sm text-blue-500 animate-pulse">Processando...</span>}
            </div>

            {/* Container de Mensagens (Scroll) */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {chatError && (
                <div className="p-2 bg-red-100 text-red-700 rounded">
                  Erro: {chatError.message}
                </div>
              )}

              {chatMessages.map((msg, index) => (
                <div 
                  key={index} 
                  className={`p-3 rounded-lg max-w-3xl ${
                    msg.role === 'user' 
                      ? 'bg-blue-600 text-white self-end ml-auto' 
                      : 'bg-gray-100 text-gray-800 self-start'
                  }`}
                >
                  <p className="text-sm font-semibold mb-1 uppercase opacity-70">
                    {msg.role === 'user' ? 'Você' : 'Assistente IA'}
                  </p>
                  <div className="whitespace-pre-wrap">{msg.content}</div>
                </div>
              ))}
            </div>

            {/* Input do Chat */}
            <form onSubmit={handleChatSubmitWithContext} className="p-4 border-t bg-white">
              <div className="flex gap-2">
                <input
                  className="flex-1 border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={chatInput}
                  onChange={handleChatChange}
                  placeholder="Descreva o erro que você está vendo..."
                />
                <button 
                  type="submit" 
                  disabled={isChatLoading}
                  className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50"
                >
                  Enviar
                </button>
              </div>
              <p className="text-xs text-gray-400 mt-2">
                Contexto injetado: Módulo de Pagamentos (Metadados via hook)
              </p>
            </form>
          </div>
        )}

        {/* --- SEÇÃO 2: SUMARIZAÇÃO --- */}
        {activeTab === 'summary' && (
          <div className="flex flex-col h-full">
            <div className="p-4 border-b bg-gray-50 flex justify-between items-center">
              <h3 className="font-semibold">Análise de Logs</h3>
              <button 
                onClick={loadExampleLog} 
                className="text-xs bg-gray-200 px-2 py-1 rounded hover:bg-gray-300"
              >
                Carregar Exemplo
              </button>
            </div>

            <div className="flex-1 flex flex-row divide-x">
              {/* Input de Logs (Lado Esquerdo) */}
              <div className="w-1/2 p-4 flex flex-col">
                <label className="font-semibold mb-2 text-sm text-gray-700">Logs Brutos</label>
                <textarea
                  className="flex-1 w-full border rounded p-3 font-mono text-xs resize-none focus:outline-none focus:ring-2 focus:ring-green-500"
                  value={rawLogs}
                  onChange={(e) => setRawLogs(e.target.value)}
                  placeholder="Cole aqui os logs de erro..."
                />
              </div>

              {/* Output da IA (Lado Direito) */}
              <div className="w-1/2 p-4 flex flex-col bg-gray-50">
                <label className="font-semibold mb-2 text-sm text-gray-700">Resumo Gerado</label>
                <div className="flex-1 border bg-white rounded p-3 overflow-y-auto">
                  {isSummaryLoading ? (
                    <div className="text-gray-400 animate-pulse">Analisando logs...</div>
                  ) : summaryResult ? (
                    <div className="whitespace-pre-wrap text-sm">{summaryResult}</div>
                  ) : (
                    <div className="text-gray-400 italic">Aguardando submissão...</div>
                  )}
                </div>
                
                <form onSubmit={handleSummarySubmitWrapper} className="mt-4">
                  <button 
                    type="submit" 
                    disabled={isSummaryLoading || !rawLogs}
                    className="w-full bg-green-600 text-white py-2 rounded hover:bg-green-700 disabled:opacity-50"
                  >
                    {isSummaryLoading ? 'Processando...' : 'Gerar Resumo Executivo'}
                  </button>
                </form>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
