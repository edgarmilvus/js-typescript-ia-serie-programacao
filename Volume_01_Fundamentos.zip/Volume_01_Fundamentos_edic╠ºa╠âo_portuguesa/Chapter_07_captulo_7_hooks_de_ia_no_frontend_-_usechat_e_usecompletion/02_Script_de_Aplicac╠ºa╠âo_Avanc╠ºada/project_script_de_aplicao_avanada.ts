/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.ts
// Description: Script de Aplicação Avançada
// ==========================================

// app/api/chat/route.ts
import { openai } from '@ai-sdk/openai';
import { streamText } from 'ai';

// Permitir streaming de resposta
export const runtime = 'edge';

/**
 * Rota POST para o chat de suporte.
 * Recebe uma mensagem do usuário e retorna uma stream de texto do modelo.
 * Adiciona metadados de contexto para melhorar a resposta do modelo.
 */
export async function POST(req: Request) {
  const { messages, metadata } = await req.json();

  // Exemplo de uso de metadados: O modelo pode usar isso para contextualizar
  // a resposta (ex: "O usuário está reportando um bug no módulo de faturamento").
  const contextMessage = {
    role: 'system',
    content: `Você é um assistente de suporte técnico. O usuário está analisando o sistema: ${metadata?.systemContext || 'Geral'}. Responda de forma clara e técnica.`,
  };

  const result = await streamText({
    model: openai('gpt-4-turbo-preview'),
    messages: [contextMessage, ...messages],
  });

  return result.toAIStreamResponse();
}
