/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part5.tsx
// Description: Soluções e Explicações
// ==========================================

import React from 'react';
import { useChat } from '@ai-sdk/react';

export function ResilientChat() {
  // Hook configurado para tratar erros
  const { 
    messages, 
    input, 
    handleInputChange, 
    handleSubmit, 
    isLoading, 
    error, 
    reload, 
    stop 
  } = useChat({
    api: '/api/chat-invalido', // URL intencionalmente errada para teste de erro
    // O hook captura erros automaticamente e popula a propriedade 'error'
  });

  // Função de envio com validação de input
  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    // Validação de segurança no cliente
    if (!input || input.trim().length === 0) {
      alert('Por favor, digite uma mensagem antes de enviar.');
      return;
    }

    handleSubmit(e);
  };

  // Função para tentar novamente (reenvia a última mensagem do usuário)
  const handleRetry = () => {
    // A função 'reload' do hook reenvia o último contexto (última mensagem do usuário)
    reload();
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px', fontFamily: 'sans-serif' }}>
      <h3>Chat Resiliente</h3>
      
      {/* Exibição do Histórico */}
      <div style={{ border: '1px solid #ddd', padding: '10px', height: '300px', overflowY: 'auto', marginBottom: '10px' }}>
        {messages.map((m) => (
          <div key={m.id} style={{ marginBottom: '5px', color: m.role === 'user' ? 'blue' : 'green' }}>
            <strong>{m.role.toUpperCase()}:</strong> {m.content}
          </div>
        ))}
      </div>

      {/* Tratamento de Erro Específico */}
      {error && (
        <div style={{ 
          backgroundColor: '#ffebee', 
          border: '1px solid #f44336', 
          color: '#c62828', 
          padding: '15px', 
          marginBottom: '15px',
          borderRadius: '4px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <div>
            <strong>Erro de Conexão:</strong> Não foi possível conectar ao servidor.
            <br />
            <small>{error.message}</small>
          </div>
          <button 
            onClick={handleRetry} 
            style={{ background: '#d32f2f', color: 'white', border: 'none', padding: '8px 12px', cursor: 'pointer' }}
          >
            Tentar Novamente
          </button>
        </div>
      )}

      {/* Formulário */}
      <form onSubmit={onSubmit} style={{ display: 'flex', gap: '10px' }}>
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          disabled={isLoading} // Desabilita durante carregamento e erro
          style={{ flex: 1, padding: '8px' }}
        />
        
        {isLoading ? (
          <button type="button" onClick={stop} style={{ background: 'orange' }}>
            Cancelar
          </button>
        ) : (
          <button type="submit" disabled={!!error}> 
            {/* Botão de envio pode ser bloqueado se houver erro crítico, ou permitir novo envio */}
            Enviar
          </button>
        )}
      </form>
    </div>
  );
}
