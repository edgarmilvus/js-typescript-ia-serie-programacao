/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part2.tsx
// Description: Soluções e Explicações
// ==========================================

import React, { useState } from 'react';
import { useCompletion } from '@ai-sdk/react';

export function TextSummarizer() {
  // Estado local para os parâmetros ajustáveis
  const [temperature, setTemperature] = useState(0.7);
  const [maxTokens, setMaxTokens] = useState(500);
  const [inputText, setInputText] = useState('');

  // Hook useCompletion para geração de texto único
  const { 
    completion, 
    input, 
    handleInputChange, 
    complete, 
    isLoading, 
    stop 
  } = useCompletion({
    api: '/api/summarize',
    // Passagem inicial de parâmetros (pode ser sobrescrita na chamada manual)
    body: {
      temperature,
      maxTokens,
    }
  });

  // Função para acionar a geração com parâmetros atuais
  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    // O hook 'complete' aceita um segundo argumento para sobrescrever o corpo da requisição
    await complete(input, {
      body: {
        temperature,
        maxTokens,
        customPrompt: 'Resuma o texto abaixo de forma concisa:'
      }
    });
  };

  // Função para limpar o estado
  const handleClear = () => {
    setInputText('');
    // O hook não limpa 'completion' automaticamente, precisamos limpar a entrada e o estado local se necessário
    // No entanto, o hook não expõe uma função 'reset' padrão, então gerenciamos a entrada manualmente.
    // Para limpar a exibição, podemos usar o estado local ou manipular o DOM.
    // Uma abordagem comum é controlar o input via estado local e limpar o completion (se disponível) ou apenas limpar o input.
    // Nota: 'completion' é acumulativo se o mesmo input for usado? Não, ele substitui.
    // Para resetar visualmente o completion, podemos usar um truque de key ou estado extra.
    // Aqui, vamos apenas limpar o input e a saída visual se o hook permitir, ou apenas o input.
    // O hook 'useCompletion' não tem uma propriedade 'reset' pública padrão, então focamos na UX.
    window.location.reload(); // Solução simples para resetar o estado do hook
  };

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '20px' }}>
      <h2>Gerador de Resumos</h2>
      
      <div style={{ marginBottom: '20px', padding: '10px', background: '#f5f5f5' }}>
        <label>
          Temperature: {temperature}
          <input 
            type="range" min="0" max="1" step="0.1" 
            value={temperature} 
            onChange={(e) => setTemperature(parseFloat(e.target.value))} 
            disabled={isLoading}
          />
        </label>
        <br />
        <label>
          Max Tokens: {maxTokens}
          <input 
            type="range" min="100" max="2000" step="100" 
            value={maxTokens} 
            onChange={(e) => setMaxTokens(parseInt(e.target.value))} 
            disabled={isLoading}
          />
        </label>
      </div>

      <form onSubmit={handleGenerate}>
        <div style={{ marginBottom: '10px' }}>
          <label htmlFor="source-text">Texto para resumir:</label>
          <textarea
            id="source-text"
            value={input}
            onChange={handleInputChange} // O hook lida com o input se vinculado
            rows={6}
            style={{ width: '100%', padding: '8px' }}
            placeholder="Cole o texto longo aqui..."
          />
        </div>

        <div style={{ gap: '10px', display: 'flex' }}>
          <button type="submit" disabled={isLoading || !input.trim()}>
            {isLoading ? 'Gerando...' : 'Gerar Resumo'}
          </button>
          
          {isLoading && (
            <button type="button" onClick={stop} style={{ background: 'orange' }}>
              Cancelar
            </button>
          )}

          <button type="button" onClick={handleClear} style={{ background: '#6c757d' }}>
            Limpar
          </button>
        </div>
      </form>

      {/* Área de Exibição do Resultado */}
      <div style={{ marginTop: '20px', border: '1px solid #ddd', padding: '15px', minHeight: '100px' }}>
        <h3>Resumo Gerado:</h3>
        {isLoading && <span style={{ color: '#999' }}>Digitando...</span>}
        {/* O completion é atualizado via streaming */}
        <p style={{ whiteSpace: 'pre-wrap' }}>{completion}</p>
      </div>
    </div>
  );
}
