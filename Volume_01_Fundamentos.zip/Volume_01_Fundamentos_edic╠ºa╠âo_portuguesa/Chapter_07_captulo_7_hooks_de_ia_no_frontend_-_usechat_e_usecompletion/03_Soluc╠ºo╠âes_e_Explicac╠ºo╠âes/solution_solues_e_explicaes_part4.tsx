/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.tsx
// Description: Soluções e Explicações
// ==========================================

import React, { useState, useEffect } from 'react';
import { useChat } from '@ai-sdk/react';

type StatusPhase = 'idle' | 'typing' | 'querying_db' | 'responding';

export function SmartSupportChat() {
  // Estado customizado para o fluxo de processamento inteligente
  const [statusPhase, setStatusPhase] = useState<StatusPhase>('idle');

  const { messages, input, handleInputChange, handleSubmit, isLoading, stop } = useChat({
    api: '/api/chat',
    // O hook chama onFinish quando o stream termina
    onFinish: (message) => {
      // Aqui poderíamos salvar no banco de dados ou analytics
      console.log('Mensagem finalizada:', message);
    },
  });

  // Efeito para detectar palavras-chave e simular consulta ao DB
  useEffect(() => {
    if (isLoading) {
      // Se está carregando, verificamos a última mensagem do usuário
      const lastUserMessage = messages[messages.length - 1];
      if (lastUserMessage && lastUserMessage.role === 'user') {
        const content = lastUserMessage.content.toLowerCase();
        
        if (content.includes('preço') || content.includes('disponibilidade')) {
          // Inicia a simulação de consulta
          setStatusPhase('querying_db');
          
          // Simula um delay de consulta (ex: 1.5 segundos)
          const timer = setTimeout(() => {
            setStatusPhase('responding');
          }, 1500);

          return () => clearTimeout(timer);
        } else {
          setStatusPhase('typing');
        }
      }
    } else {
      setStatusPhase('idle');
    }
  }, [isLoading, messages]);

  const customHandleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    
    // Reset do status antes de enviar
    setStatusPhase('typing');
    handleSubmit(e);
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px' }}>
      {/* Indicador de Status Dinâmico */}
      <div style={{ padding: '10px', background: '#eef', marginBottom: '10px', borderRadius: '4px', minHeight: '20px' }}>
        Status: {statusPhase === 'idle' && 'Aguardando...'}
        {statusPhase === 'typing' && 'Digitando...'}
        {statusPhase === 'querying_db' && (
          <span style={{ color: 'blue', fontWeight: 'bold' }}>
            🔍 Consultando base de dados...
          </span>
        )}
        {statusPhase === 'responding' && 'Processando resposta...'}
      </div>

      {/* Histórico de Mensagens */}
      <div style={{ border: '1px solid #ccc', height: '350px', overflowY: 'auto', padding: '10px' }}>
        {messages.map((m) => (
          <div key={m.id} style={{ marginBottom: '8px', textAlign: m.role === 'user' ? 'right' : 'left' }}>
            <div style={{ 
              display: 'inline-block', 
              padding: '8px 12px', 
              borderRadius: '8px', 
              background: m.role === 'user' ? '#007bff' : '#f8f9fa',
              color: m.role === 'user' ? 'white' : 'black'
            }}>
              {m.content}
            </div>
          </div>
        ))}
      </div>

      {/* Controles */}
      <form onSubmit={customHandleSubmit} style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Pergunte sobre preços ou produtos..."
          disabled={isLoading}
          style={{ flex: 1 }}
        />
        <button type="submit" disabled={isLoading || !input.trim()}>
          Enviar
        </button>
        {isLoading && (
          <button type="button" onClick={stop} style={{ background: 'orange' }}>
            Parar
          </button>
        )}
      </form>
    </div>
  );
}
