/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.tsx
// Description: Soluções e Explicações
// ==========================================

import React from 'react';
import { useChat } from '@ai-sdk/react';

export function ChatInterface() {
  // 1. Inicialização do hook useChat
  // 'api/chat' é a rota da API definida no requisito.
  // 'onError' é opcional mas recomendado para logs.
  const { messages, input, handleInputChange, handleSubmit, isLoading, error } = useChat({
    api: '/api/chat',
  });

  // Função de envio customizada para incluir metadados
  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    // Validação básica para evitar envio de texto vazio
    if (!input.trim()) return;

    // O hook 'useChat' permite passar opções adicionais no submit
    handleSubmit(e, {
      data: {
        // Metadados exigidos pelo exercício
        userId: 'user-123',
        session: 'support-chat',
      },
    });
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px', fontFamily: 'sans-serif' }}>
      {/* Área de exibição de erros */}
      {error && (
        <div style={{ color: 'red', marginBottom: '10px', padding: '10px', border: '1px solid red' }}>
          Erro: {error.message}
        </div>
      )}

      {/* Área de rolagem do histórico de mensagens */}
      <div 
        style={{ 
          height: '400px', 
          overflowY: 'auto', 
          border: '1px solid #ccc', 
          padding: '10px', 
          marginBottom: '10px',
          display: 'flex',
          flexDirection: 'column',
          gap: '8px'
        }}
      >
        {messages.map((m) => (
          <div 
            key={m.id} 
            style={{ 
              alignSelf: m.role === 'user' ? 'flex-end' : 'flex-start',
              backgroundColor: m.role === 'user' ? '#007bff' : '#e9ecef',
              color: m.role === 'user' ? 'white' : 'black',
              padding: '8px 12px',
              borderRadius: '12px',
              maxWidth: '80%',
            }}
          >
            <strong>{m.role === 'user' ? 'Você' : 'IA'}: </strong>
            {/* O conteúdo da mensagem é atualizado em tempo real via streaming */}
            {m.content}
          </div>
        ))}
        
        {/* Indicador visual de carregamento (streaming ativo) */}
        {isLoading && (
          <div style={{ alignSelf: 'flex-start', color: '#666', fontStyle: 'italic' }}>
            Pensando...
          </div>
        )}
      </div>

      {/* Formulário de entrada */}
      <form onSubmit={onSubmit} style={{ display: 'flex', gap: '10px' }}>
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Digite sua mensagem..."
          disabled={isLoading} // 3. Impede envio múltiplo
          style={{ flex: 1, padding: '10px', borderRadius: '4px', border: '1px solid #ccc' }}
        />
        <button 
          type="submit" 
          disabled={isLoading || !input.trim()}
          style={{ padding: '10px 20px', cursor: 'pointer' }}
        >
          Enviar
        </button>
      </form>
    </div>
  );
}
