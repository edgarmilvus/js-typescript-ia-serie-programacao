/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.tsx
// Description: Soluções e Explicações
// ==========================================

import React, { useState } from 'react';
import { useChat } from '@ai-sdk/react';
import { Message } from 'ai'; // Tipagem do SDK

export function MultimodalChat() {
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: '/api/chat', // Assumindo que a rota suporta multimodalidade
  });

  // Estado para armazenar a imagem em Base64 antes do envio
  const [imageBase64, setImageBase64] = useState<string | null>(null);

  // Função para converter arquivo para Base64
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      // O resultado é uma string "data:image/jpeg;base64,..."
      setImageBase64(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Função de envio customizada para lidar com multimodalidade
  const handleMultimodalSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!input.trim() && !imageBase64) return;

    // Construção da mensagem multimodal
    const content = [];
    
    // Adiciona texto se existir
    if (input.trim()) {
      content.push({ type: 'text', text: input });
    }

    // Adiciona imagem se existir
    if (imageBase64) {
      content.push({ type: 'image', image: imageBase64 });
    }

    // O hook useChat aceita uma mensagem estruturada via 'data'
    // Nota: O SDK 'ai' espera que o backend aceite esse formato.
    // O hook 'useChat' envia as mensagens atuais + a nova mensagem.
    // Para enviar multimodal, passamos a mensagem formatada no evento.
    
    // Uma abordagem comum é usar 'onSubmit' com 'options' para enviar dados extras,
    // mas o 'useChat' gerencia o array 'messages'. 
    // Para enviar uma imagem, geralmente adicionamos ao array 'messages' manualmente ou usamos uma lógica de backend.
    
    // AQUI ESTÁ A LÓGICA CRÍTICA:
    // O 'useChat' não suporta nativamente anexar arquivos diretamente no 'handleSubmit' padrão sem uma lógica de backend específica.
    // No entanto, podemos enviar o Base64 como parte do corpo da requisição ou simular a mensagem.
    
    // Vamos assumir que o backend aceita um corpo com 'image' e 'prompt'.
    // Mas o exercício pede para usar o hook corretamente.
    // O 'useChat' envia o array 'messages'. Precisamos adicionar uma mensagem com conteúdo multimodal a esse array.
    
    // Como o hook não expõe um 'addMessage' facilmente para multimodalidade complexa, 
    // usaremos uma abordagem onde 'handleSubmit' envia o input de texto, e a imagem é enviada via 'body' extra.
    // Porém, o ideal para GPT-4V é enviar a mensagem com o array de partes.
    
    // CORREÇÃO DE LÓGICA PARA O EXERCÍCIO:
    // O hook 'useChat' atualiza o estado interno. Vamos limpar o input e a imagem localmente após o envio.
    // O backend deve ser configurado para ler o corpo da requisição (que incluirá a imagem base64).
    
    handleSubmit(e, {
      data: {
        image: imageBase64, // Envia a imagem como metadado extra no corpo
        // O texto já está sendo enviado pelo hook via 'input'
      }
    });

    // Limpa o preview da imagem após o envio
    setImageBase64(null);
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px' }}>
      <div style={{ border: '1px solid #ccc', height: '300px', overflowY: 'auto', padding: '10px', marginBottom: '10px' }}>
        {messages.map((m) => (
          <div key={m.id} style={{ marginBottom: '10px', textAlign: m.role === 'user' ? 'right' : 'left' }}>
            <strong>{m.role}: </strong>
            <div>
              {/* Renderização de texto */}
              {typeof m.content === 'string' ? (
                <p>{m.content}</p>
              ) : (
                /* Se o conteúdo for um array (multimodal), renderiza partes */
                m.content.map((part, index) => (
                  <div key={index}>
                    {part.type === 'text' && <p>{part.text}</p>}
                    {/* A IA pode retornar imagens também, se suportado */}
                    {part.type === 'image' && <img src={part.image} alt="IA response" style={{ maxWidth: '100%' }} />}
                  </div>
                ))
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Preview da Imagem */}
      {imageBase64 && (
        <div style={{ marginBottom: '10px' }}>
          <img src={imageBase64} alt="Preview" style={{ maxHeight: '100px', border: '1px dashed #999' }} />
          <button onClick={() => setImageBase64(null)} type="button" style={{ color: 'red', background: 'none', border: 'none', cursor: 'pointer' }}>
            Remover Imagem
          </button>
        </div>
      )}

      <form onSubmit={handleMultimodalSubmit} style={{ display: 'flex', gap: '10px' }}>
        <input
          type="file"
          accept="image/*"
          onChange={handleFileUpload}
          disabled={isLoading}
        />
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Pergunte sobre a imagem..."
          disabled={isLoading}
          style={{ flex: 1 }}
        />
        <button type="submit" disabled={isLoading || (!input.trim() && !imageBase64)}>
          Enviar
        </button>
      </form>
    </div>
  );
}
