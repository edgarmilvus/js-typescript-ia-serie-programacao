/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.tsx
// Description: Exemplo de Código Básico
// ==========================================

// Arquivo: components/CopilotDashboard.tsx
// Descrição: Componente principal que demonstra o uso dos hooks useChat e useCompletion.

import React, { useState } from 'react';
import { useChat } from '@ai-sdk/react';
import { useCompletion } from '@ai-sdk/react';

/**
 * @description Componente de dashboard que integra dois hooks de IA distintos.
 * Contexto: SaaS de Produtividade.
 */
export default function CopilotDashboard() {
  // ========================================================================
  // 1. HOOK USECHAT: Configuração para Interface Conversacional
  // ========================================================================
  
  // O hook useChat gerencia o estado das mensagens, o input do usuário e o envio.
  // Ele lida com o streaming de resposta automaticamente.
  const {
    messages,      // Array de objetos { id, role, content }
    input,         // String do input do usuário
    handleInputChange, // Handler para atualizar o 'input'
    handleSubmit,  // Handler para enviar a mensagem (chama a API internamente)
    isLoading,     // Booleano indicando se a resposta está carregando
    error          // Objeto de erro se a requisição falhar
  } = useChat({
    // A API deve estar configurada em /api/chat
    api: '/api/chat',
    // Opcional: Adicionar metadados para o contexto do backend
    body: { userId: 'user_123' }
  });

  // ========================================================================
  // 2. HOOK USECOMPLETION: Configuração para Geração de Texto Único
  // ========================================================================

  // O hook useCompletion é otimizado para tarefas de geração única (ex: resumo, título).
  // Ele não mantém histórico de mensagens, apenas o prompt inicial e o resultado.
  const {
    completion,    // String contendo o texto gerado (atualizado via streaming)
    input: promptInput, // Input específico para a geração de completion
    handleInputChange: handlePromptChange,
    handleSubmit: handlePromptSubmit,
    isLoading: isGenerating,
    error: completionError
  } = useCompletion({
    api: '/api/completion',
    // Opcional: Configurações específicas do modelo
    body: { 
      temperature: 0.7 
    }
  });

  // ========================================================================
  // 3. ESTADO LOCAL: Controle de Abas da UI
  // ========================================================================
  
  const [activeTab, setActiveTab] = useState<'chat' | 'completion'>('chat');

  // ========================================================================
  // 4. RENDERIZAÇÃO DA UI
  // ========================================================================

  return (
    <div style={{ fontFamily: 'sans-serif', maxWidth: '800px', margin: '0 auto', padding: '20px' }}>
      <h1>Copiloto de Conteúdo</h1>
      
      {/* Seletor de Abas */}
      <div style={{ marginBottom: '20px' }}>
        <button 
          onClick={() => setActiveTab('chat')}
          style={{ 
            marginRight: '10px', 
            fontWeight: activeTab === 'chat' ? 'bold' : 'normal' 
          }}
        >
          Chat Interativo
        </button>
        <button 
          onClick={() => setActiveTab('completion')}
          style={{ fontWeight: activeTab === 'completion' ? 'bold' : 'normal' }}
        >
          Gerador de Títulos
        </button>
      </div>

      {/* SEÇÃO 1: CHAT (useChat) */}
      {activeTab === 'chat' && (
        <div style={{ border: '1px solid #ccc', padding: '20px', borderRadius: '8px' }}>
          <h2>Conversa com IA</h2>
          
          {/* Área de Exibição das Mensagens */}
          <div style={{ 
            height: '300px', 
            overflowY: 'auto', 
            border: '1px solid #eee', 
            marginBottom: '10px', 
            padding: '10px' 
          }}>
            {messages.length === 0 && <p style={{ color: '#999' }}>Inicie uma conversa...</p>}
            
            {messages.map((m) => (
              <div key={m.id} style={{ marginBottom: '8px' }}>
                <strong style={{ color: m.role === 'user' ? 'blue' : 'green' }}>
                  {m.role === 'user' ? 'Você: ' : 'IA: '}
                </strong>
                <span>{m.content}</span>
              </div>
            ))}
            
            {isLoading && (
              <div style={{ color: 'orange' }}>IA está digitando...</div>
            )}
          </div>

          {/* Formulário de Input */}
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              value={input}
              onChange={handleInputChange}
              placeholder="Digite sua mensagem..."
              style={{ width: '70%', padding: '8px', marginRight: '5px' }}
              disabled={isLoading}
            />
            <button type="submit" disabled={isLoading || !input.trim()}>
              Enviar
            </button>
          </form>
          
          {error && <p style={{ color: 'red' }}>Erro: {error.message}</p>}
        </div>
      )}

      {/* SEÇÃO 2: COMPLETION (useCompletion) */}
      {activeTab === 'completion' && (
        <div style={{ border: '1px solid #ccc', padding: '20px', borderRadius: '8px', marginTop: '20px' }}>
          <h2>Gerador de Títulos</h2>
          <p style={{ fontSize: '0.9em', color: '#555' }}>
            Descreva o tópico e gere um título impactante.
          </p>

          {/* Área de Exibição do Resultado */}
          <div style={{ 
            minHeight: '100px', 
            border: '1px solid #eee', 
            marginBottom: '10px', 
            padding: '10px',
            backgroundColor: '#f9f9f9'
          }}>
            <strong>Resultado: </strong>
            {completion || <span style={{ color: '#999' }}>Aguardando geração...</span>}
          </div>

          {/* Formulário de Input */}
          <form onSubmit={handlePromptSubmit}>
            <input
              type="text"
              value={promptInput}
              onChange={handlePromptChange}
              placeholder="Ex: Artigo sobre sustentabilidade em startups"
              style={{ width: '70%', padding: '8px', marginRight: '5px' }}
              disabled={isGenerating}
            />
            <button type="submit" disabled={isGenerating || !promptInput.trim()}>
              {isGenerating ? 'Gerando...' : 'Gerar Título'}
            </button>
          </form>

          {completionError && <p style={{ color: 'red' }}>Erro: {completionError.message}</p>}
        </div>
      )}
    </div>
  );
}
