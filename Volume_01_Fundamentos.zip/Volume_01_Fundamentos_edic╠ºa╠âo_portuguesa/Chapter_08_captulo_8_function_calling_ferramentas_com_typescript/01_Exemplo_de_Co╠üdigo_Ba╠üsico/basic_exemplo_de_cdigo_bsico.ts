/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.ts
// Description: Exemplo de Código Básico
// ==========================================

// agent.ts
import { Tool } from "@langchain/core/tools";
import { z } from "zod";

/**
 * 1. DEFINIÇÃO DO ESQUEMA (ZOD)
 * Define a estrutura segura dos argumentos que a ferramenta espera receber.
 * Isso garante que o LLM (ou o usuário) não envie dados malformados.
 */
const temperatureSchema = z.object({
  value: z.number().describe("O valor numérico da temperatura a ser convertida"),
  unit: z.enum(["celsius", "fahrenheit", "kelvin"]).describe("A unidade de entrada (ex: celsius)"),
  target: z.enum(["celsius", "fahrenheit", "kelvin"]).describe("A unidade de destino para conversão")
});

/**
 * 2. CRIAÇÃO DA FERRAMENTA (TOOL)
 * Encapsula a lógica de negócios em uma classe que o LangChain pode orquestrar.
 * A lógica real (conversão matemática) é executada aqui.
 */
class TemperatureConverterTool extends Tool {
  name = "temperature_converter";
  description = "Útil para converter temperaturas entre Celsius, Fahrenheit e Kelvin.";

  // O método _call é o núcleo da execução da ferramenta.
  // Ele recebe os argumentos validados pelo Schema do Zod.
  protected async _call(input: z.infer<typeof temperatureSchema>) {
    const { value, unit, target } = input;

    // Lógica de conversão básica (Hello World Logic)
    let result: number;

    // Normalização: Primeiro convertemos tudo para Celsius como base intermediária
    let celsiusValue: number;
    if (unit === "fahrenheit") {
      celsiusValue = (value - 32) * 5 / 9;
    } else if (unit === "kelvin") {
      celsiusValue = value - 273.15;
    } else {
      celsiusValue = value; // Já é Celsius
    }

    // Segunda etapa: Conversão do Celsius para o alvo desejado
    if (target === "fahrenheit") {
      result = (celsiusValue * 9 / 5) + 32;
    } else if (target === "kelvin") {
      result = celsiusValue + 273.15;
    } else {
      result = celsiusValue;
    }

    // Retorna o resultado formatado como string (padrão do LangChain Tool)
    return `Resultado: ${result.toFixed(2)} ${target.charAt(0).toUpperCase() + target.slice(1)}`;
  }
}

/**
 * 3. SIMULAÇÃO DO AGENTE (HELLO WORLD)
 * Como este é um exemplo básico, simularemos a etapa de orquestração
 * onde o LLM decide chamar a ferramenta.
 * Em uma aplicação real, isso seria feito via `createToolCallingAgent` ou `LLMWithTools`.
 */
async function main() {
  console.log("🚀 Iniciando Agente de Conversão de Temperatura...\n");

  // Instanciamos a ferramenta
  const converterTool = new TemperatureConverterTool();

  // Simulamos a saída do LLM (que normalmente viria de uma chamada de API)
  // O LLM "decidiu" chamar a ferramenta `temperature_converter` com estes argumentos:
  const llmOutput = {
    tool: "temperature_converter",
    args: {
      value: 25,
      unit: "celsius",
      target: "fahrenheit"
    }
  };

  console.log(`📝 Entrada do LLM (Simulada): ${JSON.stringify(llmOutput)}`);

  // O agente (nossa função main) executa a ferramenta com os argumentos fornecidos
  try {
    const resultado = await converterTool.invoke(llmOutput.args);
    console.log(`✅ Resultado da Ferramenta: ${resultado}`);
  } catch (error) {
    console.error("❌ Erro na execução da ferramenta:", error);
  }
}

// Executa a função principal
main();
