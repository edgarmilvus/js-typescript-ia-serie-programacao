/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.ts
// Description: Script de Aplicação Avançada
// ==========================================

// app/actions/analyze-feedback.ts
'use server';

import { z } from 'zod';
import { DynamicStructuredTool } from '@langchain/core/tools';
import { ChatOpenAI } from '@langchain/openai';
import { AIMessage, BaseMessage, HumanMessage } from '@langchain/core/messages';
import { ChatPromptTemplate } from '@langchain/core/prompts';

/**
 * 1. DEFINIÇÃO DO ESQUEMA DE VALIDAÇÃO (ZOD)
 * 
 * O Zod garante que os dados recebidos do formulário front-end tenham a estrutura
 * exata esperada. Além da validação, inferimos automaticamente o tipo TypeScript
 * 'FeedbackInput' a partir do schema, eliminando a necessidade de tipagem manual redundante.
 */
const FeedbackSchema = z.object({
    customerEmail: z.string().email('Deve ser um e-mail válido'),
    feedbackText: z.string().min(10, 'O feedback deve ter pelo menos 10 caracteres'),
    urgency: z.enum(['low', 'medium', 'high']).default('low'),
});

type FeedbackInput = z.infer<typeof FeedbackSchema>;

/**
 * 2. DEFINIÇÃO DAS FERRAMENTAS (TOOLS)
 * 
 * Cada classe de ferramenta segue o SRP. Elas não sabem sobre o LLM, apenas executam
 * sua tarefa específica e retornam uma string de resultado.
 */

/**
 * Ferramenta para registrar um ticket de suporte no sistema.
 * Simula uma chamada a um banco de dados ou API externa.
 */
const createSupportTicket = async (email: string, issue: string, priority: string) => {
    // Simulação de persistência (ex: Prisma, SQL)
    console.log(`[DB] Criando ticket para ${email}...`);
    const ticketId = Math.floor(Math.random() * 10000);
    
    // Lógica de negócio: Alta urgência envia notificação imediata
    if (priority === 'high') {
        console.log(`[ALERT] Disparando notificação para gestores sobre ticket #${ticketId}`);
    }

    return JSON.stringify({ 
        success: true, 
        ticketId, 
        message: `Ticket #${ticketId} criado com prioridade ${priority}` 
    });
};

/**
 * Ferramenta para enviar e-mail de agradecimento ou follow-up.
 * Simula um serviço de e-mail (ex: Resend, SendGrid).
 */
const sendEmail = async (to: string, type: 'thanks' | 'followup') => {
    console.log(`[EMAIL] Enviando e-mail '${type}' para ${to}...`);
    return JSON.stringify({ success: true, message: `E-mail ${type} enviado para ${to}` });
};

/**
 * 3. CONFIGURAÇÃO DAS FERRAMENTAS PARA O LLM (LangChain)
 * 
 * Aqui definimos o esquema (schema) que o LLM deve usar para chamar a função
 * e a função de execução (func) que será chamada após a decisão do LLM.
 */

const ticketTool = new DynamicStructuredTool({
    name: 'create_support_ticket',
    description: 'Cria um ticket de suporte para problemas técnicos ou reclamações.',
    schema: z.object({
        email: z.string().email(),
        issue: z.string().describe('Descrição resumida do problema reportado'),
        priority: z.string().describe('Nível de urgência: low, medium ou high'),
    }),
    func: async ({ email, issue, priority }) => createSupportTicket(email, issue, priority),
});

const emailTool = new DynamicStructuredTool({
    name: 'send_customer_email',
    description: 'Envia um e-mail de resposta ao cliente.',
    schema: z.object({
        to: z.string().email(),
        type: z.enum(['thanks', 'followup']).describe('O tipo de e-mail a ser enviado'),
    }),
    func: async ({ to, type }) => sendEmail(to, type),
});

/**
 * 4. ORQUESTRADOR PRINCIPAL (SERVER ACTION)
 * 
 * Esta é a função principal exportada para o componente do Next.js.
 * Ela orquestra: Validação -> Inicialização do LLM -> Decisão -> Execução.
 */
export async function analyzeFeedbackAction(formData: FormData) {
    try {
        // A. Extração e Validação dos Dados
        const rawData = {
            customerEmail: formData.get('email'),
            feedbackText: formData.get('feedback'),
            urgency: formData.get('urgency'),
        };

        const parsedData = FeedbackSchema.safeParse(rawData);

        if (!parsedData.success) {
            return { 
                success: false, 
                error: 'Dados inválidos', 
                details: parsedData.error.flatten() 
            };
        }

        const { customerEmail, feedbackText, urgency } = parsedData.data;

        // B. Inicialização do Modelo LLM
        // Usamos um modelo leve e eficiente para tarefas de roteamento
        const model = new ChatOpenAI({ 
            model: 'gpt-4o-mini', 
            temperature: 0.1 // Baixa temperatura para decisões determinísticas
        }).bindTools([ticketTool, emailTool]);

        // C. Construção do Prompt
        // O prompt instrui o LLM a agir como um analista de suporte inteligente
        const prompt = ChatPromptTemplate.fromMessages([
            ['system', `
                Você é um assistente inteligente de suporte ao cliente.
                Analise o feedback do cliente e decida qual ação tomar.
                
                Regras:
                1. Se o feedback for negativo (reclamação), crie um ticket de suporte.
                2. Se o feedback for positivo, envie um e-mail de agradecimento.
                3. Se o feedback for neutro ou simples sugestão, envie um e-mail de follow-up.
                
                Contexto do Cliente: ${customerEmail} (Urgência: ${urgency})
            `],
            ['human', `Feedback do cliente: "${feedbackText}"`]
        ]);

        // D. Invocação do LLM com Ferramentas
        const chain = prompt.pipe(model);
        const response = await chain.invoke({});

        // E. Processamento da Resposta (Tool Calling)
        // Se o LLM decidir chamar uma ferramenta, ele retornará um AIMessage com tool_calls
        const aiMessage = response as AIMessage;

        if (aiMessage.tool_calls && aiMessage.tool_calls.length > 0) {
            // O LangChain executa automaticamente as ferramentas se configurado via .bindTools(),
            // mas em Server Actions explicitas, podemos precisar iterar se quisermos logs customizados.
            // Aqui assumimos que o fluxo do LangChain já processou as chamadas.
            
            // Para este exemplo, vamos simular a leitura do resultado final do fluxo.
            // Em um cenário real complexo, usaríamos um 'ToolNode' ou 'createReactAgent'.
            const result = {
                success: true,
                action: 'Tool Called',
                details: aiMessage.additional_kwargs.tool_calls || 'Execução automática via LangChain',
                message: 'Análise concluída e ação disparada com sucesso.'
            };

            return result;
        }

        // Caso o LLM não chame ferramentas (falha de instrução)
        return {
            success: false,
            message: 'O modelo não conseguiu decidir por uma ação automática.',
            rawResponse: aiMessage.content
        };

    } catch (error) {
        console.error('Erro na análise de feedback:', error);
        return { 
            success: false, 
            error: 'Erro interno do servidor' 
        };
    }
}
