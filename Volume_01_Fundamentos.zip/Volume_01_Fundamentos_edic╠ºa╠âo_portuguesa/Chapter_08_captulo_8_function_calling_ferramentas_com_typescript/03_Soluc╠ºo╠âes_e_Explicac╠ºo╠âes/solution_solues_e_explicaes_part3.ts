/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.ts
// Description: Soluções e Explicações
// ==========================================

import { StateGraph, Annotation, END, START } from "@langchain/langgraph";

// 1. Definição do Estado e Tipos
interface WeatherResponse {
  temperature: number;
  condition: string;
}

const WeatherStateAnnotation = Annotation.Root({
  city: Annotation<string>({
    reducer: (_, update) => update,
    default: () => "São Paulo",
  }),
  weatherData: Annotation<WeatherResponse | null>({
    reducer: (_, update) => update,
    default: () => null,
  }),
  error: Annotation<string>({
    reducer: (curr, update) => update,
    default: () => "",
  }),
});

type WeatherState = typeof WeatherStateAnnotation.State;

// 2. Simulação de API Externa
const fetchWeatherData = (city: string): Promise<WeatherResponse> => {
  console.log(`[API] Consultando clima para: ${city}`);
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // Simula sucesso aleatório ou erro
      if (Math.random() > 0.2) {
        resolve({
          temperature: 25 + Math.random() * 5,
          condition: "Ensolarado",
        });
      } else {
        reject(new Error("Falha na conexão com a API de clima"));
      }
    }, 2000); // Latência simulada de 2 segundos
  });
};

// 3. Nó da Ferramenta Assíncrona
const weatherToolNode = async (state: WeatherState): Promise<Partial<WeatherState>> => {
  try {
    // Aguarda a Promise resolver antes de prosseguir
    const data = await fetchWeatherData(state.city);
    
    return {
      weatherData: data,
      error: "", // Limpa erros anteriores se houver sucesso
    };
  } catch (err) {
    // Tratamento de erro silencioso conforme requisito
    console.error("[Erro na Ferramenta]", err);
    return {
      weatherData: null,
      error: "Não foi possível obter os dados do clima.",
    };
  }
};

// 4. Nó Final (Consolidação)
const finalNode = async (state: WeatherState): Promise<Partial<WeatherState>> => {
  console.log("Consolidação final dos dados.");
  return state;
};

// 5. Montagem do Grafo
const workflow = new StateGraph(WeatherStateAnnotation)
  .addNode("weatherToolNode", weatherToolNode)
  .addNode("finalNode", finalNode)
  .addEdge(START, "weatherToolNode")
  .addEdge("weatherToolNode", "finalNode")
  .addEdge("finalNode", END);

export const graph = workflow.compile();

// Exemplo de uso
/*
graph.invoke({ city: "Rio de Janeiro" }).then(state => {
  console.log("Estado final:", state);
});
*/
