/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part2.ts
// Description: Soluções e Explicações
// ==========================================

import { StateGraph, Annotation, END, START } from "@langchain/langgraph";

// 1. Definição do Estado
const NetworkStateAnnotation = Annotation.Root({
  severity: Annotation<"low" | "high">({
    reducer: (_, update) => update,
    default: () => "low",
  }),
  diagnosis: Annotation<string>({
    reducer: (curr, update) => curr + "\n" + update,
    default: () => "",
  }),
  resolved: Annotation<boolean>({
    reducer: (_, update) => update,
    default: () => false,
  }),
});

type NetworkState = typeof NetworkStateAnnotation.State;

// 2. Definição dos Nós
const diagnoseNode = async (state: NetworkState): Promise<Partial<NetworkState>> => {
  console.log("Executando diagnóstico...");
  // Simula detecção de severidade alta
  const isSevere = Math.random() > 0.5; 
  
  return {
    diagnosis: "Diagnóstico inicial realizado.",
    severity: isSevere ? "high" : "low",
  };
};

const escalateNode = async (state: NetworkState): Promise<Partial<NetworkState>> => {
  console.log("Escalonando para suporte humano...");
  return {
    diagnosis: "Ticket de suporte criado devido à severidade alta.",
    resolved: false,
  };
};

const resolveNode = async (state: NetworkState): Promise<Partial<NetworkState>> => {
  console.log("Aplicando correção automática...");
  return {
    diagnosis: "Problema resolvido com sucesso.",
    resolved: true,
  };
};

// 3. Condicional Edge
const shouldEscalate = (state: NetworkState): "escalateNode" | "resolveNode" => {
  // A função inspeciona o estado e retorna o próximo nó
  if (state.severity === "high") {
    return "escalateNode";
  }
  return "resolveNode";
};

// 4. Orquestração do Grafo
const workflow = new StateGraph(NetworkStateAnnotation)
  .addNode("diagnoseNode", diagnoseNode)
  .addNode("escalateNode", escalateNode)
  .addNode("resolveNode", resolveNode)
  .addEdge(START, "diagnoseNode")
  .addConditionalEdges("diagnoseNode", shouldEscalate)
  .addEdge("escalateNode", END)
  .addEdge("resolveNode", END);

export const graph = workflow.compile();

// Exemplo de visualização (Graphviz DOT)
/*
digraph G {
    node [shape=box];
    START -> diagnoseNode;
    diagnoseNode -> escalateNode [label="Severidade Alta"];
    diagnoseNode -> resolveNode [label="Severidade Baixa"];
    escalateNode -> END;
    resolveNode -> END;
}
*/
