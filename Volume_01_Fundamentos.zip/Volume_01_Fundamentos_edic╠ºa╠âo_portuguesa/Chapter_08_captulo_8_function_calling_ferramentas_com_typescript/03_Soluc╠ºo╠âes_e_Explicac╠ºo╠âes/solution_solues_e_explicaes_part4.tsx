/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.tsx
// Description: Soluções e Explicações
// ==========================================

import React, { useState, FormEvent, ChangeEvent } from 'react';

// 1. Tipagem do Estado e Mensagens
interface ChatMessage {
  role: 'user' | 'agent';
  content: string;
}

interface ChatState {
  messages: ChatMessage[];
  isLoading: boolean;
  input: string;
}

// 2. Simulação da Lógica de Backend (Agente)
const sendQuery = async (query: string): Promise<string> => {
  // Simula latência de rede
  await new Promise(resolve => setTimeout(resolve, 1500));

  if (query.toLowerCase().includes("saldo")) {
    return "Consultando sua conta... Saldo atual: R$ 1.500,00 (via ferramenta de banco de dados).";
  }
  return "Posso ajudar com consultas de saldo ou extratos.";
};

// 3. Componente React
export const BankChat: React.FC = () => {
  const [state, setState] = useState<ChatState>({
    messages: [],
    isLoading: false,
    input: '',
  });

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    // Não permite digitar se estiver carregando (desafio interativo)
    if (!state.isLoading) {
      setState(prev => ({ ...prev, input: e.target.value }));
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const userMessage = state.input.trim();
    if (!userMessage || state.isLoading) return;

    // 1. Adiciona mensagem do usuário e ativa loading
    setState(prev => ({
      ...prev,
      messages: [...prev.messages, { role: 'user', content: userMessage }],
      input: '',
      isLoading: true,
    }));

    try {
      // 2. Chamada assíncrona
      const response = await sendQuery(userMessage);

      // 3. Atualiza estado com resposta do agente
      setState(prev => ({
        ...prev,
        messages: [...prev.messages, { role: 'agent', content: response }],
        isLoading: false,
      }));
    } catch (error) {
      setState(prev => ({
        ...prev,
        messages: [...prev.messages, { role: 'agent', content: "Erro ao processar sua solicitação." }],
        isLoading: false,
      }));
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto', fontFamily: 'sans-serif' }}>
      <div style={{ height: '400px', overflowY: 'auto', border: '1px solid #ccc', padding: '10px', marginBottom: '10px' }}>
        {state.messages.map((msg, index) => (
          <div key={index} style={{ textAlign: msg.role === 'user' ? 'right' : 'left', margin: '5px 0' }}>
            <span style={{
              display: 'inline-block',
              padding: '8px 12px',
              borderRadius: '12px',
              background: msg.role === 'user' ? '#007bff' : '#f1f1f1',
              color: msg.role === 'user' ? 'white' : 'black',
            }}>
              {msg.content}
            </span>
          </div>
        ))}
        {state.isLoading && (
          <div style={{ textAlign: 'left', margin: '5px 0', color: '#666' }}>
            <em>Digitando...</em>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} style={{ display: 'flex', gap: '10px' }}>
        <input
          type="text"
          value={state.input}
          onChange={handleInputChange}
          placeholder="Pergunte sobre seu saldo..."
          disabled={state.isLoading}
          style={{ flex: 1, padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
        />
        <button 
          type="submit" 
          disabled={state.isLoading}
          style={{ padding: '8px 16px', background: '#007bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
        >
          Enviar
        </button>
      </form>
    </div>
  );
};
