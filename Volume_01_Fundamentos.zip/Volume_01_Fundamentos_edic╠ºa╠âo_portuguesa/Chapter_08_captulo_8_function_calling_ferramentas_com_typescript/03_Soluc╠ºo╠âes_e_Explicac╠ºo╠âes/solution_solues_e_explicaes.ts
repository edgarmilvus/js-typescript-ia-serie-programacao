/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.ts
// Description: Soluções e Explicações
// ==========================================

import { z } from "zod";
import { tool } from "@langchain/core/tools";
import { ChatOpenAI } from "@langchain/openai";
import { AgentExecutor, createToolCallingAgent } from "langchain/agents";
import { ChatPromptTemplate } from "@langchain/core/prompts";

// 1. Definição de Tipos e Esquemas Zod
// Tipo estrito para o resultado da busca
export interface SearchResult {
  technology: string;
  growthScore: number;
}

// Schema de validação para a ferramenta de busca
const searchSchema = z.object({
  query: z.string().describe("A consulta de pesquisa para tendências tecnológicas"),
});

// Schema de validação para a ferramenta de cálculo
const calculateSchema = z.object({
  scores: z.array(z.number()).describe("Lista de scores numéricos para calcular a média"),
});

// 2. Definição das Ferramentas
// Ferramenta de busca simulada
const searchTrends = tool(
  async ({ query }): Promise<SearchResult[]> => {
    // Simulação de dados externos baseada na query
    console.log(`[Ferramenta Busca] Executando para: "${query}"`);
    const mockData: SearchResult[] = [
      { technology: "Generative AI", growthScore: 9.5 },
      { technology: "Cloud Computing", growthScore: 8.2 },
      { technology: "Blockchain", growthScore: 7.8 },
    ];
    return mockData.filter((item) => 
      query.toLowerCase().includes("ia") && item.technology === "Generative AI" ||
      query.toLowerCase().includes("cloud") && item.technology === "Cloud Computing" ||
      query.toLowerCase().includes("blockchain") && item.technology === "Blockchain"
    ).length > 0 
      ? mockData 
      : [{ technology: "Tecnologia Não Encontrada", growthScore: 0 }];
  },
  {
    name: "searchTrends",
    description: "Busca tendências tecnológicas atuais e seus scores de crescimento.",
    schema: searchSchema,
  }
);

// Ferramenta de cálculo
const calculateAverageGrowth = tool(
  async ({ scores }): Promise<string> => {
    console.log(`[Ferramenta Cálculo] Recebido scores: [${scores.join(", ")}]`);
    if (!scores || scores.length === 0) return "0";
    const sum = scores.reduce((a, b) => a + b, 0);
    const avg = sum / scores.length;
    return avg.toFixed(2);
  },
  {
    name: "calculateAverageGrowth",
    description: "Calcula a média aritmética de uma lista de scores numéricos.",
    schema: calculateSchema,
  }
);

// 3. Configuração do LLM e Agente
const prompt = ChatPromptTemplate.fromMessages([
  ["system", "Você é um analista de mercado. Sempre que receber dados de scores, calcule a média usando a ferramenta apropriada."],
  ["human", "{input}"],
  ["placeholder", "{agent_scratchpad}"],
]);

const llm = new ChatOpenAI({
  model: "gpt-4o-mini",
  temperature: 0,
});

// 4. Fluxo de Execução
export async function executeMarketAnalysis(query: string) {
  const tools = [searchTrends, calculateAverageGrowth];
  
  const agent = await createToolCallingAgent({
    llm,
    tools,
    prompt,
  });

  const agentExecutor = new AgentExecutor({
    agent,
    tools,
    verbose: true, // Para depuração
  });

  const result = await agentExecutor.invoke({
    input: query,
  });

  return result.output;
}

// Exemplo de uso (comentado para evitar execução automática em importações)
// executeMarketAnalysis("Pesquise por 'Cloud Computing' e calcule a média dos scores de crescimento.")
//   .then(console.log)
//   .catch(console.error);
