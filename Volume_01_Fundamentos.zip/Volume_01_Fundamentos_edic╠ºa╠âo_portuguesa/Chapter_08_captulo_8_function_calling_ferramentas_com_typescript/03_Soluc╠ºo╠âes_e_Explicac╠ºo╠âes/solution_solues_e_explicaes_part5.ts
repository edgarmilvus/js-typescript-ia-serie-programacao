/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part5.ts
// Description: Soluções e Explicações
// ==========================================

import { StateGraph, Annotation, END, START } from "@langchain/langgraph";

// 1. Definição do Estado ReAct
const ReActStateAnnotation = Annotation.Root({
  input: Annotation<string>({
    reducer: (curr, update) => update,
    default: () => "",
  }),
  thoughts: Annotation<string[]>({
    reducer: (curr, update) => [...curr, update],
    default: () => [],
  }),
  actions: Annotation<Array<{ tool: string; args: any }>>({
    reducer: (curr, update) => [...curr, update],
    default: () => [],
  }),
  observations: Annotation<string[]>({
    reducer: (curr, update) => [...curr, update],
    default: () => [],
  }),
  finalAnswer: Annotation<string | null>({
    reducer: (_, update) => update,
    default: () => null,
  }),
  iterationCount: Annotation<number>({
    reducer: (curr, update) => curr + 1,
    default: () => 0,
  }),
});

type ReActState = typeof ReActStateAnnotation.State;

// Constantes de limite
const MAX_ITERATIONS = 5;

// 2. Simulação de Ferramentas
const mockTools = {
  calculator: (args: any) => `Resultado da conta: ${args.a} + ${args.b} = ${args.a + args.b}`,
  search: (args: any) => `Resultados para '${args.query}': Encontramos dados relevantes.`,
};

// 3. Nós do Grafo

// Nó de Raciocínio (Simulado)
const reasonNode = async (state: ReActState): Promise<Partial<ReActState>> => {
  console.log(`[Raciocínio] Iteração ${state.iterationCount + 1}`);
  
  // Simulação de decisão do LLM
  // Se for a primeira iteração, busca calcular algo. Se tiver observação, finaliza.
  let thought = "";
  let action = null;

  if (state.observations.length === 0) {
    thought = "Preciso calcular a soma de 10 e 20 para responder.";
    action = { tool: "calculator", args: { a: 10, b: 20 } };
  } else {
    // Baseado na observação anterior, decide finalizar
    thought = "Recebi o resultado da conta. Posso fornecer a resposta final.";
    action = null; // Sem ação, apenas raciocínio final
  }

  return {
    thoughts: thought,
    // Se houver ação, retorna o objeto, senão retorna null (que será ignorado pelo reducer se for undefined, mas aqui tratamos explicitamente)
    actions: action ? action : undefined, 
    finalAnswer: action ? null : `A soma é ${state.observations[0].replace('Resultado da conta: ', '')}`,
  };
};

// Nó de Ação (Execução de Ferramentas)
const actionNode = async (state: ReActState): Promise<Partial<ReActState>> => {
  const lastAction = state.actions[state.actions.length - 1];
  console.log(`[Ação] Executando ferramenta: ${lastAction.tool}`);
  
  const toolFn = mockTools[lastAction.tool as keyof typeof mockTools];
  const result = toolFn(lastAction.args);

  return {
    observations: result,
  };
};

// 4. Nó Condicional (CheckNode)
const checkNode = (state: ReActState): "reasonNode" | typeof END => {
  // Limite de iterações para evitar loops infinitos
  if (state.iterationCount >= MAX_ITERATIONS) {
    console.log("Limite de iterações atingido.");
    return END;
  }

  // Se o finalAnswer estiver preenchido, termina.
  if (state.finalAnswer && state.finalAnswer.trim() !== "") {
    return END;
  }

  // Caso contrário, volta para o raciocínio
  return "reasonNode";
};

// 5. Montagem do Grafo com Loop
const workflow = new StateGraph(ReActStateAnnotation)
  .addNode("reasonNode", reasonNode)
  .addNode("actionNode", actionNode)
  .addEdge(START, "reasonNode")
  // Saída do reasonNode vai para actionNode
  .addEdge("reasonNode", "actionNode")
  // Saída do actionNode vai para o checkNode (nó virtual de decisão)
  .addEdge("actionNode", "checkNode");

// Adiciona o nó condicional (checkNode é uma função, não um nó de processamento de estado)
workflow.addConditionalEdges(
  "checkNode", // Identificador do nó ou função
  checkNode,
  {
    [END]: END,
    "reasonNode": "reasonNode",
  }
);

// Nota: No LangGraph, precisamos adicionar o nó 'checkNode' logicamente.
// Para simplificar, usaremos um nó virtual ou adicionaremos ao grafo se necessário.
// Nesta implementação, usaremos um padrão comum onde o nó anterior chama a lógica de decisão,
// mas seguindo a estrutura solicitada de "nós do grafo", vamos criar um nó real para o check.

const checkNodeWrapper = async (state: ReActState): Promise<Partial<ReActState>> => {
  // Apenas retorna vazio, a decisão é tomada nas arestas condicionais
  return {};
};

workflow.addNode("checkNode", checkNodeWrapper);
// Corrigindo arestas para usar o nó wrapper
workflow.addEdge("actionNode", "checkNode");
workflow.addConditionalEdges("checkNode", checkNode);

export const graph = workflow.compile();

// Exemplo de execução
/*
graph.invoke({ input: "Calcule a soma de 10 e 20" }).then(state => {
  console.log("Estado Final:", state);
});
*/
