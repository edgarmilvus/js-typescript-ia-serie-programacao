/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada_part2.tsx
// Description: Script de Aplicação Avançada
// ==========================================

// app/page.tsx
'use client';

import { useFormState, useFormStatus } from 'react-dom';
import { performRAGQuery } from './actions/rag-actions';
import { useState } from 'react';

const initialState = {
  answer: '',
  sources: [],
  error: null,
  success: false,
};

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <button 
      type="submit" 
      disabled={pending}
      className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50"
    >
      {pending ? 'Processando...' : 'Consultar'}
    </button>
  );
}

export default function RAGPage() {
  const [state, formAction] = useFormState(performRAGQuery, initialState);
  const [query, setQuery] = useState('');

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Consultor de Documentação Interna (RAG)</h1>
      
      <form action={formAction} className="flex gap-2 mb-6">
        <input
          type="text"
          name="query"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Ex: Como resolvo o erro 429?"
          className="flex-1 p-2 border rounded text-black"
          required
        />
        <SubmitButton />
      </form>

      {state?.error && (
        <div className="p-4 bg-red-100 text-red-700 rounded mb-4">
          {state.error}
        </div>
      )}

      {state?.success && (
        <div className="space-y-4">
          <div className="p-4 bg-gray-100 rounded">
            <h2 className="font-semibold text-gray-700">Resposta:</h2>
            <p className="mt-2 text-gray-900">{state.answer}</p>
          </div>
          
          {state.sources && state.sources.length > 0 && (
            <div className="p-4 bg-blue-50 rounded">
              <h2 className="font-semibold text-blue-800">Fontes Utilizadas:</h2>
              <ul className="list-disc list-inside mt-2 text-blue-700">
                {state.sources.map((src: any, idx: number) => (
                  <li key={idx}>{src.source} (Seção: {src.section})</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
