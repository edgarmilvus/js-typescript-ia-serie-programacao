/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.tsx
// Description: Script de Aplicação Avançada
// ==========================================

// app/actions/rag-actions.ts
'use server';

import { OpenAIEmbeddings } from '@langchain/openai';
import { MemoryVectorStore } from 'langchain/vectorstores/memory';
import { ChatOpenAI } from '@langchain/openai';
import { PromptTemplate } from '@langchain/core/prompts';
import { z } from 'zod';

/**
 * @description Schema de validação para a entrada do usuário.
 * Garante que a query não seja vazia e limpa espaços em branco.
 * Usa Zod para inferência de tipos TypeScript automática.
 */
const QuerySchema = z.object({
  query: z.string().min(1, "A consulta não pode estar vazia.").trim(),
});

// Simulação de uma base de conhecimento inicial (Documentos internos da empresa)
const initialDocs = [
  {
    id: "doc1",
    content: "A API da Empresa X suporta autenticação via Bearer Token. O endpoint de login é POST /api/v1/auth/login. Os tokens expiram em 24 horas.",
    metadata: { source: "internal-docs", section: "auth" }
  },
  {
    id: "doc2",
    content: "Para limites de taxa, a API padrão permite 100 requisições por minuto. Planos Enterprise podem solicitar aumento para 1000 req/min através do painel de controle.",
    metadata: { source: "internal-docs", section: "limits" }
  },
  {
    id: "doc3",
    content: "O erro 429 indica 'Too Many Requests'. Para resolver, implemente um backoff exponencial no cliente.",
    metadata: { source: "internal-docs", section: "errors" }
  },
  {
    id: "doc4",
    content: "A documentação pública da API está disponível em https://api.empresa-x.com/docs. Lá você encontrará especificações OpenAPI.",
    metadata: { source: "public", section: "general" }
  }
];

// Instância global (em memória) para fins de demonstração. 
// Em produção, isso seria um banco de dados vetorial persistente (Pinecone, pgvector).
let vectorStoreInstance: MemoryVectorStore | null = null;

/**
 * @description Inicializa o Vector Store com embeddings gerados a partir dos documentos iniciais.
 * Esta função simula o processo de ingestão (ETL) de dados.
 */
async function initializeVectorStore() {
  if (vectorStoreInstance) return vectorStoreInstance;

  // 1. Configurar o modelo de embeddings (OpenAI ada-002 é padrão para texto)
  const embeddings = new OpenAIEmbeddings({
    apiKey: process.env.OPENAI_API_KEY,
    model: "text-embedding-ada-002",
  });

  // 2. Gerar embeddings e armazenar em memória
  // O LangChain abstrai a chamada à API da OpenAI e o armazenamento vetorial
  vectorStoreInstance = await MemoryVectorStore.fromTexts(
    initialDocs.map(doc => doc.content),
    initialDocs.map(doc => doc.metadata),
    embeddings
  );

  return vectorStoreInstance;
}

/**
 * @description Server Action principal que orquestra o fluxo RAG.
 * 1. Valida entrada.
 * 2. Recupera contexto relevante (Similarity Search).
 * 3. Gera resposta via LLM com contexto injetado.
 */
export async function performRAGQuery(prevState: any, formData: FormData) {
  try {
    // --- PASSO 1: VALIDAÇÃO ---
    const rawData = Object.fromEntries(formData);
    const result = QuerySchema.safeParse(rawData);

    if (!result.success) {
      return { error: result.error.errors[0].message, success: false };
    }

    const { query } = result.data;
    const store = await initializeVectorStore();

    // --- PASSO 2: RECUPERAÇÃO (RETRIEVAL) ---
    // Realiza uma busca por Similaridade Cosine (CSS) para encontrar os top 2 documentos mais relevantes.
    // Isso transforma a query textual em um vetor e compara com os vetores armazenados.
    const docs = await store.similaritySearch(query, 2);

    if (docs.length === 0) {
      return { 
        answer: "Não encontrei informações relevantes na base de conhecimento.", 
        sources: [],
        success: true 
      };
    }

    // --- PASSO 3: GERAÇÃO AUMENTADA (AUGMENTATION) ---
    // Concatena o conteúdo dos documentos recuperados para formar o contexto.
    const context = docs.map(doc => doc.pageContent).join("\n\n---\n\n");

    // Carrega o modelo GPT-3.5-Turbo (ou 4o-mini para eficiência)
    const model = new ChatOpenAI({
      apiKey: process.env.OPENAI_API_KEY,
      model: "gpt-3.5-turbo-0125", 
      temperature: 0.1, // Baixa temperatura para respostas factuais
    });

    // Define um prompt estruturado para forçar a LLM a usar o contexto
    const prompt = PromptTemplate.fromTemplate(
      `Você é um assistente de suporte técnico da Empresa X.
       Responda à pergunta do usuário baseando-se estritamente no contexto abaixo.
       Se a resposta não estiver no contexto, diga que não sabe.
       
       CONTEXTO:
       {context}
       
       PERGUNTA: {question}
       
       RESPOSTA:`
    );

    // Cadeia de execução: Prompt -> LLM
    const chain = prompt.pipe(model);
    
    // Invoca a LLM
    const response = await chain.invoke({
      context: context,
      question: query,
    });

    // Formata a resposta final
    return {
      answer: response.content as string,
      sources: docs.map(d => d.metadata), // Retorna as fontes para o frontend exibir
      success: true,
    };

  } catch (error) {
    console.error("Erro no fluxo RAG:", error);
    return { 
      error: "Ocorreu um erro ao processar sua solicitação.", 
      success: false 
    };
  }
}
