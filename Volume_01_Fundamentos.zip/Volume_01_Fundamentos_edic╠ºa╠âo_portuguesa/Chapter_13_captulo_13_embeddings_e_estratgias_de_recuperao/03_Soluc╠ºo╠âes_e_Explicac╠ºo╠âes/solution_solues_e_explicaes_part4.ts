/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.ts
// Description: Soluções e Explicações
// ==========================================

import { ChatOpenAI } from "@langchain/openai";
import { PromptTemplate } from "@langchain/core/prompts";
import { RunnableSequence, RunnablePassthrough } from "@langchain/core/runnables";
import { HNSWLib } from "@langchain/community/vectorstores/hnswlib";
import { OpenAIEmbeddings } from "@langchain/openai";

// Função auxiliar para formatar documentos recuperados
const formatDocuments = (docs: any[]) => {
  return docs.map((doc) => doc.pageContent).join("\n\n");
};

/**
 * Executa um pipeline RAG completo.
 * @param question - A pergunta do usuário.
 * @param vectorStore - O banco de dados vetorial contendo os documentos.
 * @returns Promise<string> - A resposta gerada pelo LLM.
 */
export async function runRAGPipeline(question: string, vectorStore: HNSWLib): Promise<string> {
  // 1. Configurar o Modelo de Linguagem (LLM)
  const model = new ChatOpenAI({
    modelName: "gpt-3.5-turbo",
    temperature: 0, // Foco na factualidade, criatividade mínima
  });

  // 2. Configurar o Retriever (Busca Vetorial)
  const retriever = vectorStore.asRetriever(3); // Retorna os top 3 documentos mais similares

  // 3. Definir o Prompt Template
  // Instruções explícitas para usar apenas o contexto fornecido
  const promptTemplate = `
    Você é um assistente útil e preciso.
    Responda à pergunta do usuário baseando-se estritamente no contexto fornecido abaixo.
    Se a resposta não estiver no contexto, diga que não sabe a resposta baseada nos documentos disponíveis.
    
    Contexto:
    {context}
    
    Pergunta: {question}
    
    Resposta:
  `;

  const prompt = new PromptTemplate({
    template: promptTemplate,
    inputVariables: ["context", "question"],
  });

  // 4. Montar a Cadeia (Chain) de RAG
  // A cadeia conecta o retriever, o formatador de documentos, o prompt e o modelo.
  const ragChain = RunnableSequence.from([
    {
      // Passa a pergunta adiante e usa o retriever para buscar documentos
      question: new RunnablePassthrough(),
      context: retriever.pipe(formatDocuments), 
    },
    prompt,
    model,
  ]);

  // 5. Invocar a cadeia
  const response = await ragChain.invoke(question);
  
  // O retorno é um AIMessage, acessamos o conteúdo
  return response.content as string;
}

/*
// Exemplo de setup (simulado para demonstração)
async function demo() {
    // Assumindo que um vectorStore foi criado e populado conforme o Ex 1
    // const vectorStore = ... 
    
    // const pergunta = "O que são embeddings?";
    // const resposta = await runRAGPipeline(pergunta, vectorStore);
    // console.log(resposta);
}
*/
