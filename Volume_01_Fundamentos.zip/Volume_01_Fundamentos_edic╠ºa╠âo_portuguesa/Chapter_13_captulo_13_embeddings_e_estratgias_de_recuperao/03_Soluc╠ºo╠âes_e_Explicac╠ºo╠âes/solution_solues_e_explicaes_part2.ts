/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part2.ts
// Description: Soluções e Explicações
// ==========================================

import { OpenAIEmbeddings } from "@langchain/openai";
import { HNSWLib } from "@langchain/community/vectorstores/hnswlib";
import { Document } from "@langchain/core/documents";

// Interface para o resultado da busca
interface SearchResult {
  text: string;
  score: number; // Similaridade de cosseno (0 a 1, onde 1 é idêntico)
}

/**
 * Realiza uma busca semântica em um repositório de vetores.
 * @param query - A consulta do usuário em texto.
 * @param k - Número de resultados a retornar.
 * @param vectorStore - Instância do banco de dados vetorial (HNSWLib neste caso).
 * @returns Promise<SearchResult[]> - Array de documentos similares e suas pontuações.
 */
export async function semanticSearch(
  query: string,
  k: number,
  vectorStore: HNSWLib
): Promise<SearchResult[]> {
  // 1. Realizar a busca no vector store
  // O método similaritySearchWithScore retorna documentos e uma pontuação de similaridade (0 a 1).
  // Quanto mais próximo de 1, maior a similaridade.
  const results = await vectorStore.similaritySearchWithScore(query, k);

  // 2. Mapear os resultados para a interface desejada
  const formattedResults: SearchResult[] = results.map(([doc, score]) => ({
    text: doc.pageContent,
    score: score,
  }));

  return formattedResults;
}

// --- Contexto de Simulação para Teste ---
// Esta parte simula a criação de um vector store a partir dos dados do Exercício 1
// para que a função possa ser testada isoladamente.
async function setupTestEnvironment() {
    const rawText = `
    O conceito de Embeddings é fundamental no processamento de linguagem natural moderna.
    Um embedding é uma representação vetorial de alta dimensão que captura o significado semântico de uma palavra ou frase.
    Ao contrário de métodos antigos como Bag-of-Words, embeddings permitem que a máquina entenda relações como "rei" é para "homem" assim como "rainha" é para "mulher".
    A API da OpenAI oferece modelos de embedding de última geração que convertem textos em vetores de 1536 dimensões.
    Esses vetores podem então ser armazenados em bancos de dados especializados como o Pinecone ou Weaviate para busca rápida.
    `;
    
    const embeddings = new OpenAIEmbeddings();
    
    // Criando documentos para o HNSWLib
    const docs = [
        new Document({ pageContent: "Embeddings são vetores de alta dimensão." }),
        new Document({ pageContent: "A busca semântica entende o significado, não apenas palavras." }),
        new Document({ pageContent: "O uso de bancos de dados vetoriais permite busca rápida." }),
    ];

    // Nota: Em um cenário real, carregaríamos o HNSWLib de um diretário existente
    // Para este exemplo de código, criamos um novo (requer salvamento em disco para persistência real)
    const vectorStore = await HNSWLib.fromDocuments(docs, embeddings);
    return vectorStore;
}

/*
// Exemplo de uso:
setupTestEnvironment().then(async (vectorStore) => {
    const query = "métodos de representação textual avançada";
    const results = await semanticSearch(query, 2, vectorStore);
    console.log(results);
});
*/
