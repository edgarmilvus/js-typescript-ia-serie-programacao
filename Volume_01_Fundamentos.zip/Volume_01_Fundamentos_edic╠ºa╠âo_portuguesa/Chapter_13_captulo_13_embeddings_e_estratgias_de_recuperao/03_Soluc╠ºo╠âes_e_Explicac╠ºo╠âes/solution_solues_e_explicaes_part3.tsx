/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.tsx
// Description: Soluções e Explicações
// ==========================================

// SearchResults.tsx
import React from 'react';

// Definição da interface para as props
interface SearchResult {
  text: string;
  score: number;
  id: string; // Adicionado para key prop e identificação única
}

interface SearchResultsProps {
  results: SearchResult[] | null;
}

// Estilização simples via Tailwind CSS (assumido no projeto)
// Se usar CSS Modules, seria import './SearchResults.module.css'

/**
 * Componente Server (App Router) para exibir resultados de busca vetorial.
 */
export default function SearchResults({ results }: SearchResultsProps) {
  // Verifica se há resultados válidos
  if (!results || results.length === 0) {
    return (
      <div className="p-4 bg-gray-50 text-gray-500 text-center rounded-md border border-gray-200">
        Nenhum documento encontrado.
      </div>
    );
  }

  return (
    <div className="space-y-4 mt-4">
      <h2 className="text-lg font-semibold text-gray-800">Resultados da Busca:</h2>
      <div className="grid gap-4">
        {results.map((result) => (
          <div
            key={result.id}
            className="p-4 bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex justify-between items-start mb-2">
              <span className="text-xs font-mono bg-blue-100 text-blue-800 px-2 py-1 rounded">
                Score: {result.score.toFixed(4)}
              </span>
            </div>
            <p className="text-gray-700 leading-relaxed text-sm">
              {result.text}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
