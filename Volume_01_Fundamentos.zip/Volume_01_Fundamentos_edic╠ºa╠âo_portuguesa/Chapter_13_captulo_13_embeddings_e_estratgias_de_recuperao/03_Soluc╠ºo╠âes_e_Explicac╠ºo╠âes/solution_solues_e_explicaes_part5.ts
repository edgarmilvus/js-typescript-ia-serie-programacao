/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part5.ts
// Description: Soluções e Explicações
// ==========================================

// Interfaces comuns
interface ResultItem {
  id: string;
  text: string;
  score: number; // Score de 0 a 1
}

interface HybridResult extends ResultItem {
  finalScore: number;
}

/**
 * Combina resultados de busca vetorial e textual (simulado) com re-ranqueamento.
 * @param vectorResults - Resultados da busca vetorial (semântica).
 * @param keywordResults - Resultados da busca por palavras-chave (simulada).
 * @param k - Número final de resultados a retornar.
 * @returns HybridResult[] - Top K documentos ranqueados pela pontuação híbrida.
 */
export function hybridSearch(
  vectorResults: ResultItem[],
  keywordResults: ResultItem[],
  k: number
): HybridResult[] {
  // Pesos para a fórmula de fusão (pode ser ajustado via aprendizado de máquina)
  const WEIGHT_VETORIAL = 0.7;
  const WEIGHT_KEYWORD = 0.3;

  // Mapa para facilitar o acesso aos scores de keyword pelo ID
  const keywordScoresMap = new Map<string, number>();
  keywordResults.forEach((item) => {
    keywordScoresMap.set(item.id, item.score);
  });

  // 1. Processar os resultados vetoriais (garantindo que todos sejam considerados)
  const combinedResults: HybridResult[] = vectorResults.map((vecItem) => {
    const keywordScore = keywordScoresMap.get(vecItem.id) || 0; // Se não encontrar, score é 0
    const finalScore = (vecItem.score * WEIGHT_VETORIAL) + (keywordScore * WEIGHT_KEYWORD);
    
    return {
      id: vecItem.id,
      text: vecItem.text,
      score: vecItem.score,
      finalScore: finalScore,
    };
  });

  // 2. Ordenar pela pontuação híbrida (decrescente)
  combinedResults.sort((a, b) => b.finalScore - a.finalScore);

  // 3. Retornar os top K
  return combinedResults.slice(0, k);
}

/*
// Exemplo de Simulação de Dados:
const vectorData: ResultItem[] = [
  { id: "doc1", text: "Embeddings são vetores...", score: 0.95 },
  { id: "doc2", text: "Banana é uma fruta...", score: 0.10 }, // Irrelevante semanticamente
];

const keywordData: ResultItem[] = [
  { id: "doc1", text: "Embeddings são vetores...", score: 0.80 }, // Alto score
  { id: "doc2", text: "Banana é uma fruta...", score: 0.90 }, // Alto score por conter palavra rara? (Simulado)
];

// O "doc1" deve prevalecer no topo devido à combinação de scores altos.
// O "doc2" pode subir se o score vetorial for baixo mas o keyword alto, dependendo do peso.
// const results = hybridSearch(vectorData, keywordData, 2);
// console.log(results);
*/
