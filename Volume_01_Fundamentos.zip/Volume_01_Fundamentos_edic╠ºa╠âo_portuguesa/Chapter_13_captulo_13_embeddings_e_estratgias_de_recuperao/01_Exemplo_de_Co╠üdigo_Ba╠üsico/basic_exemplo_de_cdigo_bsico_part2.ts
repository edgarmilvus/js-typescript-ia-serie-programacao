/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico_part2.ts
// Description: Exemplo de Código Básico
// ==========================================

// Arquivo: rag-hello-world.ts
// Objetivo: Implementar um fluxo RAG simples (Ingestão -> Recuperação -> Geração)
// Dependências necessárias: @supabase/supabase-js, @langchain/openai, @langchain/community

import { createClient } from '@supabase/supabase-js';
import { OpenAIEmbeddings } from '@langchain/openai';
import { SupabaseVectorStore } from '@langchain/community/vectorstores/supabase';
import { ChatOpenAI } from '@langchain/openai';
import { PromptTemplate } from '@langchain/core/prompts';

// --- CONFIGURAÇÃO DE AMBIENTE ---
// Em um app real, use variáveis de ambiente (.env) para segurança.
const SUPABASE_URL = 'https://sua-project-ref.supabase.co';
const SUPABASE_API_KEY = 'sua-anon-key';
const OPENAI_API_KEY = 'sk-...'; // Sua API Key da OpenAI

// --- 1. INICIALIZAÇÃO DO CLIENTE SUPABASE ---
// O Supabase é o nosso banco de dados PostgreSQL hospedado.
// Ele suporta a extensão pgvector para busca vetorial.
const supabaseClient = createClient(SUPABASE_URL, SUPABASE_API_KEY);

// --- 2. INICIALIZAÇÃO DO EMBEDDING MODEL ---
// Usamos o modelo 'text-embedding-ada-002' da OpenAI para converter texto em vetores (1536 dimensões).
const embeddings = new OpenAIEmbeddings({
    openAIApiKey: OPENAI_API_KEY,
    modelName: 'text-embedding-ada-002',
});

// --- 3. FUNÇÃO DE INGESTÃO (OPCIONAL PARA ESTE EXEMPLO) ---
// Normalmente, você ingesta dados uma vez. Aqui criamos uma função para demonstrar
// como salvar documentos no banco vetorial.
async function ingestarDocumentos() {
    console.log('-> Iniciando ingestão de documentos...');
    
    // Textos de exemplo (FAQ de um SaaS de e-commerce)
    const documentos = [
        { pageContent: "Como faço para resetar minha senha?", metadata: { id: 1 } },
        { pageContent: "Qual é o prazo de entrega para o Brasil?", metadata: { id: 2 } },
        { pageContent: "Aceitam cartões de crédito internacionais?", metadata: { id: 3 } },
        { pageContent: "Como entro em contato com o suporte?", metadata: { id: 4 } },
    ];

    // O SupabaseVectorStore abstrai a lógica de inserção SQL complexa.
    await SupabaseVectorStore.fromDocuments(
        supabaseClient,
        documentos,
        embeddings,
        { tableName: 'documents', queryName: 'match_documents' } // Nome da tabela e função de busca no DB
    );
    console.log('✅ Documentos vetorizados e salvos no Supabase.');
}

// --- 4. FUNÇÃO DE BUSCA E GERAÇÃO (O "HELLO WORLD" RAG) ---
// Esta é a função principal que seu app chamaria em tempo real.
async function buscarEResponder(perguntaUsuario: string) {
    console.log(`\n🔍 Buscando contexto para: "${perguntaUsuario}"`);

    // A. Configurar o Vector Store (Conexão com o DB)
    const vectorStore = new SupabaseVectorStore(supabaseClient, embeddings, {
        tableName: 'documents',
        queryName: 'match_documents', // Deve ser uma função SQL pgvector no seu DB
    });

    // B. Realizar a Similarity Search (Busca por Similaridade)
    // k=1 significa que queremos o resultado mais relevante.
    const documentosSimilares = await vectorStore.similaritySearch(perguntaUsuario, 1);

    if (documentosSimilares.length === 0) {
        console.log('❌ Nenhum contexto encontrado.');
        return;
    }

    const contexto = documentosSimilares[0].pageContent;
    console.log(`✅ Contexto recuperado: "${contexto}"`);

    // C. Configurar o LLM (GPT-3.5 Turbo ou similar)
    const model = new ChatOpenAI({
        openAIApiKey: OPENAI_API_KEY,
        modelName: 'gpt-3.5-turbo',
        temperature: 0.7, // Criatividade da resposta
    });

    // D. Criar o Prompt Template
    // Instruimos o LLM a usar estritamente o contexto fornecido.
    const promptTemplate = PromptTemplate.fromTemplate(
        `Você é um assistente de suporte ao cliente.
        Responda à pergunta do usuário baseando-se EXCLUSIVAMENTE no contexto abaixo.
        
        Contexto: {contexto}
        
        Pergunta: {pergunta}
        
        Resposta:`
    );

    // E. Encadear (Chain) e Invocar
    // Juntamos o template, o modelo e executamos.
    const chain = promptTemplate.pipe(model);
    const resposta = await chain.invoke({
        contexto: contexto,
        pergunta: perguntaUsuario,
    });

    console.log(`\n🤖 Resposta do Assistente: ${resposta.content}`);
}

// --- EXECUÇÃO DO FLUXO ---
// Em um app web (Next.js, React), você separaria a ingestão (admin) da busca (usuário).
(async () => {
    try {
        // Passo 1: Ingestão (Rode isso apenas uma vez para popular o banco)
        // await ingestarDocumentos();

        // Passo 2: Consulta (Rode isso sempre que o usuário perguntar)
        await buscarEResponder("Preciso de ajuda com meu cartão de crédito?");
        
    } catch (error) {
        console.error("Erro no fluxo RAG:", error);
    }
})();
