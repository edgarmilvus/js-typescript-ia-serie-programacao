/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.ts
// Description: Soluções e Explicações
// ==========================================

import { BaseDocumentLoader, Document } from "langchain/document_loaders/base";
import * as fs from "fs/promises";
import * as path from "path";

// Interface estrita para metadados, evitando 'any'
interface CustomMetadata {
  source: string;
  equipment: string;
  error?: boolean;
  decodingErrorDetails?: string;
}

// Interface para o resultado da decodificação
interface DecodeResult {
  content: string | null;
  encoding: string;
  error?: string;
}

export class CustomTextLoader extends BaseDocumentLoader {
  constructor(private filePath: string) {
    super();
  }

  // Método principal para carregar os documentos
  async load(): Promise<Document[]> {
    try {
      // Tenta ler o arquivo como buffer binário primeiro
      const buffer = await fs.readFile(this.filePath);
      
      // Tenta decodificar com uma lista de encodings comuns
      const decodeResult = this.tryDecodings(buffer);

      if (decodeResult.error || !decodeResult.content) {
        // Fallback: Retorna um documento vazio com metadados de erro
        return [this.createErrorDocument(decodeResult.error || "Unknown decoding error")];
      }

      // Extração de metadados do nome do arquivo
      const metadata = this.extractMetadata(path.basename(this.filePath));

      // Retorna o documento processado
      return [
        {
          pageContent: decodeResult.content,
          metadata: metadata,
        },
      ];
    } catch (fsError) {
      // Tratamento de erro de sistema (arquivo não encontrado, etc.)
      return [this.createErrorDocument((fsError as Error).message)];
    }
  }

  // Tenta várias codificações comuns (UTF-8, UTF-16LE, ASCII)
  private tryDecodings(buffer: Buffer): DecodeResult {
    const encodings = ["utf-8", "utf-16le", "ascii"];
    
    for (const encoding of encodings) {
      try {
        const content = buffer.toString(encoding);
        // Validação básica: se o conteúdo parece binário inválido (opcional)
        if (content.includes('\uFFFD')) continue; // Caractere de substituição Unicode
        return { content, encoding };
      } catch (e) {
        continue; // Tenta o próximo encoding
      }
    }
    
    return { content: null, encoding: "unknown", error: "Failed to decode with standard encodings" };
  }

  // Extrai metadados do nome do arquivo (ex: manual_bomba_agua.txt -> equipment: 'bomba_agua')
  private extractMetadata(filename: string): CustomMetadata {
    const nameWithoutExt = path.parse(filename).name;
    // Assume formato "prefixo_equipamento" ou apenas "equipamento"
    const parts = nameWithoutExt.split('_');
    const equipment = parts.length > 1 ? parts.slice(1).join('_') : nameWithoutExt;

    return {
      source: filename,
      equipment: equipment,
    };
  }

  // Cria um documento de erro padronizado
  private createErrorDocument(errorDetails: string): Document {
    return {
      pageContent: "", // Conteúdo vazio
      metadata: {
        source: this.filePath,
        equipment: "unknown",
        error: true,
        decodingErrorDetails: errorDetails,
      } as CustomMetadata,
    };
  }
}
