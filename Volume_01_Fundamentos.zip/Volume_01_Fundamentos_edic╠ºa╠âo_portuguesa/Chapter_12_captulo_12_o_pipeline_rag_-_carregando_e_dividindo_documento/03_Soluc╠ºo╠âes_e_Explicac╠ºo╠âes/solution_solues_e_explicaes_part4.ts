/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.ts
// Description: Soluções e Explicações
// ==========================================

/**
 * Limpa o texto do documento removendo ruído e normalizando espaçamento.
 * @param text - Texto bruto do documento.
 * @returns Texto limpo e processado.
 */
export function cleanDocumentText(text: string): string {
  // 1. Remover cabeçalhos e rodapés (ex: "Página X de Y", "Manual Técnico")
  // Assumimos que estão no início ou fim do texto e possuem palavras-chave específicas.
  const headerFooterRegex = /(Página \d+ de \d+|Manual Técnico|Confidencial)\s*\n?/gi;
  let cleanedText = text.replace(headerFooterRegex, '');

  // 2. Tratamento de referências cruzadas [Ver Figura X.Y]
  // Substitui por texto descritivo para manter contexto semântico no embedding.
  // Usamos um lookahead/lookbehind negativo para evitar alterar códigos técnicos que usam colchetes
  // mas que não seguem o padrão "Ver Figura".
  const figureRefRegex = /\[Ver Figura [\d\.]+\]/gi;
  cleanedText = cleanedText.replace(figureRefRegex, (match) => ` (referência à figura omitida: ${match}) `);

  // 3. Quebras de linha desnecessárias
  // Substitui múltiplas quebras de linha (2 ou mais) por uma dupla (parágrafo),
  // e quebras solitárias por espaço, preservando estrutura.
  cleanedText = cleanedText.replace(/\n{3,}/g, '\n\n'); // Máximo 2 quebras
  cleanedText = cleanedText.replace(/([^\n])\n([^\n])/g, '$1 $2'); // Une linhas quebradas no meio da frase

  // 4. Múltiplos espaços em branco
  cleanedText = cleanedText.replace(/\s+/g, ' ');

  // 5. Trim de início e fim
  return cleanedText.trim();
}

// Exemplo de uso
const rawText = `
Página 1 de 5
Manual Técnico - Bomba Hidráulica

Dados do equipamento [Ver Figura 1.2].
Pressão: 100 PSI
Recomendação [Ver Figura 2.0].

Fim do documento.
`;

console.log(cleanDocumentText(rawText));
