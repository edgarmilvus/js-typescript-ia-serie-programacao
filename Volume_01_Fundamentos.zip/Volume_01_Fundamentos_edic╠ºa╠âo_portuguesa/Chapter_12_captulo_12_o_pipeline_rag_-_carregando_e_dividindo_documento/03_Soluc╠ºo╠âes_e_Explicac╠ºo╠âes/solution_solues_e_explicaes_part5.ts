/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part5.ts
// Description: Soluções e Explicações
// ==========================================

import { z } from "zod";

// 1. Definição do Schema com Coerção e Transformação
const DocumentMetadataSchema = z.object({
  // Fonte é obrigatória e deve ser string
  source: z.string(),

  // Página é opcional. Se for fornecida como string (ex: "1"), converte para número.
  // Se não existir, define como 0.
  page: z.preprocess(
    (val) => (val === undefined || val === null ? 0 : Number(val)),
    z.number().int().nonnegative()
  ),

  // Categoria deve ser um dos valores específicos.
  category: z.enum(["technical", "legal", "marketing"]),

  // Data de ingestão. Aceita string ISO ou objeto Date.
  // Transforma a string ISO em objeto Date.
  ingestionDate: z.preprocess(
    (val) => (val instanceof Date ? val : new Date(String(val))),
    z.date()
  ),
});

// Tipo inferido do schema para uso no código
export type ValidatedMetadata = z.infer<typeof DocumentMetadataSchema>;

// 2. Função de Validação e Normalização
export function validateAndNormalizeMetadata(metadata: unknown): ValidatedMetadata {
  try {
    // O .parse() do Zod valida e executa as transformações definidas no schema
    return DocumentMetadataSchema.parse(metadata);
  } catch (error) {
    if (error instanceof z.ZodError) {
      // Lança um erro detalhado com os problemas específicos encontrados
      const errorMessages = error.errors.map(err => `${err.path.join('.')}: ${err.message}`).join(', ');
      throw new Error(`Falha na validação de metadados: ${errorMessages}`);
    }
    throw error;
  }
}

// 3. Exemplo de Integração no Loader (Baseado no Exercício 1)
// Supondo que temos metadados "sujos" vindos de uma fonte legada:
const rawMetadata = {
  source: "manual_bomba_agua.txt",
  page: "5", // String, não número
  category: "technical", // Válido
  ingestionDate: "2023-10-01T12:00:00Z", // String ISO
  // Campo extra ignorado pelo schema (strip: true por padrão no Zod)
  author: "John Doe" 
};

try {
  const cleanMetadata = validateAndNormalizeMetadata(rawMetadata);
  console.log("Metadados validados:", cleanMetadata);
  // Saída esperada: { source: "...", page: 5, category: "technical", ingestionDate: Date object... }
} catch (e) {
  console.error(e);
}
