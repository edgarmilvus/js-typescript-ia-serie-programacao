/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.tsx
// Description: Soluções e Explicações
// ==========================================

import React, { useState, useRef } from 'react';

// Interfaces TypeScript estritas
type FileStatus = 'idle' | 'uploading' | 'chunking' | 'completed' | 'error' | 'cancelled';

interface FileItem {
  file: File;
  status: FileStatus;
  progress: number;
  error?: string;
}

interface UploadState {
  files: FileItem[];
}

// Componente de Zona de Upload
export const FileUploadZone: React.FC = () => {
  const [state, setState] = useState<UploadState>({ files: [] });
  
  // Mapa para armazenar AbortControllers individuais por nome de arquivo
  const abortControllers = useRef<Map<string, AbortController>>(new Map());

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!event.target.files) return;
    
    const newFiles: FileItem[] = Array.from(event.target.files).map(file => ({
      file,
      status: 'idle',
      progress: 0,
    }));

    setState(prev => ({
      files: [...prev.files, ...newFiles]
    }));
  };

  const handleUpload = async () => {
    const filesToUpload = state.files.filter(f => f.status === 'idle' || f.status === 'error');
    
    for (const fileItem of filesToUpload) {
      await uploadFile(fileItem.file);
    }
  };

  const uploadFile = async (file: File) => {
    updateFileStatus(file.name, 'uploading', 0);
    
    const controller = new AbortController();
    abortControllers.current.set(file.name, controller);

    const formData = new FormData();
    formData.append('file', file);

    try {
      // Simulação de progresso dividido em fases
      // Fase 1: Upload (Network)
      updateFileStatus(file.name, 'uploading', 20);
      
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
        signal: controller.signal,
      });

      if (!response.ok) throw new Error('Upload falhou');

      // Fase 2: Chunking (Processamento no Servidor)
      updateFileStatus(file.name, 'chunking', 60);
      
      // Aguarda conclusão do processamento (simulação de polling ou SSE)
      // Aqui assumimos que a API retorna quando o chunking termina
      const result = await response.json();

      if (result.status === 'completed') {
        updateFileStatus(file.name, 'completed', 100);
      } else {
        throw new Error('Processamento falhou');
      }

    } catch (error: any) {
      if (error.name === 'AbortError') {
        updateFileStatus(file.name, 'cancelled', 0);
      } else {
        updateFileStatus(file.name, 'error', 0, error.message);
      }
    } finally {
      abortControllers.current.delete(file.name);
    }
  };

  const handleCancel = (fileName: string) => {
    const controller = abortControllers.current.get(fileName);
    if (controller) {
      controller.abort(); // Dispara o sinal de aborto
    }
  };

  // Helper para atualizar estado imutavelmente
  const updateFileStatus = (fileName: string, status: FileStatus, progress: number, error?: string) => {
    setState(prev => ({
      files: prev.files.map(f => 
        f.file.name === fileName 
          ? { ...f, status, progress, error } 
          : f
      )
    }));
  };

  return (
    <div>
      <input type="file" multiple onChange={handleFileSelect} />
      <button onClick={handleUpload}>Iniciar Upload</button>
      
      <ul>
        {state.files.map((item) => (
          <li key={item.file.name}>
            <span>{item.file.name} - {item.status} ({item.progress}%)</span>
            {item.status === 'uploading' && (
              <button onClick={() => handleCancel(item.file.name)}>Cancelar</button>
            )}
            {item.error && <span style={{ color: 'red' }}> Erro: {item.error}</span>}
          </li>
        ))}
      </ul>
    </div>
  );
};
