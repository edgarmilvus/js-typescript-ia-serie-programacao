/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.ts
// Description: Script de Aplicação Avançada
// ==========================================

// app/api/ingest/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { PDFLoader } from '@langchain/community/document_loaders/fs/pdf';
import { RecursiveCharacterTextSplitter } from 'langchain/text_splitter';
import { Document } from '@langchain/core/documents';
import { OpenAIEmbeddings } from '@langchain/openai';
import { PineconeStore } from '@langchain/pinecone';
import { Pinecone } from '@pinecone-database/pinecone';
import { existsSync, mkdirSync } from 'fs';
import { writeFile } from 'fs/promises';
import path from 'path';

/**
 * @description Interface para a resposta padronizada da API.
 * Aplica o princípio de 'Strict Type Discipline' definindo contratos explícitos.
 */
interface IngestionResponse {
  success: boolean;
  message: string;
  chunksProcessed?: number;
  error?: string;
}

/**
 * @description POST /api/ingest
 * Fluxo principal de Ingestão RAG:
 * 1. Recebe arquivo PDF via multipart/form-data.
 * 2. Salva temporariamente (simulação de storage local).
 * 3. Carrega documentos usando PDFLoader.
 * 4. Divide documentos usando RecursiveCharacterTextSplitter.
 * 5. Gera embeddings e armazena no vetor DB (Mock ou Real).
 */
export async function POST(req: NextRequest): Promise<NextResponse<IngestionResponse>> {
  try {
    // 1. Preparação do Ambiente e Validação
    const uploadDir = path.join(process.cwd(), 'tmp_uploads');
    if (!existsSync(uploadDir)) {
      mkdirSync(uploadDir, { recursive: true });
    }

    // Leitura do FormData (Next.js Web API)
    const formData = await req.formData();
    const file = formData.get('file') as File | null;

    if (!file || file.type !== 'application/pdf') {
      return NextResponse.json(
        { success: false, message: 'Apenas arquivos PDF são suportados.' },
        { status: 400 }
      );
    }

    // 2. Carregamento Físico do Arquivo (I/O)
    // Em um ambiente serverless, preferimos streams ou buffers diretos.
    // Aqui, salvamos temporariamente para demonstrar o uso de loaders de sistema de arquivos.
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    const filePath = path.join(uploadDir, file.name);
    await writeFile(filePath, buffer);

    // 3. Carregamento Lógico (Document Loading)
    // O PDFLoader extrai texto e metadados do PDF binário.
    const loader = new PDFLoader(filePath, {
      parsedItemSeparator: ' ', // Separa páginas com espaço simples
    });

    // Carrega os documentos brutos. Cada 'Document' representa uma página ou seção.
    const rawDocs = await loader.load();

    // 4. Divisão de Documentos (Chunking) - Estratégia Avançada
    // O RecursiveCharacterTextSplitter é ideal para código e texto técnico.
    // Ele tenta dividir por parágrafos, depois por linhas, e finalmente por caracteres,
    // preservando a coesão semântica.
    const textSplitter = new RecursiveCharacterTextSplitter({
      chunkSize: 1000,       // Tamanho ideal para contexto de LLMs (context window)
      chunkOverlap: 200,     // Overlap para manter contexto entre chunks (ex: nomes de funções)
      separators: ['\n\n', '\n', ' ', ''], // Hierarquia de separadores
    });

    const splitDocs = await textSplitter.splitDocuments(rawDocs);

    // Enriquecimento de Metadados (Opcional mas recomendado)
    // Adicionando metadados específicos para filtragem posterior no RAG.
    const enrichedDocs = splitDocs.map((doc) => {
      return new Document({
        pageContent: doc.pageContent,
        metadata: {
          ...doc.metadata,
          source: file.name,
          chunkDate: new Date().toISOString(),
          type: 'technical_manual',
        },
      });
    });

    // 5. Geração de Embeddings e Armazenamento Vetorial (Simulado para o Script)
    // Nota: Em produção, descomente a seção abaixo para integrar com OpenAI e Pinecone.
    /*
    const pinecone = new Pinecone({
      apiKey: process.env.PINECONE_API_KEY!,
    });
    const pineconeIndex = pinecone.Index(process.env.PINECONE_INDEX_NAME!);
    const embeddings = new OpenAIEmbeddings({
      openAIApiKey: process.env.OPENAI_API_KEY!,
    });

    await PineconeStore.fromDocuments(enrichedDocs, embeddings, {
      pineconeIndex,
    });
    */

    // Limpeza de arquivos temporários (Boa prática em Node.js)
    // await unlink(filePath); 

    // Retorno da resposta estruturada
    return NextResponse.json({
      success: true,
      message: 'Documento processado e dividido com sucesso.',
      chunksProcessed: enrichedDocs.length,
    });

  } catch (error) {
    console.error('Erro no pipeline de ingestão:', error);
    
    // Tratamento de erro tipado
    const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
    
    return NextResponse.json(
      { 
        success: false, 
        message: 'Falha na ingestão do documento.', 
        error: errorMessage 
      },
      { status: 500 }
    );
  }
}
