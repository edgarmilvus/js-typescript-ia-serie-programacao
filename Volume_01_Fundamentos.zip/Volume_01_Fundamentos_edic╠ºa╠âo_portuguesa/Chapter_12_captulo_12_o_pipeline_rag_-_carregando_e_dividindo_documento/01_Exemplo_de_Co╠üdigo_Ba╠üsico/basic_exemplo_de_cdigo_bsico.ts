/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.ts
// Description: Exemplo de Código Básico
// ==========================================

/**
 * EXEMPLO: Pipeline de Ingestão RAG (Carregamento e Divisão)
 * Contexto: Backend de uma aplicação SaaS (Node.js + LangChain)
 * Dependências necessárias: npm install langchain @langchain/core
 */

import { TextLoader } from "langchain/document_loaders/fs/text";
import { RecursiveCharacterTextSplitter } from "langchain/text_splitter";
import * as fs from "fs";
import * as path from "path";

// --- 1. DEFINIÇÃO DE TIPOS (Strict Type Discipline) ---
// Definimos interfaces explícitas para evitar 'any' e garantir contratos claros de dados.
interface ProcessedChunk {
  content: string;
  metadata: {
    source: string;
    chunkIndex: number;
    totalChunks: number;
    charCount: number;
  };
}

/**
 * --- 2. FUNÇÃO PRINCIPAL DE INGESTÃO ---
 * Esta função encapsula a lógica de carregamento e divisão.
 * Ela é 'async' pois a maioria das operações de IO e processamento é assíncrona.
 */
async function ingestAndSplitDocument(filePath: string): Promise<ProcessedChunk[]> {
  console.log(`[1] Iniciando ingestão do arquivo: ${filePath}`);

  // --- 3. CARREGAMENTO DO DOCUMENTO (Document Loading) ---
  // O TextLoader é responsável por ler o arquivo do sistema de arquivos.
  // Nota: Em produção, o arquivo viria de um upload (e.g., Multer em Express).
  const loader = new TextLoader(filePath);

  // Carrega os documentos brutos. O método load() retorna um array de Document objects.
  // Cada Document contém 'pageContent' (texto) e 'metadata' (informações sobre a fonte).
  const rawDocs = await loader.load();

  // Verificação de segurança: Garantir que o arquivo não esteja vazio.
  if (rawDocs.length === 0) {
    throw new Error("O documento carregado está vazio ou não pôde ser lido.");
  }

  console.log(`[2] Documento carregado. Conteúdo total: ${rawDocs[0].pageContent.length} caracteres.`);

  // --- 4. DIVISÃO DE TEXTO (Chunking) ---
  // Configuração do RecursiveCharacterTextSplitter.
  // 'chunkSize': Tamanho máximo de cada bloco (em caracteres).
  // 'chunkOverlap': Quantidade de caracteres que se sobrepõem entre blocos para manter o contexto.
  const textSplitter = new RecursiveCharacterTextSplitter({
    chunkSize: 1000, // Blocos de aprox. 1000 caracteres
    chunkOverlap: 200, // Sobrepõe 200 caracteres para evitar cortar frases no meio
  });

  // Aplica a divisão. O resultado é um array de novos Documents fragmentados.
  const splitDocs = await textSplitter.splitDocuments(rawDocs);

  console.log(`[3] Documento dividido em ${splitDocs.length} blocos (chunks).`);

  // --- 5. TRANSFORMAÇÃO E NORMALIZAÇÃO ---
  // Mapeamos os documentos do LangChain para nossa interface personalizada (ProcessedChunk).
  // Isso é útil para serialização JSON e envio para o banco de dados vetorial.
  const processedChunks: ProcessedChunk[] = splitDocs.map((doc, index) => ({
    content: doc.pageContent,
    metadata: {
      source: path.basename(filePath),
      chunkIndex: index,
      totalChunks: splitDocs.length,
      charCount: doc.pageContent.length,
    },
  }));

  return processedChunks;
}

// --- 6. EXECUÇÃO DO EXEMPLO (Simulação de Ambiente Web) ---
// Esta função simula o fluxo de uma requisição HTTP.
(async () => {
  try {
    // Cria um arquivo de texto temporário para simular o upload do usuário.
    const tempFilePath = "./exemplo_documento.txt";
    const dummyText = `
      Bem-vindo ao Capítulo 12 sobre RAG Pipeline.
      Neste capítulo, aprendemos sobre Document Loaders e Text Splitters.
      O processo de chunking é vital para manter o contexto.
      
      A LangChain.js facilita muito a integração com Node.js.
      Vamos explorar o RecursiveCharacterTextSplitter.
      Este separador tenta dividir por parágrafos, depois por linhas, depois por palavras.
    `.trim();
    
    fs.writeFileSync(tempFilePath, dummyText);

    // --- Chamada da função principal ---
    const chunks = await ingestAndSplitDocument(tempFilePath);

    // Simula a resposta da API (JSON)
    console.log("\n[RESULTADO] Dados prontos para Embedding/Vetor Store:");
    console.log(JSON.stringify(chunks, null, 2));

    // Limpeza do arquivo temporário
    fs.unlinkSync(tempFilePath);

  } catch (error) {
    console.error("Erro no pipeline de ingestão:", error);
  }
})();
