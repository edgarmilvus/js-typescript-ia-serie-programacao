/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.ts
// Description: Script de Aplicação Avançada
// ==========================================

// app/api/recommend/route.ts
import { NextResponse } from 'next/server';
import { Pinecone } from '@pinecone-database/pinecone';
import OpenAI from 'openai';

// ============================================================================
// CONFIGURAÇÃO E INICIALIZAÇÃO
// ============================================================================

// Inicializa o cliente OpenAI para geração de embeddings e texto.
// Idealmente, utilize variáveis de ambiente para as chaves API.
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Inicializa o cliente Pinecone.
// A configuração automática é suportada se o ambiente estiver configurado.
const pinecone = new Pinecone();

// Define o nome do index Pinecone e o namespace (ex: para um cliente específico 'client-123').
const PINECONE_INDEX_NAME = 'conteudo-saas-index';
const PINECONE_NAMESPACE = 'client-123';

// ============================================================================
// 1. FUNÇÃO DE GERAÇÃO DE EMBEDDINGS
// ============================================================================

/**
 * Gera um vetor de embedding para um texto dado usando o modelo 'text-embedding-ada-002'.
 * @param text - O texto a ser convertido em vetor.
 * @returns Um array de números representando o vetor.
 */
async function gerarEmbedding(text: string): Promise<number[]> {
  try {
    const response = await openai.embeddings.create({
      model: 'text-embedding-ada-002',
      input: text,
    });
    
    // O vetor está no primeiro item da resposta.
    return response.data[0].embedding;
  } catch (error) {
    console.error('Erro ao gerar embedding:', error);
    throw new Error('Falha na geração do vetor.');
  }
}

// ============================================================================
// 2. FUNÇÃO DE INDEXAÇÃO (UPsert)
// ============================================================================

/**
 * Armazena um documento e seu embedding no Pinecone.
 * Em uma aplicação real, isso seria um processo assíncrono (ex: via Queue).
 * 
 * @param id - Identificador único do documento (ex: ID do banco de dados SQL).
 * @param text - Texto completo do conteúdo.
 * @param metadata - Metadados para filtragem (ex: categoria, data).
 */
async function indexarDocumento(id: string, text: string, metadata: object) {
  const index = pinecone.index(PINECONE_INDEX_NAME);
  
  // Gera o embedding do texto
  const embedding = await gerarEmbedding(text);

  // Upsert: Atualiza se existir, insere se não existir.
  await index.namespace(PINECONE_NAMESPACE).upsert([
    {
      id: id,
      values: embedding,
      metadata: {
        text: text, // Armazenamos o texto original ou um resumo nos metadados
        ...metadata,
      },
    },
  ]);
  
  console.log(`Documento ${id} indexado com sucesso.`);
}

// ============================================================================
// 3. FUNÇÃO DE BUSCA POR SIMILARIDADE (RAG Retrieval)
// ============================================================================

/**
 * Busca os documentos mais similares à consulta do usuário.
 * 
 * @param query - A consulta string do usuário.
 * @param topK - Quantidade de resultados a retornar.
 * @returns Documentos recuperados com texto e metadata.
 */
async function buscarSimilaridade(query: string, topK: number = 3) {
  const index = pinecone.index(PINECONE_INDEX_NAME);
  
  // 1. Converter a consulta do usuário em um vetor
  const queryEmbedding = await gerarEmbedding(query);

  // 2. Consultar o Pinecone
  const results = await index.namespace(PINECONE_NAMESPACE).query({
    vector: queryEmbedding,
    topK: topK,
    includeMetadata: true, // Importante para trazer o texto de volta
  });

  // 3. Extrair e formatar os resultados
  if (!results.matches || results.matches.length === 0) {
    return [];
  }

  return results.matches.map((match) => ({
    score: match.score,
    content: (match.metadata as any).text, // Recuperando o texto armazenado
    category: (match.metadata as any).category,
  }));
}

// ============================================================================
// 4. FUNÇÃO DE GERAÇÃO DE RESPOSTA (LLM)
// ============================================================================

/**
 * Gera uma resposta contextualizada usando a LLM com base nos documentos recuperados.
 */
async function gerarRespostaContextualizada(query: string, context: any[]) {
  // Construção do prompt com contexto RAG
  const contextText = context.map(c => `Contexto: ${c.content} (Categoria: ${c.category})`).join('\n\n');

  const completion = await openai.chat.completions.create({
    model: 'gpt-3.5-turbo',
    messages: [
      {
        role: 'system',
        content: `
          Você é um assistente de recomendação de conteúdo para uma plataforma SaaS.
          Responda à pergunta do usuário baseando-se estritamente no contexto fornecido abaixo.
          Se o contexto não fornecer informações relevantes, diga que não encontrou nada relacionado.
          
          Contexto:
          ${contextText}
        `,
      },
      {
        role: 'user',
        content: query,
      },
    ],
    temperature: 0.3, // Baixa temperatura para fidelidade ao contexto
  });

  return completion.choices[0].message.content;
}

// ============================================================================
// 5. ENDPOINT API (NEXT.JS ROUTE HANDLER)
// ============================================================================

/**
 * POST /api/recommend
 * 
 * Fluxo Principal:
 * 1. Recebe a consulta do usuário.
 * 2. Busca vetores similares no Pinecone.
 * 3. Gera uma resposta usando a LLM com o contexto recuperado.
 */
export async function POST(req: Request) {
  try {
    const { query, mode, documentId, documentText, documentMetadata } = await req.json();

    // Modo Indexação (Ingestão de dados)
    if (mode === 'index') {
      if (!documentId || !documentText) {
        return NextResponse.json(
          { error: 'Faltam dados para indexação.' },
          { status: 400 }
        );
      }
      await indexarDocumento(documentId, documentText, documentMetadata || {});
      return NextResponse.json({ success: true, message: 'Documento indexado.' });
    }

    // Modo Busca (Recomendação RAG)
    if (mode === 'search') {
      if (!query) {
        return NextResponse.json({ error: 'Consulta vazia.' }, { status: 400 });
      }

      // 1. Recuperação Vetorial
      const documentos = await buscarSimilaridade(query);

      if (documentos.length === 0) {
        return NextResponse.json({
          answer: "Não encontrei conteúdo relevante para sua consulta.",
          sources: []
        });
      }

      // 2. Geração
      const resposta = await gerarRespostaContextualizada(query, documentos);

      return NextResponse.json({
        answer: resposta,
        sources: documentos, // Retornamos as fontes para transparência (Citations)
      });
    }

    return NextResponse.json({ error: 'Modo inválido.' }, { status: 400 });

  } catch (error) {
    console.error('Erro na API:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor.' },
      { status: 500 }
    );
  }
}
