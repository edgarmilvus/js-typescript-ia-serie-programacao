/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part2.ts
// Description: Soluções e Explicações
// ==========================================

import { Pinecone } from '@pinecone-database/pinecone';
import { OpenAI } from 'openai';

// Configuração
const pinecone = new Pinecone({ apiKey: process.env.PINECONE_API_KEY! });
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY! });
const INDEX_NAME = 'politica-privacidade';

// Tipos
type Metadata = {
  texto: string;
  data_atualizacao: string; // Formato ISO
};

/**
 * 1. Indexação no Pinecone
 * Converte texto em chunks, gera embeddings e upsert.
 */
export async function indexarPolitica(textoCompleto: string, dataAtualizacao: string) {
  const index = pinecone.Index(INDEX_NAME);
  
  // Simulação de chunking simples
  const chunks = textoCompleto.split('\n\n').slice(0, 5); // Limitando para exemplo
  
  const vectors = await Promise.all(
    chunks.map(async (chunk, i) => {
      const embeddingResponse = await openai.embeddings.create({
        model: 'text-embedding-ada-002',
        input: chunk,
      });
      
      return {
        id: `chunk-${Date.now()}-${i}`,
        values: embeddingResponse.data[0].embedding,
        metadata: {
          texto: chunk,
          data_atualizacao: dataAtualizacao
        } as Metadata
      };
    })
  );

  await index.upsert(vectors);
  console.log(`${vectors.length} vetores indexados.`);
}

/**
 * 3. Recuperação (Retrieval) com Filtro Híbrido
 */
export async function recuperarContexto(query: string, dataLimite: string) {
  const index = pinecone.Index(INDEX_NAME);
  
  // Gerar embedding da query
  const embeddingResponse = await openai.embeddings.create({
    model: 'text-embedding-ada-002',
    input: query,
  });
  const queryEmbedding = embeddingResponse.data[0].embedding;

  // Busca Vetorial com Filtro de Metadados (Hybrid Search)
  const results = await index.query({
    vector: queryEmbedding,
    topK: 4,
    includeMetadata: true,
    filter: {
      data_atualizacao: { $gte: dataLimite } // Apenas documentos atualizados após a data limite
    }
  });

  // Extrair textos dos resultados
  const contexts = results.matches
    .map(match => match.metadata?.texto)
    .filter(Boolean) as string[];

  return contexts;
}

/**
 * 4. Geração com Contexto
 */
export async function gerarResposta(query: string, contexto: string[]) {
  const systemPrompt = `
    Você é um assistente de suporte. Responda à pergunta do usuário baseando-se estritamente no contexto fornecido abaixo.
    
    Contexto:
    ${contexto.join('\n\n---\n\n')}
    
    Se a resposta não estiver no contexto, responda "Não tenho informações sobre isso na política atual.".
  `;

  const completion = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: query }
    ],
    temperature: 0.2
  });

  return completion.choices[0].message.content;
}
