/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.ts
// Description: Soluções e Explicações
// ==========================================

import { Tool } from '@langchain/core/tools';
import { z } from 'zod';
import { createOpenAIFunctionsAgent, AgentExecutor } from 'langchain/agents';
import { ChatOpenAI } from '@langchain/openai';
import { ChatPromptTemplate } from '@langchain/core/prompts';

// 1. Definição da Ferramenta com Schema (Zod)
const saldoSchema = z.object({
  contaId: z.string().describe("ID da conta bancária"),
  moeda: z.enum(['BRL', 'USD']).optional().describe("Moeda desejada (padrão BRL)")
});

export class ConsultarSaldoTool extends Tool {
  name = "consultar_saldo";
  description = "Consulte o saldo de uma conta bancária. Use para perguntas sobre valores financeiros.";
  
  // Schema de entrada para validação automática pelo LangChain
  schema = saldoSchema;

  // 2. Handler da Ferramenta
  protected async _call(arg: z.infer<typeof saldoSchema>) {
    const { contaId, moeda = 'BRL' } = arg;
    
    // Simulação de banco de dados
    const saldosReais: Record<string, number> = {
      '12345': 1500.00,
      '67890': 5000.00
    };

    const saldoBase = saldosReais[contaId];
    if (!saldoBase) return `Erro: Conta ${contaId} não encontrada.`;

    let valorFinal = saldoBase;
    let moedaFinal = moeda;

    // 3. Lógica de Conversão Simulada
    if (moeda === 'USD') {
      // Taxa de conversão fictícia: 1 USD = 5.00 BRL
      valorFinal = saldoBase / 5.00;
    }

    return `Saldo atual da conta ${contaId}: ${valorFinal.toFixed(2)} ${moedaFinal}`;
  }
}

// 4. Configuração do Agente
export async function criarAgenteFinanceiro() {
  const model = new ChatOpenAI({ model: "gpt-3.5-turbo", temperature: 0 });
  
  // Prompt template simples
  const prompt = ChatPromptTemplate.fromMessages([
    ["system", "Você é um assistente financeiro útil. Use ferramentas para responder perguntas."],
    ["human", "{input}"],
    ["placeholder", "{agent_scratchpad}"]
  ]);

  const tools = [new ConsultarSaldoTool()];

  const agent = await createOpenAIFunctionsAgent({
    llm: model,
    tools,
    prompt
  });

  const executor = new AgentExecutor({
    agent,
    tools,
    verbose: true
  });

  return executor;
}

// Exemplo de uso (simulado):
/*
const executor = await criarAgenteFinanceiro();
const result = await executor.invoke({ 
  input: "Qual o saldo da conta 12345 em dólares?" 
});
console.log(result.output);
*/
