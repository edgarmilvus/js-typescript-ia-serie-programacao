/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part5.tsx
// Description: Soluções e Explicações
// ==========================================

import React, { useState, useMemo } from 'react';
import { Scatter } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, Tooltip } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, Tooltip);

// Tipos
interface VectorPoint {
  id: string;
  embedding: number[]; // Alto dimensional
  label: string;
  // Coordenadas 2D para plotagem (simuladas ou reduzidas via PCA)
  x: number;
  y: number;
}

interface Props {
  vectors: VectorPoint[];
}

const VectorVisualizer: React.FC<Props> = ({ vectors }) => {
  const [selectedPoint, setSelectedPoint] = useState<VectorPoint | null>(null);
  const [isSelectionMode, setIsSelectionMode] = useState(false);

  // Calcular Distância Euclidiana
  const calculateDistance = (v1: number[], v2: number[]) => {
    return Math.sqrt(v1.reduce((sum, val, i) => sum + Math.pow(val - v2[i], 2), 0));
  };

  // Lógica de "Busca por Similaridade Visual"
  const highlightedIds = useMemo(() => {
    if (!isSelectionMode || !selectedPoint) return new Set();

    const distances = vectors.map(v => ({
      id: v.id,
      distance: calculateDistance(selectedPoint.embedding, v.embedding)
    }));

    // Ordenar por menor distância e pegar os 5 mais próximos
    distances.sort((a, b) => a.distance - b.distance);
    const top5 = distances.slice(1, 6); // Exclui o próprio ponto (índice 0)
    
    return new Set(top5.map(d => d.id));
  }, [selectedPoint, vectors, isSelectionMode]);

  // Preparar dados para o Chart.js
  const chartData = {
    datasets: [
      {
        label: 'Vetores',
        data: vectors.map(v => ({ x: v.x, y: v.y, original: v })),
        backgroundColor: (ctx: any) => {
          const id = ctx.raw?.original?.id;
          if (id === selectedPoint?.id) return 'red'; // Ponto selecionado
          if (isSelectionMode && highlightedIds.has(id)) return 'orange'; // Vizinhos próximos
          return 'rgba(54, 162, 235, 0.6)'; // Padrão
        },
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      tooltip: {
        callbacks: {
          label: (context: any) => {
            const v = context.raw.original as VectorPoint;
            return `${v.label.substring(0, 30)}...`; // Tooltip simplificado
          }
        }
      }
    },
    onClick: (evt: any, elements: any[]) => {
      if (elements.length > 0 && isSelectionMode) {
        const index = elements[0].index;
        setSelectedPoint(vectors[index]);
      }
    }
  };

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px' }}>
      <div style={{ marginBottom: '10px', display: 'flex', gap: '10px', alignItems: 'center' }}>
        <h3>Visualização Vetorial</h3>
        <button 
          onClick={() => setIsSelectionMode(!isSelectionMode)}
          style={{ 
            padding: '5px 10px', 
            backgroundColor: isSelectionMode ? '#d63031' : '#0984e3',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer'
          }}
        >
          {isSelectionMode ? 'Sair do Modo Seleção' : 'Entrar Modo Seleção'}
        </button>
        {isSelectionMode && <span>Clique em um ponto para encontrar vizinhos.</span>}
      </div>

      <div style={{ height: '400px' }}>
        <Scatter data={chartData} options={options} />
      </div>

      {selectedPoint && (
        <div style={{ marginTop: '15px', padding: '10px', background: '#f0f0f0' }}>
          <strong>Texto Selecionado:</strong>
          <p>{selectedPoint.label}</p>
        </div>
      )}
    </div>
  );
};

export default VectorVisualizer;
