/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.ts
// Description: Soluções e Explicações
// ==========================================

// main.ts

// Definição do Worker
const workerCode = `
  self.onmessage = async (e) => {
    const { batch, wasmModule } = e.data;
    
    // Simulação de processamento WASM (Neste exemplo, usamos lógica JS pura para simplicidade)
    // Em um cenário real, aqui carregaríamos o módulo WASM (WebAssembly.instantiate)
    // e executaríamos a função WASM para tokenização.
    
    const processedBatch = batch.map(item => ({
      ...item,
      textoLimpo: item.texto.toLowerCase().replace(/[^a-z0-9\s]/g, '') // Simulação WASM
    }));

    // Simulação de "Work Stealing": O worker pede mais trabalho se processar rápido
    self.postMessage({ type: 'result', data: processedBatch });
  };
`;

const blob = new Blob([workerCode], { type: 'application/javascript' });
const workerUrl = URL.createObjectURL(blob);

// Fila de batches pendentes
let pendingQueue: any[][] = [];
const NUM_WORKERS = 4;
const workers: Worker[] = [];

// Inicialização
export function initWorkers() {
  for (let i = 0; i < NUM_WORKERS; i++) {
    const worker = new Worker(workerUrl);
    
    worker.onmessage = (e) => {
      if (e.data.type === 'result') {
        // Processar resultados (enviar para OpenAI)
        console.log(`Worker ${i} completou batch.`);
        processarEmbeddingsOpenAI(e.data.data);
        
        // Lógica de "Work Stealing": Se houver mais trabalho na fila, envie para este worker
        if (pendingQueue.length > 0) {
          const nextBatch = pendingQueue.shift()!;
          worker.postMessage({ batch: nextBatch });
        } else {
          // Marcar worker como ocioso se necessário
        }
      } else if (e.data.type === 'requestWork') {
        // Worker pediu trabalho explicitamente
        if (pendingQueue.length > 0) {
          const nextBatch = pendingQueue.shift()!;
          worker.postMessage({ batch: nextBatch });
        }
      }
    };
    workers.push(worker);
  }
}

// Distribuição de trabalho
export function processarCSVParalelo(csvData: any[]) {
  // Dividir CSV em batches
  const batchSize = Math.ceil(csvData.length / NUM_WORKERS);
  const batches: any[][] = [];
  
  for (let i = 0; i < csvData.length; i += batchSize) {
    batches.push(csvData.slice(i, i + batchSize));
  }

  // Distribuir batches iniciais
  batches.forEach((batch, index) => {
    if (index < NUM_WORKERS) {
      workers[index].postMessage({ batch });
    } else {
      pendingQueue.push(batch); // Enchendo a fila
    }
  });
}

// Função simulada para chamar a API da OpenAI após o pré-processamento
async function processarEmbeddingsOpenAI(data: any[]) {
  // Aqui entraria a lógica de chamada à API OpenAI
  console.log("Enviando lote pré-processado para embeddings:", data.length);
}
