/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.ts
// Description: Soluções e Explicações
// ==========================================

import { createClient } from '@supabase/supabase-js';
import { OpenAI } from 'openai';

// 1. Configuração (Assumindo variáveis de ambiente configuradas)
const supabaseUrl = process.env.SUPABASE_URL!;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const openaiApiKey = process.env.OPENAI_API_KEY!;

const supabase = createClient(supabaseUrl, supabaseKey);
const openai = new OpenAI({ apiKey: openaiApiKey });

// Definição de tipos
type ArticleMetadata = {
  title: string;
  source: string;
  chunkIndex: number;
};

/**
 * 2. Processamento de Texto
 * Divide o texto em chunks baseados em parágrafos, respeitando o limite de tokens.
 */
function chunkText(text: string, maxTokens: number = 512): string[] {
  // Simplificação: Divisão por parágrafos. Em produção, use um tokenizer real (ex: tiktoken).
  const paragraphs = text.split('\n\n');
  const chunks: string[] = [];
  let currentChunk = '';

  for (const p of paragraphs) {
    // Estimativa grosseira: 1 token ≈ 4 caracteres
    if ((currentChunk + p).length / 4 > maxTokens && currentChunk !== '') {
      chunks.push(currentChunk);
      currentChunk = p;
    } else {
      currentChunk += (currentChunk ? '\n\n' : '') + p;
    }
  }
  if (currentChunk) chunks.push(currentChunk);
  return chunks;
}

/**
 * 3. Função Principal: Processar Artigo
 * Gera embeddings e insere no Supabase.
 */
export async function processarArtigo(texto: string, metadata: Omit<ArticleMetadata, 'chunkIndex'>) {
  const chunks = chunkText(texto);
  
  for (let i = 0; i < chunks.length; i++) {
    const chunk = chunks[i];
    
    // Gerar embedding
    const embeddingResponse = await openai.embeddings.create({
      model: 'text-embedding-ada-002',
      input: chunk,
    });
    const embedding = embeddingResponse.data[0].embedding;

    // Inserir no Supabase
    const { error } = await supabase
      .from('artigos_embeddings')
      .insert({
        conteudo: chunk,
        embedding: embedding,
        metadata: { ...metadata, chunkIndex: i }
      });

    if (error) {
      console.error(`Erro ao inserir chunk ${i}:`, error);
      throw error;
    }
  }
  console.log(`Artigo "${metadata.title}" processado com ${chunks.length} chunks.`);
}

/**
 * 4. Busca por Similaridade
 * Realiza busca vetorial no Supabase.
 */
export async function buscarArtigo(query: string, limit: number = 3) {
  // Gerar embedding da consulta
  const embeddingResponse = await openai.embeddings.create({
    model: 'text-embedding-ada-002',
    input: query,
  });
  const queryEmbedding = embeddingResponse.data[0].embedding;

  // Busca vetorial usando operador de similaridade de cosseno (<->)
  // O operador '<->' retorna a distância. Ordenamos pela menor distância.
  const { data, error } = await supabase
    .rpc('match_artigos', { 
      query_embedding: queryEmbedding, 
      match_threshold: 0.5, 
      match_count: limit 
    });

  if (error) {
    console.error("Erro na busca:", error);
    return [];
  }

  return data;
}

/**
 * Desafio Interativo: Atualizar Embedding
 * Garante idempotência na atualização.
 */
export async function atualizarEmbedding(id: number, novoTexto: string, metadata: Partial<ArticleMetadata>) {
  // 1. Gerar novo embedding
  const embeddingResponse = await openai.embeddings.create({
    model: 'text-embedding-ada-002',
    input: novoTexto,
  });
  const novoEmbedding = embeddingResponse.data[0].embedding;

  // 2. Atualizar registro existente (upsert ou update)
  // Assumimos que o ID é a chave primária e queremos manter o histórico ou apenas atualizar o campo.
  // Se quisermos manter a referência, atualizamos o campo 'embedding' e 'conteudo' no mesmo ID.
  const { error } = await supabase
    .from('artigos_embeddings')
    .update({
      conteudo: novoTexto,
      embedding: novoEmbedding,
      metadata: { ...metadata, updatedAt: new Date().toISOString() }
    })
    .eq('id', id);

  if (error) throw error;
  console.log(`Artigo ID ${id} atualizado com sucesso.`);
}
