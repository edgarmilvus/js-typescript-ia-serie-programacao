/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.ts
// Description: Exemplo de Código Básico
// ==========================================

// src/config/database.ts
// Este arquivo gerencia a conexão com o banco de dados Supabase.
// É uma prática comum centralizar a configuração do cliente para reutilização.

import { createClient, SupabaseClient } from '@supabase/supabase-js';

/**
 * Configuração das variáveis de ambiente.
 * Em uma aplicação real, NUNCA hardcode chaves de API.
 * Utilize variáveis de ambiente (.env) e bibliotecas como 'dotenv'.
 * 
 * @constant {string} SUPABASE_URL - A URL do seu projeto Supabase.
 * @constant {string} SUPABASE_ANON_KEY - A chave pública (anon) do seu projeto.
 */
const SUPABASE_URL: string = process.env.SUPABASE_URL || '';
const SUPABASE_ANON_KEY: string = process.env.SUPABASE_ANON_KEY || '';

/**
 * Validação básica das variáveis de ambiente.
 * Lança um erro se as chaves estiverem ausentes, impedindo a execução com configuração inválida.
 */
if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  throw new Error(
    "Erro de configuração: Variáveis de ambiente SUPABASE_URL e SUPABASE_ANON_KEY são obrigatórias."
  );
}

/**
 * Inicializa e exporta o cliente Supabase.
 * Esta instância será usada por toda a aplicação para realizar operações no banco de dados.
 * 
 * @type {SupabaseClient}
 */
export const supabase: SupabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// src/index.ts
// Ponto de entrada da nossa aplicação "Hello World".

import { supabase } from './config/database';

/**
 * Função principal que demonstra a conexão com o banco de dados.
 * Em uma aplicação web real, esta função seria chamada durante a inicialização do servidor
 * ou no carregamento de um componente cliente (ex: Next.js useEffect).
 */
async function inicializarConexao(): Promise<void> {
  console.log('Iniciando a conexão com o Supabase...');

  try {
    // O método 'from' seleciona a tabela. Aqui usamos 'test_table' apenas para exemplo.
    // O método 'select' tenta recuperar dados.
    // Se a tabela não existir ou houver erro de permissão, o erro será capturado.
    const { data, error } = await supabase
      .from('test_table') // Substitua por uma tabela real no seu banco
      .select('*')
      .limit(1);

    if (error) {
      console.error('Erro ao conectar ou consultar dados:', error.message);
      // Em um ambiente de produção, logar erros de forma estruturada (ex: Sentry, Datadog)
      return;
    }

    console.log('Conexão estabelecida com sucesso!');
    console.log('Resultado da consulta básica:', data ? 'Dados recebidos' : 'Sem dados');

  } catch (err) {
    console.error('Exceção inesperada durante a inicialização:', err);
  }
}

// Executa a função de inicialização.
// Nota: Em um servidor Node.js, você chamaria isso no início do script.
// Em uma aplicação web (Frontend), isso seria chamado sob demanda ou em hooks de ciclo de vida.
inicializarConexao();
