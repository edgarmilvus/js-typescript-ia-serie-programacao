/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.ts
// Description: Soluções e Explicações
// ==========================================

import OpenAI from 'openai';
import { z } from 'zod';
import { zodResponseFormat } from 'openai/helpers/zod';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// 1. Definição do Schema de Dados (Zod)
const ReceiptSchema = z.object({
    storeName: z.string().nullable(),
    date: z.string().nullable(), // Formato ISO ou texto
    totalAmount: z.number().nullable(),
    items: z.array(z.string()).nullable()
});

type ReceiptData = z.infer<typeof ReceiptSchema> & { needsManualReview?: boolean };

// 2. Função de Extração
export async function extractReceiptData(imageBuffer: Buffer): Promise<ReceiptData> {
    const base64Image = imageBuffer.toString('base64');

    const response = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
            {
                role: "system",
                content: `
                    Você é um assistente de extração de dados de recibos.
                    Extraia as informações da imagem fornecida.
                    Retorne um JSON estritamente válido baseado no schema fornecido.
                    Se um campo não for encontrado, use null.
                    Campos: storeName (string), date (string), totalAmount (number), items (array de strings).
                `
            },
            {
                role: "user",
                content: [
                    { type: "text", text: "Extrai os dados deste recibo." },
                    { type: "image_url", image_url: { url: `data:image/jpeg;base64,${base64Image}` } }
                ]
            }
        ],
        response_format: zodResponseFormat(ReceiptSchema, "receipt"),
    });

    const content = response.choices[0].message.parsed;
    
    if (!content) {
        throw new Error("Falha ao extrair dados ou parsing falhou.");
    }

    // Retorno inicial sem verificação de consistência
    return {
        storeName: content.storeName,
        date: content.date,
        totalAmount: content.totalAmount,
        items: content.items
    };
}

// 3. Função de Processamento em Lote com Pós-processamento
export async function processBatchReceipts(imageBuffers: Buffer[]): Promise<ReceiptData[]> {
    const results: ReceiptData[] = [];

    for (const buffer of imageBuffers) {
        try {
            const data = await extractReceiptData(buffer);
            
            // 4. Lógica de Pós-processamento de Consistência
            if (data.items && data.totalAmount !== null) {
                // Simulação simples: soma de itens fictícios (extraídos como texto)
                // Nota: Em cenário real, você precisaria parsear valores monetários dos strings de items.
                // Aqui assumimos que 'items' contém valores ou calculamos uma média para simulação.
                
                // Para este exemplo, vamos simular uma verificação:
                // Se houver muitos itens (>5) e o total for baixo (< 10), marcamos para revisão.
                // Ou se o total for 0 e itens existem.
                
                let shouldFlag = false;

                // Exemplo de lógica heurística (já que não temos OCR numérico dos itens)
                if (data.items.length > 0 && data.totalAmount === 0) {
                    shouldFlag = true;
                }

                // Se a lógica anterior detectar inconsistência
                if (shouldFlag) {
                    data.needsManualReview = true;
                } else {
                    data.needsManualReview = false;
                }
            }

            results.push(data);
        } catch (error) {
            console.error("Erro ao processar recibo:", error);
            // Poderia adicionar um objeto de erro vazio ou pular
        }
    }

    return results;
}

/* 
Exemplo de uso (simulado):
const fs = require('fs');
const buffers = [fs.readFileSync('recibo1.jpg'), fs.readFileSync('recibo2.jpg')];
processBatchReceipts(buffers).then(console.log);
*/
