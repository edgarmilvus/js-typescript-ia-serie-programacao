/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.ts
// Description: Soluções e Explicações
// ==========================================

import { StateGraph, END, MessageGraph } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai";
import { HumanMessage, SystemMessage } from "@langchain/core/messages";

// 1. Definição do Estado Compartilhado
interface AgentState {
    imageUrl: string;
    userDescription: string;
    visualAnalysis?: string;
    validatorOutput?: string; // Contém a pontuação
    detectorOutput?: string;  // Contém a pontuação
    finalVerdict?: string;
    scores?: { validation: number; completeness: number };
}

// Inicialização do Modelo LLM
const llm = new ChatOpenAI({ 
    model: "gpt-4o-mini", 
    temperature: 0 
});

// 2. Nós do Grafo

// Nó 1: Análise Visual (Entry Point)
const visualAnalysisNode = async (state: AgentState): Promise<Partial<AgentState>> => {
    const prompt = new SystemMessage("Descreva esta imagem detalhadamente focando em produtos e cores. Retorne apenas o texto descritivo.");
    const userMsg = new HumanMessage({ content: [{ type: "image_url", image_url: { url: state.imageUrl } }] });
    
    const response = await llm.invoke([prompt, userMsg]);
    return { visualAnalysis: response.content as string };
};

// Nó 2: Agente Validador (Texto vs Imagem)
const validatorNode = async (state: AgentState): Promise<Partial<AgentState>> => {
    const prompt = `
        Compare a descrição visual (abaixo) com a descrição do usuário.
        Avalie a correspondência factual (cores, tipo de produto).
        Retorne uma pontuação de 0 a 100 e uma breve justificativa.
        Formato: "Pontuação: [numero]\nJustificativa: [texto]"
    `;
    const response = await llm.invoke([
        new SystemMessage(prompt),
        new HumanMessage(`Visual: ${state.visualAnalysis}\nUsuário: ${state.userDescription}`)
    ]);
    return { validatorOutput: response.content as string };
};

// Nó 3: Agente Detector (Omissões)
const detectorNode = async (state: AgentState): Promise<Partial<AgentState>> => {
    const prompt = `
        Analise a imagem e a descrição do usuário. Identifique elementos visuais IMPORTANTES presentes na imagem que NÃO foram mencionados.
        Dê uma pontuação de completude de 0 a 100 (100 = sem omissões importantes).
        Formato: "Pontuação: [numero]\nOmissões: [texto]"
    `;
    const response = await llm.invoke([
        new SystemMessage(prompt),
        new HumanMessage(`Imagem (via contexto visual): ${state.visualAnalysis}\nUsuário: ${state.userDescription}`)
    ]);
    return { detectorOutput: response.content as string };
};

// Nó 4: Supervisor (Síntese e Consenso)
const supervisorNode = async (state: AgentState): Promise<Partial<AgentState>> => {
    // Parsing das pontuações (Regex para extrair números)
    const valMatch = state.validatorOutput?.match(/Pontuação:\s*(\d+)/);
    const detMatch = state.detectorOutput?.match(/Pontuação:\s*(\d+)/);

    const validationScore = valMatch ? parseInt(valMatch[1]) : 0;
    const completenessScore = detMatch ? parseInt(detMatch[1]) : 0;

    // Lógica de Consenso Interativo: Média Ponderada
    // Damos mais peso à validação (60%) do que à completude (40%)
    const weightedAverage = (validationScore * 0.6) + (completenessScore * 0.4);
    
    let verdict = "";
    if (weightedAverage > 80) verdict = "Aprovado";
    else if (weightedAverage >= 50) verdict = "Revisão Parcial";
    else verdict = "Revisão Urgente";

    return {
        finalVerdict: verdict,
        scores: { validation: validationScore, completeness: completenessScore }
    };
};

// 3. Construção do Grafo
const workflow = new StateGraph<AgentState>({
    channels: {
        imageUrl: { value: null },
        userDescription: { value: null },
        visualAnalysis: { value: null },
        validatorOutput: { value: null },
        detectorOutput: { value: null },
        finalVerdict: { value: null },
        scores: { value: null }
    }
});

// Adição dos Nós
workflow.addNode("visual_analysis", visualAnalysisNode);
workflow.addNode("text_validator", validatorNode);
workflow.addNode("omission_detector", detectorNode);
workflow.addNode("supervisor", supervisorNode);

// Definição do Fluxo (Graph Edges)
workflow.setEntryNode("visual_analysis");
workflow.addEdge("visual_analysis", "text_validator");
workflow.addEdge("visual_analysis", "omission_detector");

// O Supervisor espera pelos dois agentes (Padrão Fork/Join)
workflow.addNode("join_agents", async (state) => state); // Nó de junção simples
workflow.addEdge("text_validator", "join_agents");
workflow.addEdge("omission_detector", "join_agents");
workflow.addEdge("join_agents", "supervisor");
workflow.addEdge("supervisor", END);

// Compilação do Grafo
const app = workflow.compile();

// 4. Função de Execução
export async function runVerificationPipeline(imageUrl: string, userDescription: string) {
    console.log("Iniciando pipeline de verificação...");
    const inputs = { imageUrl, userDescription };
    
    // Execução do grafo
    const finalState = await app.invoke(inputs);
    
    console.log("=== RESULTADO FINAL ===");
    console.log(`Veredicto: ${finalState.finalVerdict}`);
    console.log(`Pontuação Validação: ${finalState.scores?.validation}`);
    console.log(`Pontuação Completude: ${finalState.scores?.completeness}`);
    
    return finalState;
}

/* 
Exemplo de uso:
runVerificationPipeline(
    "https://example.com/product.jpg", 
    "Um smartphone preto na caixa."
);
*/
