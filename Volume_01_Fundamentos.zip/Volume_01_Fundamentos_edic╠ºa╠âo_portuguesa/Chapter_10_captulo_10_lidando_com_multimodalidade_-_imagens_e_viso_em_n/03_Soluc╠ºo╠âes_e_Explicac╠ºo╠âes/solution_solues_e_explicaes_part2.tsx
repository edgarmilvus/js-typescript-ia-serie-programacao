/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part2.tsx
// Description: Soluções e Explicações
// ==========================================

import React, { useState } from 'react';

// Tipagem para o resultado da análise
interface AnalysisResult {
    description: string;
    categories: string[];
}

// Mock da API para simulação
const mockAnalyzeImage = (file: File): Promise<AnalysisResult> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            // Simula resultados diferentes baseados no nome do arquivo (apenas para demo)
            const isTech = file.name.toLowerCase().includes('tech');
            resolve({
                description: `Esta é uma descrição detalhada da imagem ${file.name}. Ela mostra elementos visuais complexos e cores vibrantes.`,
                categories: isTech ? ["Tecnologia", "Outro"] : ["Natureza", "Retrato"]
            });
        }, 2000); // Delay de 2 segundos
    });
};

const ImageAnalyzerComponent: React.FC = () => {
    // Estados para a primeira imagem
    const [image1, setImage1] = useState<File | null>(null);
    const [preview1, setPreview1] = useState<string | null>(null);
    const [result1, setResult1] = useState<AnalysisResult | null>(null);

    // Estados para a segunda imagem (Comparação)
    const [image2, setImage2] = useState<File | null>(null);
    const [preview2, setPreview2] = useState<string | null>(null);
    const [result2, setResult2] = useState<AnalysisResult | null>(null);

    const [loading, setLoading] = useState(false);

    // Handler de upload genérico
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, setImage: React.Dispatch<React.SetStateAction<File | null>>, setPreview: React.Dispatch<React.SetStateAction<string | null>>) => {
        const file = e.target.files?.[0];
        if (file) {
            setImage(file);
            setPreview(URL.createObjectURL(file));
        }
    };

    // Função de análise
    const handleAnalyze = async (image: File, setResult: React.Dispatch<React.SetStateAction<AnalysisResult | null>>) => {
        if (!image) return;
        setLoading(true);
        try {
            const data = await mockAnalyzeImage(image);
            setResult(data);
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    // Renderiza badges de categoria com destaque visual
    const renderCategories = (cats: string[], isComparison: boolean = false) => (
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginTop: '8px' }}>
            {cats.map((cat, idx) => {
                // Lógica simples de destaque: se for comparação, cores alternadas
                const color = isComparison 
                    ? (idx % 2 === 0 ? '#4caf50' : '#2196f3') 
                    : '#607d8b';
                return (
                    <span key={idx} style={{
                        backgroundColor: color,
                        color: 'white',
                        padding: '4px 8px',
                        borderRadius: '12px',
                        fontSize: '0.8rem',
                        fontWeight: 'bold'
                    }}>
                        {cat}
                    </span>
                );
            })}
        </div>
    );

    return (
        <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
            <h2>Image Analyzer & Comparator</h2>
            
            {/* Seção 1: Upload e Análise da Imagem 1 */}
            <div style={{ marginBottom: '20px', padding: '10px', border: '1px solid #ccc' }}>
                <h3>Imagem 1</h3>
                <input type="file" accept="image/*" onChange={(e) => handleFileChange(e, setImage1, setPreview1)} />
                {preview1 && <img src={preview1} alt="Preview 1" style={{ maxWidth: '200px', maxHeight: '150px', display: 'block', marginTop: '10px' }} />}
                <button 
                    onClick={() => handleAnalyze(image1!, setResult1)} 
                    disabled={!image1 || loading}
                    style={{ marginTop: '10px' }}
                >
                    {loading ? 'Analisando...' : 'Analisar Imagem'}
                </button>
                
                {result1 && (
                    <div style={{ marginTop: '10px', backgroundColor: '#f5f5f5', padding: '10px' }}>
                        <p><strong>Descrição:</strong> {result1.description}</p>
                        {renderCategories(result1.categories)}
                    </div>
                )}
            </div>

            {/* Seção 2: Comparação (Visível apenas após primeira análise) */}
            {result1 && (
                <div style={{ padding: '10px', border: '2px dashed #2196f3' }}>
                    <h3>Modo Comparação</h3>
                    <p>Carregue uma segunda imagem para comparar os resultados.</p>
                    
                    <input type="file" accept="image/*" onChange={(e) => handleFileChange(e, setImage2, setPreview2)} />
                    {preview2 && <img src={preview2} alt="Preview 2" style={{ maxWidth: '200px', maxHeight: '150px', display: 'block', marginTop: '10px' }} />}
                    
                    <button 
                        onClick={() => handleAnalyze(image2!, setResult2)} 
                        disabled={!image2 || loading}
                        style={{ marginTop: '10px', backgroundColor: '#2196f3', color: 'white' }}
                    >
                        {loading ? 'Analisando...' : 'Comparar'}
                    </button>

                    {result2 && (
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginTop: '20px' }}>
                            {/* Coluna 1 */}
                            <div style={{ padding: '10px', backgroundColor: '#e8f5e9' }}>
                                <h4>Imagem 1</h4>
                                <p>{result1.description}</p>
                                {renderCategories(result1.categories, true)}
                            </div>
                            {/* Coluna 2 */}
                            <div style={{ padding: '10px', backgroundColor: '#e3f2fd' }}>
                                <h4>Imagem 2</h4>
                                <p>{result2.description}</p>
                                {renderCategories(result2.categories, true)}
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default ImageAnalyzerComponent;
