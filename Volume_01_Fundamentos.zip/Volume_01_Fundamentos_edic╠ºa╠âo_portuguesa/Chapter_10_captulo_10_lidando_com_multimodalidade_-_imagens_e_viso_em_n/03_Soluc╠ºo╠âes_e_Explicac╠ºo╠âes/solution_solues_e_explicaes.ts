/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.ts
// Description: Soluções e Explicações
// ==========================================

import fs from 'fs/promises';
import path from 'path';
import OpenAI from 'openai';
import { z } from 'zod';

// Configuração do cliente OpenAI (certifique-se de ter a variável OPENAI_API_KEY definida)
const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
});

// Definição das categorias permitidas para garantir consistência
const CATEGORIES = ["Natureza", "Retrato", "Tecnologia", "Comida", "Outro"];

/**
 * Analisa e categoriza uma única imagem do disco local.
 * @param imagePath Caminho absoluto ou relativo da imagem.
 * @returns Promise com objeto contendo descrição e lista de categorias.
 */
export async function analyzeAndCategorizeImage(imagePath: string): Promise<{ description: string; categories: string[] }> {
    try {
        // 1. Leitura e conversão da imagem para Base64
        const imageBuffer = await fs.readFile(imagePath);
        const base64Image = imageBuffer.toString('base64');

        // 2. Definição do Schema com Zod para validação da resposta
        const responseSchema = z.object({
            description: z.string().min(10, "Descrição muito curta"),
            categories: z.array(z.string()).refine(
                (cats) => cats.every(c => CATEGORIES.includes(c)),
                { message: "Categoria inválida detectada" }
            )
        });

        // 3. Construção do Prompt para a API
        const systemPrompt = `
            Você é um assistente de organização de mídia. Analise a imagem fornecida.
            Retorne um JSON estruturado contendo:
            1. "description": Uma descrição detalhada do conteúdo visual.
            2. "categories": Uma lista de categorias escolhidas estritamente da lista: ${CATEGORIES.join(', ')}.
        `;

        // 4. Chamada da API da OpenAI (GPT-4o mini)
        const response = await openai.chat.completions.create({
            model: "gpt-4o-mini",
            messages: [
                { role: "system", content: systemPrompt },
                {
                    role: "user",
                    content: [
                        { type: "text", text: "Analise esta imagem." },
                        { type: "image_url", image_url: { url: `data:image/jpeg;base64,${base64Image}` } }
                    ],
                },
            ],
            response_format: { type: "json_object" },
            temperature: 0.1, // Baixa temperatura para categorização precisa
        });

        const content = response.choices[0].message.content;
        if (!content) throw new Error("Resposta vazia da API");

        // 5. Validação e Parsing da resposta
        const parsedData = JSON.parse(content);
        const validatedData = responseSchema.parse(parsedData);

        return validatedData;

    } catch (error) {
        console.error(`Erro ao processar ${imagePath}:`, error);
        // Relança o erro para ser capturado pelo loop de lote
        throw error;
    }
}

/**
 * Processa um lote de imagens sequencialmente com resiliência a falhas.
 * @param imagePaths Array de caminhos de imagem.
 * @param outputDir Diretório para salvar resultados e logs.
 */
export async function processImageBatch(imagePaths: string[], outputDir: string = './output') {
    // Garante que o diretório de saída exista
    await fs.mkdir(outputDir, { recursive: true });
    
    const results: any[] = [];
    const errors: string[] = [];

    console.log(`Iniciando processamento de ${imagePaths.length} imagens...`);

    // Processamento Sequencial (para evitar limites de taxa/rate limit)
    for (const imagePath of imagePaths) {
        try {
            console.log(`Processando: ${path.basename(imagePath)}`);
            const result = await analyzeAndCategorizeImage(imagePath);
            
            results.push({
                file: imagePath,
                ...result
            });
        } catch (error) {
            // Registro de falha sem interromper o loop
            const errorMsg = `Falha em ${imagePath}: ${(error as Error).message}`;
            errors.push(errorMsg);
            console.warn(errorMsg);
        }
    }

    // Salvamento dos arquivos de saída
    await fs.writeFile(
        path.join(outputDir, 'results.json'), 
        JSON.stringify(results, null, 2)
    );

    if (errors.length > 0) {
        await fs.writeFile(
            path.join(outputDir, 'errors.log'), 
            errors.join('\n')
        );
    }

    console.log(`Processamento concluído. ${results.length} sucesso(s), ${errors.length} falha(s).`);
}

// Exemplo de uso (descomente para executar):
/*
const images = ['./img1.jpg', './img2.jpg', './img3.jpg'];
processImageBatch(images);
*/
