/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part5.ts
// Description: Soluções e Explicações
// ==========================================

import http from 'http';
import { setTimeout } from 'timers/promises';

// Simulação de função de processamento pesado (Pré-processamento)
async function simulateHeavyPreprocessing(imageUrl: string): Promise<void> {
    const start = Date.now();
    // Simula um bloqueio CPU-bound de 1.5 segundos (não recomendado em produção real, mas útil para teste)
    // Em Node.js, isso bloquearia o event loop se não fosse isolado, mas aqui simulamos o delay.
    // Para verdadeira paralelização, usariamos Worker Threads, mas o desafio pede simulação de não-bloqueio via async.
    await setTimeout(1500); 
    console.log(`[Preprocess] Imagem ${imageUrl} pré-processada em ${Date.now() - start}ms`);
}

// Simulação de chamada de API (I/O bound)
async function callInferenceAPI(imageUrl: string): Promise<string> {
    console.log(`[API] Chamando API para ${imageUrl}...`);
    await setTimeout(1000); // Simula latência de rede
    return `Descrição gerada para ${imageUrl}`;
}

// Função principal de Headless Inference
export async function processImageHeadless(imageUrl: string): Promise<string> {
    console.log(`[Start] Iniciando processamento: ${imageUrl}`);
    
    // Esta função é async, permitindo que o await libere o event loop
    await simulateHeavyPreprocessing(imageUrl);
    
    const description = await callInferenceAPI(imageUrl);
    
    console.log(`[Done] Concluído: ${imageUrl}`);
    return description;
}

// Simulação do Servidor HTTP
const server = http.createServer(async (req, res) => {
    if (req.method === 'POST' && req.url === '/analyze') {
        let body = '';
        
        // Leitura do corpo da requisição
        req.on('data', chunk => { body += chunk; });
        
        req.on('end', async () => {
            try {
                const { imageUrl } = JSON.parse(body);
                
                // Disparo da função assíncrona
                // Importante: Não usamos 'await' aqui dentro do callback de evento 'end' 
                // de forma a bloquear a resposta imediatamente? 
                // Na verdade, para este exemplo, queremos que a requisição espere o resultado.
                // Mas para demonstrar concorrência, o servidor deve aceitar novas conexões enquanto processa.
                
                const description = await processImageHeadless(imageUrl);
                
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ description }));
            } catch (e) {
                res.writeHead(500);
                res.end('Error');
            }
        });
    } else {
        res.writeHead(404);
        res.end('Not Found');
    }
});

// Inicia o servidor
const PORT = 3000;
server.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
    console.log('Use o script cliente para enviar requisições.');
});

/* 
Script Cliente (Simulação de requisições concorrentes)
Salve como client.ts e execute separadamente ou use curl em terminais diferentes.
*/
/*
import http from 'http';

function sendRequest(id: number) {
    const payload = JSON.stringify({ imageUrl: `img_${id}.jpg` });
    const options = {
        hostname: 'localhost',
        port: 3000,
        path: '/analyze',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(payload)
        }
    };

    const start = Date.now();
    console.log(`[Client ${id}] Enviado`);

    const req = http.request(options, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
            console.log(`[Client ${id}] Recebido em ${Date.now() - start}ms: ${data}`);
        });
    });

    req.on('error', (e) => console.error(e));
    req.write(payload);
    req.end();
}

// Envia 3 requisições quase simultaneamente
setTimeout(() => sendRequest(1), 0);
setTimeout(() => sendRequest(2), 100); // Pequeno delay para simular "concorrência"
setTimeout(() => sendRequest(3), 200);
*/
