/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.ts
// Description: Exemplo de Código Básico
// ==========================================

// index.ts
import fs from 'fs'; // Módulo nativo do Node.js para manipulação de arquivos do sistema.
import OpenAI from 'openai'; // SDK oficial da OpenAI para TypeScript.

/**
 * Configuração Inicial da Aplicação.
 * 
 * Aqui inicializamos o cliente da OpenAI. Em um ambiente de produção (SaaS),
 * a chave API deve ser carregada via variável de ambiente (process.env.OPENAI_API_KEY)
 * para segurança. Neste exemplo, usamos uma string direta para facilitar o teste local.
 */
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || 'SUA_CHAVE_API_AQUI', // Substitua pela sua chave real.
});

/**
 * Função Principal: describeImage
 * 
 * Esta função encapsula a lógica de envio de uma imagem multimodal.
 * Ela demonstra o padrão assíncrono essencial para operações de I/O em Node.js.
 * 
 * @param imagePath - O caminho local para o arquivo de imagem.
 * @returns - A descrição textual gerada pelo modelo.
 */
async function describeImage(imagePath: string): Promise<string> {
  console.log(`Iniciando processamento da imagem: ${imagePath}`);

  // 1. Leitura e Codificação (Base64)
  // Como a API não aceita arquivos binários brutos diretamente no corpo JSON,
  // convertemos a imagem em uma string Base64. Isso aumenta o tamanho dos dados
  // em aproximadamente 33%, mas garante compatibilidade com HTTP/JSON.
  try {
    const imageBuffer = fs.readFileSync(imagePath);
    const base64Image = imageBuffer.toString('base64');

    // 2. Construção do Prompt Multimodal
    // Diferente de um chat de texto puro, aqui passamos um array de mensagens.
    // O objeto 'content' é um array que pode conter texto e imagens.
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini', // Modelo otimizado para visão e custo.
      messages: [
        {
          role: 'user',
          content: [
            { 
              type: 'text', 
              text: 'Analise esta imagem com atenção aos detalhes. Descreva o que você vê, incluindo cores, objetos e ações.' 
            },
            {
              type: 'image_url',
              image_url: {
                // A estrutura 'url' aceita dados Base64 formatados.
                // O prefixo é obrigatório: data:image/jpeg;base64,...
                url: `data:image/jpeg;base64,${base64Image}`,
                // A 'detail' controla a resolução da análise. 'high' escaneia a imagem
                // em 512px quadrados (mais detalhado, mais tokens), 'low' usa 512px total.
                detail: 'high' 
              }
            }
          ]
        }
      ],
      max_tokens: 300 // Limite de resposta para controlar custos e tamanho.
    });

    // 3. Extração da Resposta
    // A estrutura da resposta contém 'choices', onde a primeira opção
    // contém a mensagem do assistente.
    const description = response.choices[0].message.content;
    
    if (!description) {
      throw new Error("A IA retornou uma resposta vazia.");
    }

    return description;

  } catch (error) {
    // Tratamento de erro robusto é crítico em aplicações web.
    console.error("Erro durante a análise da imagem:", error);
    throw new Error("Falha na análise visual.");
  }
}

// --- Execução do Script ---
// Em um servidor web (Express/Fastify), esta lógica seria chamada dentro de um controller HTTP.
const main = async () => {
  const imagePath = './exemplo.jpg'; // Certifique-se que este arquivo existe!

  if (!fs.existsSync(imagePath)) {
    console.error(`Erro: O arquivo '${imagePath}' não foi encontrado na pasta raiz.`);
    console.error("Por favor, adicione uma imagem de teste para continuar.");
    return;
  }

  try {
    console.log("--- Aguardando resposta da OpenAI (isso pode levar alguns segundos) ---");
    const descricao = await describeImage(imagePath);
    
    console.log("\n--- Resultado da Análise Visual ---");
    console.log(descricao);
    console.log("------------------------------------");
    
  } catch (error) {
    console.error("Falha na execução principal:", error);
  }
};

main();
