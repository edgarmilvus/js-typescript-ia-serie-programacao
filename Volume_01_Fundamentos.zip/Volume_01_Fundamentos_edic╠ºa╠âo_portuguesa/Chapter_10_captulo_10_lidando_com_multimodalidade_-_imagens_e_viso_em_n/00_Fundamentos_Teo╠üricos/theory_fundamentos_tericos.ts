/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_fundamentos_tericos.ts
// Description: Fundamentos Teóricos
// ==========================================

// Exemplo ilustrativo da preparação de uma imagem para envio à API
import * as fs from 'fs';
import * as path from 'path';

// Função para codificar uma imagem local para Base64
const encodeImageToBase64 = (imagePath: string): string => {
    // Lê o arquivo como um buffer binário
    const imageBuffer = fs.readFileSync(path.resolve(imagePath));
    // Converte o buffer para uma string Base64
    return imageBuffer.toString('base64');
};

// O payload que será enviado para a API de IA
const prepareMultimodalPayload = (imagePath: string, userPrompt: string) => {
    const base64Image = encodeImageToBase64(imagePath);
    
    return {
        model: "gpt-4-vision-preview", // Modelo capaz de processar imagens
        messages: [
            {
                role: "user",
                content: [
                    {
                        type: "text",
                        text: userPrompt // O contexto textual (ex: "Descreva esta imagem")
                    },
                    {
                        type: "image_url",
                        image_url: {
                            // A imagem é passada como um objeto data URL
                            url: `data:image/jpeg;base64,${base64Image}`
                        }
                    }
                ]
            }
        ],
        max_tokens: 300
    };
};
