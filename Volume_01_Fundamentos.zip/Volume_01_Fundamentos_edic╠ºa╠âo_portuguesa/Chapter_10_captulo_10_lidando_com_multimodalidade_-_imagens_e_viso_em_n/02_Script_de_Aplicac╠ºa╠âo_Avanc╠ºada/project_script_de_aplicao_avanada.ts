/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.ts
// Description: Script de Aplicação Avançada
// ==========================================

// /app/api/process-image/route.ts
import { NextResponse } from 'next/server';
import OpenAI from 'openai';

// Configuração da instância da OpenAI
// Certifique-se de ter a variável de ambiente OPENAI_API_KEY configurada
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Interface para definir a estrutura da resposta esperada da IA.
 * Isso garante tipagem segura e evita erros em tempo de execução.
 */
interface ImageAnalysisResponse {
  productName: string;
  category: string;
  color: string;
  description: string;
  keyFeatures: string[];
}

export async function POST(request: Request) {
  try {
    // 1. Recebimento dos dados do frontend
    const body = await request.json();
    const { imageBase64 } = body;

    if (!imageBase64) {
      return NextResponse.json(
        { error: 'Nenhuma imagem fornecida.' },
        { status: 400 }
      );
    }

    // 2. Análise Multimodal com GPT-4 Vision
    // Prompt de sistema detalhado para estruturar a resposta em JSON
    const systemPrompt = `
      Você é um assistente especializado em catalogação de produtos para e-commerce.
      Analise a imagem fornecida e retorne um JSON estruturado com os seguintes campos:
      - "productName": Nome comercial do produto.
      - "category": Categoria principal (ex: Eletrônicos, Vestuário, Casa).
      - "color": Cor dominante ou principal.
      - "description": Uma descrição marketing curta (1 frase).
      - "keyFeatures": Lista de 3 características visíveis.
      Responda exclusivamente com o JSON, sem texto adicional.
    `;

    const visionResponse = await openai.chat.completions.create({
      model: 'gpt-4-vision-preview',
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: systemPrompt },
            {
              type: 'image_url',
              image_url: {
                url: `data:image/jpeg;base64,${imageBase64}`,
                detail: 'high',
              },
            },
          ],
        },
      ],
      max_tokens: 500,
      response_format: { type: 'json_object' }, // Forçando a IA a retornar JSON válido
    });

    // Parse da resposta da IA
    const content = visionResponse.choices[0].message.content;
    if (!content) throw new Error('Resposta vazia da IA.');

    const analysis: ImageAnalysisResponse = JSON.parse(content);

    // 3. Geração de Embeddings para Vetorização
    // Usamos o campo 'description' ou uma combinação de campos para gerar o vetor
    // Aqui combinamos o nome e a descrição para um embedding mais rico
    const textToEmbed = `${analysis.productName}: ${analysis.description}`;

    const embeddingResponse = await openai.embeddings.create({
      model: 'text-embedding-3-small',
      input: textToEmbed,
    });

    const embedding = embeddingResponse.data[0].embedding;

    // 4. Preparação para Inserção no Pinecone (Simulação)
    // Em um cenário real, você conectaria o cliente Pinecone aqui.
    // Estrutura do documento para o Pinecone:
    const vectorDocument = {
      id: `prod_${Date.now()}`, // ID único
      values: embedding,        // O vetor numérico
      metadata: {               // Metadados para filtragem e recuperação
        ...analysis,
        timestamp: new Date().toISOString(),
      },
    };

    // Simulação de sucesso da inserção (descomente para usar Pinecone real)
    // const pinecone = new PineconeClient();
    // await pinecone.init({ environment: 'us-west1-gcp' });
    // const index = pinecone.Index('product-catalog');
    // await index.upsert([vectorDocument]);

    // 5. Retorno dos dados para o Frontend
    return NextResponse.json({
      success: true,
      metadata: analysis,
      embeddingGenerated: true,
      vectorId: vectorDocument.id,
    });

  } catch (error) {
    console.error('Erro no processamento de imagem:', error);
    return NextResponse.json(
      { error: 'Falha ao processar a imagem.' },
      { status: 500 }
    );
  }
}
