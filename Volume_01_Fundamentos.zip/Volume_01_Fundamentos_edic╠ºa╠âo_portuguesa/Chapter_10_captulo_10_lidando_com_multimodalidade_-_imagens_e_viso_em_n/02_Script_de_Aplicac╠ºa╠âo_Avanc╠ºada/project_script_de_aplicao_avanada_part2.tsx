/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada_part2.tsx
// Description: Script de Aplicação Avançada
// ==========================================

// /app/components/ImageUpload.tsx
'use client';

import { useState, ChangeEvent, FormEvent } from 'react';

// Interface para o estado do componente
interface AnalysisResult {
  productName: string;
  category: string;
  color: string;
  description: string;
  keyFeatures: string[];
}

export default function ImageUpload() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  /**
   * Manipula a seleção de arquivo do input.
   * Cria uma URL de pré-visualização para feedback imediato ao usuário.
   */
  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
      setResult(null); // Limpa resultados anteriores
      setError(null);
    }
  };

  /**
   * Converte um arquivo Blob (File) para uma string Base64.
   * Esta etapa é necessária para enviar a imagem via JSON para a API Route.
   */
  const convertFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  };

  /**
   * Lida com o envio do formulário.
   * Fluxo: Converter -> Enviar API -> Atualizar Estado.
   */
  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!selectedFile) return;

    setLoading(true);
    setError(null);

    try {
      // 1. Conversão para Base64 (removendo o prefixo "data:image/...;base64,")
      const base64Image = (await convertFileToBase64(selectedFile)).split(',')[1];

      // 2. Requisição para a API Route do Next.js
      const response = await fetch('/api/process-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: base64Image }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Erro desconhecido.');
      }

      // 3. Atualização do estado com metadados extraídos
      setResult(data.metadata);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white shadow-lg rounded-lg">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">
        Catálogo Inteligente
      </h2>
      
      {/* Formulário de Upload */}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-500 transition-colors">
          <input
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
          />
        </div>

        {previewUrl && (
          <div className="mt-4">
            <img
              src={previewUrl}
              alt="Preview"
              className="max-h-64 mx-auto rounded-md object-contain"
            />
          </div>
        )}

        <button
          type="submit"
          disabled={!selectedFile || loading}
          className={`w-full py-3 px-4 rounded-md font-semibold text-white transition-colors ${
            !selectedFile || loading
              ? 'bg-gray-400 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-700'
          }`}
        >
          {loading ? 'Processando Imagem...' : 'Analisar Imagem'}
        </button>
      </form>

      {/* Exibição de Erros */}
      {error && (
        <div className="mt-4 p-3 bg-red-100 text-red-700 rounded-md">
          <strong>Erro:</strong> {error}
        </div>
      )}

      {/* Exibição de Resultados (Metadados Extraídos) */}
      {result && (
        <div className="mt-6 p-4 bg-gray-50 rounded-md border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-700 mb-2">
            Metadados Extraídos
          </h3>
          <ul className="space-y-2 text-sm text-gray-600">
            <li>
              <strong>Produto:</strong> {result.productName}
            </li>
            <li>
              <strong>Categoria:</strong> {result.category}
            </li>
            <li>
              <strong>Cor:</strong> {result.color}
            </li>
            <li>
              <strong>Descrição:</strong> {result.description}
            </li>
            <li>
              <strong>Características:</strong>
              <ul className="list-disc list-inside ml-4">
                {result.keyFeatures.map((feature, idx) => (
                  <li key={idx}>{feature}</li>
                ))}
              </ul>
            </li>
          </ul>
          <div className="mt-3 text-xs text-gray-400">
            Status: Embedding gerado e pronto para armazenamento vetorial.
          </div>
        </div>
      )}
    </div>
  );
}
