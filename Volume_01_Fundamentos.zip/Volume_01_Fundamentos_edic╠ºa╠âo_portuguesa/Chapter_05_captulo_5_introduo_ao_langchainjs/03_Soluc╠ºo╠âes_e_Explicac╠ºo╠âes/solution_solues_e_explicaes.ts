/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.ts
// Description: Soluções e Explicações
// ==========================================

import { BaseOutputParser } from "@langchain/core/output_parsers";
import { z } from "zod";

// 1. Definição da Interface e Schema de Validação
// Usamos Zod para validação de runtime, que é mais robusta que interfaces TS puras
const ProductFeedbackSchema = z.object({
  sentiment: z.enum(["Positivo", "Negativo", "Neutro"]),
  product: z.string().min(1),
  urgency: z.number().int().min(1).max(5),
  summary: z.string().min(1),
});

type ProductFeedback = z.infer<typeof ProductFeedbackSchema>;

// 2. Implementação do OutputParser Personalizado
class ProductFeedbackParser extends BaseOutputParser<ProductFeedback> {
  lc_namespace = ["langchain", "output_parsers"];

  async parse(text: string): Promise<ProductFeedback> {
    // Type Narrowing: Tenta extrair o bloco JSON se o LLM envolver em 