/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part2.ts
// Description: Soluções e Explicações
// ==========================================

import { LLMChain } from "langchain/chains";
import { PromptTemplate } from "@langchain/core/prompts";
import { FakeLLM } from "@langchain/core/utils/testing"; // Simulando LLM para exemplo

// 1. Definição dos Prompts
const extractionTemplate = `
Dado um texto técnico, extraia 5 a 7 pontos principais.
Retorne APENAS os pontos, um por linha, sem numeração.
Texto: {text}
Pontos:`;

const summaryTemplate = `
Baseado nos pontos abaixo, escreva um resumo executivo coeso e profissional de um parágrafo.
Pontos: {points}
Resumo Executivo:`;

// 2. Função de Validação e Retry para Extração
async function extractPointsWithRetry(llm: any, text: string, maxRetries: number = 2): Promise<string> {
  const extractionPrompt = PromptTemplate.fromTemplate(extractionTemplate);
  const extractionChain = new LLMChain({ llm, prompt: extractionPrompt });
  
  for (let i = 0; i < maxRetries; i++) {
    const response = (await extractionChain.invoke({ text })).text as string;
    
    // Validação: Verifica se a resposta tem pelo menos 3 linhas (pontos)
    const lines = response.split('\n').filter(line => line.trim().length > 0);
    
    if (lines.length >= 3) {
      return response;
    }
    
    console.log(`Tentativa ${i + 1} falhou. Formatando retry...`);
    // Modifica o prompt para a próxima tentativa se falhar
    // Na prática, você poderia injetar um prompt de correção aqui
  }
  
  throw new Error("Falha ao extrair pontos após múltiplas tentativas.");
}

// 3. Função Principal de Execução
async function executeSummaryChain(text: string) {
  // Usando FakeLLM para simulação (substituir por OpenAI ou outro LLM real)
  const llm = new FakeLLM({ response: "Ponto 1\nPonto 2\nPonto 3\nPonto 4\nPonto 5" });

  try {
    // Etapa 1: Extração com validação
    const points = await extractPointsWithRetry(llm, text);
    
    // Etapa 2: Redação do Resumo
    const summaryPrompt = PromptTemplate.fromTemplate(summaryTemplate);
    const summaryChain = new LLMChain({ llm, prompt: summaryPrompt });
    
    const summaryResult = await summaryChain.invoke({ points });
    
    return summaryResult.text;
  } catch (error) {
    console.error(error);
    return "Erro no processo de sumarização.";
  }
}

// Simulação de uso
const longText = "Texto longo sobre arquitetura de microserviços...";
executeSummaryChain(longText).then(console.log);
