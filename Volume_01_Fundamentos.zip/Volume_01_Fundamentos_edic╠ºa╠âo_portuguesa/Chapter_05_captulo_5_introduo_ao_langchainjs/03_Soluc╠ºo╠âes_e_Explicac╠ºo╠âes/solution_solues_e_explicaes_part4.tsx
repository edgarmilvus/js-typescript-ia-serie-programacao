/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.tsx
// Description: Soluções e Explicações
// ==========================================

import React, { useState, useEffect, ReactNode } from 'react';

// 1. Definição de Tipos para o Stream
type StreamEvent = 
  | { type: 'text'; content: string }
  | { type: 'component'; component: ReactNode };

// 2. Hook Personalizado (Simulado)
const useStreamResponse = (eventStream: StreamEvent[]) => {
  const [displayedContent, setDisplayedContent] = useState<ReactNode[]>([]);
  const [isStreaming, setIsStreaming] = useState(true);

  useEffect(() => {
    let index = 0;
    
    const interval = setInterval(() => {
      if (index >= eventStream.length) {
        clearInterval(interval);
        setIsStreaming(false);
        return;
      }

      const event = eventStream[index];
      
      setDisplayedContent(prev => {
        if (event.type === 'text') {
          // Concatena texto ao último elemento se for texto, ou cria novo
          const lastItem = prev[prev.length - 1];
          if (React.isValidElement(lastItem) && lastItem.props.isText) {
             // Simplificação: para o exemplo, tratamos como fluxo linear
             // Em apps reais, usamos 'useReducer' para manipulação mais fina
             return [...prev.slice(0, -1), <span key={index}>{(lastItem.props.children as string) + event.content}</span>];
          }
          return [...prev, <span key={index} className="text-bubble">{event.content}</span>];
        } else {
          // Insere componente JSX
          return [...prev, <div key={index} className="component-wrapper">{event.component}</div>];
        }
      });

      index++;
    }, 300); // Simula delay de tokens

    return () => clearInterval(interval);
  }, [eventStream]);

  return { displayedContent, isStreaming };
};

// 3. Componente de Chat
interface ChatMessageProps {
  content: ReactNode;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ content }) => {
  return (
    <div className="chat-message">
      {content}
    </div>
  );
};

// 4. Simulação e Renderização
const MockComponent = () => (
  <div style={{ border: '1px solid #ccc', padding: '10px', marginTop: '5px', borderRadius: '5px' }}>
    <strong>Opção Rápida:</strong> <button>Confirmar Ação</button>
  </div>
);

const ChatInterface: React.FC = () => {
  // Simulação de eventos que chegariam do backend via WebSocket ou Stream
  const events: StreamEvent[] = [
    { type: 'text', content: 'Olá! Analisei seu pedido. ' },
    { type: 'text', content: 'Aqui estão suas opções: ' },
    { type: 'component', component: <MockComponent /> },
    { type: 'text', content: ' Selecione uma para prosseguir.' }
  ];

  const { displayedContent } = useStreamResponse(events);

  return (
    <div className="chat-container">
      <ChatMessage content={displayedContent} />
    </div>
  );
};

export default ChatInterface;
