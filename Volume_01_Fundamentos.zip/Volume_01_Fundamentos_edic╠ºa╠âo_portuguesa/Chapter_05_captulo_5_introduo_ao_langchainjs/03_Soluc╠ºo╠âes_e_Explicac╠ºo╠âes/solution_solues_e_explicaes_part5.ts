/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part5.ts
// Description: Soluções e Explicações
// ==========================================

// 1. Constantes e Interfaces
const EMBEDDING_DIMENSION = 1536; // Padrão para text-embedding-ada-002

interface VectorDocument {
  id: string;
  content: string;
  embedding: number[];
}

// 2. Função de Geração de Embeddings (Simulada)
function generateEmbeddings(texts: string[]): VectorDocument[] {
  return texts.map((text, index) => ({
    id: `doc_${index}`,
    content: text,
    // Simula um vetor aleatório com a dimensão correta
    embedding: Array.from({ length: EMBEDDING_DIMENSION }, () => Math.random())
  }));
}

// 3. Função de Similaridade com Validação de Dimensionalidade
function searchSimilar(
  queryEmbedding: number[],
  documents: VectorDocument[],
  topK: number = 3
): VectorDocument[] {
  // Type Narrowing: Validação da query
  if (queryEmbedding.length !== EMBEDDING_DIMENSION) {
    throw new Error(`Dimensão da query inválida. Esperado: ${EMBEDDING_DIMENSION}, Recebido: ${queryEmbedding.length}`);
  }

  // Cálculo de Similaridade (Distância Euclidiana simplificada)
  const scoredDocs = documents
    .map((doc) => {
      // VALIDAÇÃO CRÍTICA: Verifica dimensão do documento antes de calcular
      if (doc.embedding.length !== EMBEDDING_DIMENSION) {
        console.error(`[Erro de Dados] Documento ID ${doc.id} ignorado. Dimensão inválida: ${doc.embedding.length} (Esperado: ${EMBEDDING_DIMENSION}).`);
        return null; // Ignora documento inválido
      }

      // Calcula distância (exemplo simples)
      let sumSq = 0;
      for (let i = 0; i < EMBEDDING_DIMENSION; i++) {
        sumSq += Math.pow(queryEmbedding[i] - doc.embedding[i], 2);
      }
      
      return { ...doc, score: Math.sqrt(sumSq) };
    })
    .filter((doc): doc is VectorDocument & { score: number } => doc !== null);

  // Ordena por score (menor distância = mais similar) e pega top K
  return scoredDocs
    .sort((a, b) => a.score - b.score)
    .slice(0, topK)
    .map(({ score, ...rest }) => rest); // Remove score para retornar apenas VectorDocument
}

// 4. Simulação do Cenário Interativo
function runRAGSimulation() {
  // Dados de treino com um documento incorreto (dimensão 1535)
  const docs: VectorDocument[] = [
    { id: "1", content: "Manual A", embedding: Array(1536).fill(0.1) },
    { id: "2", content: "Manual B (Corrompido)", embedding: Array(1535).fill(0.2) }, // ERRO AQUI
    { id: "3", content: "Manual C", embedding: Array(1536).fill(0.3) },
  ];

  const queryVec = Array(1536).fill(0.15);

  console.log("Iniciando busca...");
  const results = searchSimilar(queryVec, docs);
  
  console.log(`Resultados encontrados: ${results.length}`); // Deve ser 2, ignorando o corrompido
  results.forEach(r => console.log(`- ${r.content}`));
}

runRAGSimulation();
