/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.ts
// Description: Soluções e Explicações
// ==========================================

import { Tool } from "@langchain/core/tools";
import { AgentExecutor, createReactAgent } from "langchain/agents";
import { ChatOpenAI } from "@langchain/openai"; // Ou FakeLLM para teste
import { PromptTemplate } from "@langchain/core/prompts";

// 1. Interface e Mock da Ferramenta
interface WeatherResponse {
  city: string;
  temperature: number;
  condition: string;
}

class MockWeatherTool extends Tool {
  name = "weather_api";
  description = "Útil para obter dados climáticos de uma cidade específica. A entrada deve ser o nome da cidade.";

  async _call(input: string): Promise<string> {
    // Simulando uma chamada de API assíncrona
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const mockData: WeatherResponse = {
      city: input,
      temperature: 25 + Math.floor(Math.random() * 10), // Randomizado para exemplo
      condition: ["Ensolarado", "Nublado", "Chuvoso"][Math.floor(Math.random() * 3)]
    };
    
    // A ferramenta retorna JSON stringificado para o agente processar
    return JSON.stringify(mockData);
  }
}

// 2. Parser de Saída da Ferramenta (Formatador de Resposta)
function formatWeatherResponse(weatherJson: string): string {
  try {
    const data: WeatherResponse = JSON.parse(weatherJson);
    return `O tempo em ${data.city} está ${data.condition.toLowerCase()} com temperatura de ${data.temperature}°C.`;
  } catch (e) {
    return "Não foi possível formatar a previsão do tempo.";
  }
}

// 3. Configuração do Agente
async function createWeatherAgent() {
  // Nota: Em produção, use um LLM real como ChatOpenAI
  // Para este exemplo, usaremos um FakeLLM ou simularemos a lógica
  const llm = new ChatOpenAI({ model: "gpt-3.5-turbo", temperature: 0 }); 
  
  const prompt = PromptTemplate.fromTemplate(`
    Você é um assistente útil.
    Se o usuário perguntar sobre o clima, use a ferramenta "weather_api".
    Depois de obter a resposta da ferramenta, formate-a de forma amigável para o usuário.
    Ferramenta: {tool_desc}
    Entrada do usuário: {input}
  `);

  const tools = [new MockWeatherTool()];
  
  // Cria o agente usando a abordagem de Tool Calling (padrão recente)
  const agent = await createReactAgent({
    llm,
    tools,
    prompt,
  });

  return agent;
}

// 4. Execução
async function runAgent() {
  const agent = await createWeatherAgent();
  const executor = new AgentExecutor({ agent, tools: [new MockWeatherTool()], verbose: true });
  
  const query = "Como está o tempo em São Paulo?";
  
  try {
    const result = await executor.invoke({ input: query });
    
    // Aplicando o parser customizado na resposta final (opcional, dependendo da complexidade)
    // O agente já formata, mas podemos usar o parser se quisermos garantir o tom.
    console.log("Resposta do Agente:", result.output);
  } catch (error) {
    console.error("Erro na execução do agente:", error);
  }
}

// runAgent(); // Descomente para executar (requer chave API válida ou ajuste para FakeLLM)
