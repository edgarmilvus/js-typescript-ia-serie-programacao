/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.ts
// Description: Exemplo de Código Básico
// ==========================================

// index.ts
// Importações essenciais do LangChain.js e do provedor OpenAI.
import { OpenAI } from "@langchain/openai";
import { PromptTemplate } from "@langchain/core/prompts";
import { StringOutputParser } from "@langchain/core/output_parsers";

/**
 * Função principal assíncrona que orquestra o fluxo de geração de texto.
 * @async
 * @returns {Promise<void>}
 */
async function main(): Promise<void> {
  // 1. INICIALIZAÇÃO DO LLM (Modelo de Linguagem)
  // Configuramos o modelo 'gpt-3.5-turbo' com uma temperatura baixa (0.7)
  // para respostas consistentes, mas criativas. A API Key deve vir de variáveis de ambiente.
  const llm = new OpenAI({
    model: "gpt-3.5-turbo",
    temperature: 0.7,
    apiKey: process.env.OPENAI_API_KEY, // Segurança: Nunca hardcode chaves!
  });

  // 2. DEFINIÇÃO DO PROMPT TEMPLATE
  // Um template de prompt é uma string que aceita variáveis (inputs).
  // Aqui, definimos um contexto de "explicador técnico" para o modelo.
  // A variável {topic} será preenchida dinamicamente.
  const promptTemplate = PromptTemplate.fromTemplate(
    `Você é um assistente técnico especializado em JavaScript e TypeScript. 
     Explique o conceito de {topic} de forma concisa, com um exemplo de código e em português.`
  );

  // 3. DEFINIÇÃO DO OUTPUT PARSER
  // O parser converte a saída bruta do LLM (geralmente uma string)
  // em um formato estruturado ou mantém a integridade da string.
  const outputParser = new StringOutputParser();

  // 4. CONSTRUÇÃO DA CADEIA (CHAIN)
  // Encadeamos as etapas: Prompt -> LLM -> Parser.
  // O pipe (|>) conecta a saída de uma etapa à entrada da próxima.
  const chain = promptTemplate.pipe(llm).pipe(outputParser);

  // 5. EXECUÇÃO DA CADEIA
  // Invocamos a cadeia com um objeto de entrada contendo a variável 'topic'.
  // O 'await' pausa a execução até que a resposta da API seja recebida.
  const topic = "Tipos Genéricos (Generics) em TypeScript";
  
  try {
    console.log("🤖 Iniciando geração de resposta...");
    const response = await chain.invoke({ topic: topic });
    
    // Saída final formatada
    console.log("\n--- Resposta do Assistente ---");
    console.log(response);
    console.log("------------------------------");

  } catch (error) {
    console.error("❌ Erro ao processar a requisição:", error);
  }
}

// Executa a função principal.
main();
