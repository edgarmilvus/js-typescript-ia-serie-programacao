/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.ts
// Description: Script de Aplicação Avançada
// ==========================================

// app/api/analyze-feedback/route.ts
import { NextResponse } from 'next/server';
import { OpenAIEmbeddings, ChatOpenAI } from '@langchain/openai';
import { MemoryVectorStore } from 'langchain/vectorstores/memory';
import { Document } from 'langchain/document';
import { createRetrieverTool } from 'langchain/tools/retriever';
import { ChatPromptTemplate, PromptTemplate } from '@langchain/core/prompts';
import { JsonOutputParser } from '@langchain/core/output_parsers';
import { AgentExecutor, createOpenAIFunctionsAgent } from 'langchain/agents';
import { RunnableSequence } from '@langchain/core/runnables';

/**
 * POST /api/analyze-feedback
 * 
 * Endpoint para processar feedbacks de usuários utilizando um workflow agente.
 * 1. Inicializa o banco de vetores (RAG).
 * 2. Define as ferramentas do agente.
 * 3. Constrói o agente supervisor.
 * 4. Executa o agente com o input do usuário.
 */
export async function POST(req: Request) {
  try {
    const { feedback } = await req.json();

    if (!feedback) {
      return NextResponse.json(
        { error: 'Feedback é obrigatório' },
        { status: 400 }
      );
    }

    // --- PASSO 1: CONFIGURAÇÃO DO MODELO E EMBEDDINGS ---
    // Utilizamos gpt-4o-mini para o agente e text-embedding-3-small para os vetores.
    // Nota: Em produção, a inicialização do modelo deve ser feita fora do handler para otimização.
    const model = new ChatOpenAI({
      modelName: 'gpt-4o-mini',
      temperature: 0.1, // Baixa temperatura para consistência na classificação
    });

    const embeddings = new OpenAIEmbeddings({
      modelName: 'text-embedding-3-small',
      dimensions: 1536, // Dimensão padrão para este modelo
    });

    // --- PASSO 2: CRIAÇÃO DO BANCO DE VETORES (RAG) ---
    // Simula uma base de dados de clientes. Em um app real, isso viria do banco SQL/NoSQL.
    const mockClientDocs = [
      new Document({
        pageContent: "Cliente: João Silva. Plano atual: Enterprise. Histórico: 3 tickets resolvidos este mês.",
        metadata: { clientId: '123', source: 'crm' }
      }),
      new Document({
        pageContent: "Cliente: Maria Souza. Plano atual: Starter. Histórico: Reclamação de lentidão na API na última semana.",
        metadata: { clientId: '456', source: 'crm' }
      }),
      new Document({
        pageContent: "Cliente: Pedro Costa. Plano atual: Pro. Histórico: Nenhuma interação recente.",
        metadata: { clientId: '789', source: 'crm' }
      }),
    ];

    // Inicializa a loja de vetores em memória (ideal para demos e protótipos)
    const vectorStore = await MemoryVectorStore.fromDocuments(
      mockClientDocs,
      embeddings
    );

    // --- PASSO 3: DEFINIÇÃO DAS FERRAMENTAS DO AGENTE ---
    // A ferramenta permite ao agente "ler" documentos para obter contexto.
    const retriever = vectorStore.asRetriever({
      k: 2, // Retorna os 2 documentos mais relevantes
    });

    const retrieverTool = createRetrieverTool(retriever, {
      name: 'retriever_client_context',
      description: 'Busca histórico de clientes, planos e tickets antigos. Use esta ferramenta se o feedback mencionar problemas específicos ou nomes de clientes.',
    });

    // --- PASSO 4: CONSTRUÇÃO DO PROMPT DO AGENTE (Supervisor) ---
    // O prompt instrui o agente a usar a ferramenta antes de analisar, se necessário.
    const prompt = ChatPromptTemplate.fromMessages([
      ['system', `Você é um analista de suporte inteligente. Sua tarefa é classificar o sentimento de feedbacks de clientes.
      
      Regras:
      1. Se o feedback parecer urgente, negativo ou mencionar um cliente específico, USE a ferramenta 'retriever_client_context' para obter contexto antes de responder.
      2. Analise o sentimento (Positivo, Negativo, Neutro).
      3. Se for negativo, sugira uma ação baseada no histórico do cliente.
      
      Ferramentas disponíveis: {tool_description}`],
      ['human', 'Feedback do usuário: {input}'],
      ['assistant', 'Pensamentos iniciais...'],
      ['human', '{agent_scratchpad}'], // Onde o pensamento passo a passo do agente será registrado
    ]);

    // --- PASSO 5: CRIAÇÃO DA AGENTE (OpenAI Functions) ---
    const agent = await createOpenAIFunctionsAgent({
      llm: model,
      tools: [retrieverTool],
      prompt,
    });

    // --- PASSO 6: EXECUTOR DO AGENTE ---
    const agentExecutor = new AgentExecutor({
      agent,
      tools: [retrieverTool],
      returnIntermediateSteps: true, // Útil para debug
      maxIterations: 5, // Evita loops infinitos
    });

    // --- PASSO 7: EXECUÇÃO E TRATAMENTO DA SAÍDA ---
    const result = await agentExecutor.invoke({
      input: feedback,
    });

    // O LangChain retorna o output final do agente.
    // Em um fluxo mais complexo, poderíamos usar um OutputParser específico aqui.
    // Para este exemplo, retornamos a saída direta do agente LLM.
    
    return NextResponse.json({
      status: 'success',
      analysis: result.output,
      // Opcional: mostrar passos intermediários se em modo debug
      // intermediateSteps: result.intermediateSteps 
    });

  } catch (error) {
    console.error('Erro na análise:', error);
    return NextResponse.json(
      { error: 'Falha ao processar o feedback' },
      { status: 500 }
    );
  }
}
