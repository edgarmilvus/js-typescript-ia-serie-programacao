/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part2.ts
// Description: Soluções e Explicações
// ==========================================

import { StateGraph, Annotation, MemorySaver } from "@langchain/langgraph";

// 1. Definição do Estado
const GraphState = Annotation.Root({
  generatedCode: Annotation<string>({ default: "" }),
  errorLog: Annotation<string[]>({ default: [] }),
  attempts: Annotation<number>({ default: 0 })
});

// Constante para limite de tentativas
const MAX_ATTEMPTS = 3;

// 2. Nó: Gerar Código (Simulado)
const generateCode = async (state: typeof GraphState.State) => {
  // Simulação: A cada tentativa, o código muda ligeiramente (apenas para visualização)
  const newCode = `function calculate(a, b) { return a ${state.attempts === 0 ? '+' : '*'} b; }`;
  console.log(`[Tentativa ${state.attempts + 1}] Gerando código...`);
  return { 
    generatedCode: newCode, 
    attempts: state.attempts + 1 
  };
};

// 3. Nó: Verificar Sintaxe (Simulado)
const checkSyntax = async (state: typeof GraphState.State) => {
  // Simulação de erro: Se for a primeira ou segunda tentativa, adiciona erro
  if (state.attempts < 2) {
    const errorMsg = `Erro de sintaxe na linha ${state.attempts}: Missing semicolon`;
    console.log(`[Verificação] Erro encontrado: ${errorMsg}`);
    return { errorLog: [errorMsg] }; // Sobrescreve ou adiciona (depende da anotação, aqui resetamos para simular nova tentativa)
  }
  console.log("[Verificação] Código válido!");
  return { errorLog: [] }; // Limpa erros se passar
};

// 4. Nó: Finalizar
const finalizeNode = async (state: typeof GraphState.State) => {
  return { generatedCode: `// Código Finalizado\n${state.generatedCode}` };
};

// 5. Nó: Falha Crítica
const handleFailure = async (state: typeof GraphState.State) => {
  return { generatedCode: "// ERRO: Limite de tentativas excedido." };
};

// 6. Configuração do Grafo e Checkpointer
const workflow = new StateGraph(GraphState)
  .addNode("generateCode", generateCode)
  .addNode("checkSyntax", checkSyntax)
  .addNode("finalize", finalizeNode)
  .addNode("handleFailure", handleFailure)
  .setStartPoint("generateCode")
  // Loop condicional e lógica de falha
  .addConditionalEdges("checkSyntax", (state) => {
    // Prioridade 1: Falha crítica
    if (state.attempts >= MAX_ATTEMPTS && state.errorLog.length > 0) {
      return "handleFailure";
    }
    // Prioridade 2: Loop de reflexão
    if (state.errorLog.length > 0) {
      return "generateCode"; // Volta para gerar
    }
    // Prioridade 3: Sucesso
    return "finalize";
  })
  .addEdge("generateCode", "checkSyntax") // Sempre verifica após gerar
  .addEdge("finalize", "__end__")
  .addEdge("handleFailure", "__end__");

// Configuração do Checkpointer (MemorySaver)
const checkpointer = new MemorySaver();
const compiledGraph = workflow.compile({ checkpointer });

// 7. Execução e Checkpointing
const runSimulation = async () => {
  const threadId = "thread-01"; // Identificador da conversa/sessão
  const config = { configurable: { thread_id: threadId } };

  console.log("--- Execução Inicial ---");
  
  // Passo 1: Gera código e encontra erro (volta para generateCode automaticamente via loop)
  // O grafo continuará rodando até atingir um estado terminal ou esgotar tentativas
  // Como estamos usando .stream(), podemos pausar e inspecionar.
  
  // Neste exemplo, vamos simular passo a passo para visualizar o checkpoint
  let snapshot = await compiledGraph.invoke({ 
    generatedCode: "", 
    errorLog: [], 
    attempts: 0 
  }, config);

  // Simulação manual de passos para demonstrar o loop (o LangGraph gerencia o loop se chamado via stream/invoke contínuo)
  // Para este exercício, executaremos o fluxo completo para chegar ao estado final ou falha.
  
  // Como o grafo tem ciclos, o `invoke` tentará resolver até o fim. 
  // Mas para mostrar o checkpoint, vamos usar `stream` e capturar um momento.
  
  console.log("Iniciando stream...");
  const stream = await compiledGraph.stream({ 
    generatedCode: "", 
    errorLog: [], 
    attempts: 0 
  }, config);

  for await (const step of stream) {
    console.log("Passo do Grafo:", step);
    // Aqui, o estado é salvo após cada nó processado pelo MemorySaver
  }
  
  // Recuperando o estado final
  const finalState = await compiledGraph.getState(config);
  console.log("Estado Final Recuperado:", finalState.values);
};

runSimulation();
