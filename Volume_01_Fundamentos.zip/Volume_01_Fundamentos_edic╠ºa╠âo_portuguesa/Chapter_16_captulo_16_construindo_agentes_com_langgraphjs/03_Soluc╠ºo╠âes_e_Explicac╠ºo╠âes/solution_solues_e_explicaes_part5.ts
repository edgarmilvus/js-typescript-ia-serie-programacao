/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part5.ts
// Description: Soluções e Explicações
// ==========================================

import { StateGraph, Annotation } from "@langchain/langgraph";

// 1. Definição do Estado Global (Grafo Principal)
const GlobalState = Annotation.Root({
  query: Annotation<string>,
  category: Annotation<string>({ default: "" }), // "billing" ou "support"
  // Campos específicos de faturamento
  invoiceId: Annotation<string | null>({ default: null }),
  amount: Annotation<number | null>({ default: null }),
  // Campos específicos de suporte
  techLog: Annotation<string[] | null>({ default: null }),
  // Saída final
  finalResponse: Annotation<string>({ default: "" })
});

// 2. Definição do Estado do Subgrafo de Faturamento
// Nota: Este estado é mais restrito, focado apenas no necessário para faturamento
const BillingState = Annotation.Root({
  invoiceId: Annotation<string>,
  amount: Annotation<number>,
  billingStatus: Annotation<string>({ default: "" })
});

// 3. Definição do Estado do Subgrafo de Suporte
const SupportState = Annotation.Root({
  techLog: Annotation<string[]>,
  errorSummary: Annotation<string>({ default: "" })
});

// --- CONSTRUÇÃO DOS SUBGRAFOS ---

// 4. Subgrafo: Faturamento
const buildBillingSubgraph = () => {
  const billingGraph = new StateGraph(BillingState);
  
  // Nós específicos de faturamento
  const verifyInvoice = async (state: typeof BillingState.State) => {
    console.log(`Verificando fatura ${state.invoiceId} valor: ${state.amount}`);
    return { billingStatus: "Verified" };
  };

  const processPayment = async (state: typeof BillingState.State) => {
    return { billingStatus: "Paid" };
  };

  billingGraph
    .addNode("verifyInvoice", verifyInvoice)
    .addNode("processPayment", processPayment)
    .setStartPoint("verifyInvoice")
    .addEdge("verifyInvoice", "processPayment")
    .addEdge("processPayment", "__end__");

  return billingGraph.compile();
};

// 5. Subgrafo: Suporte Técnico
const buildSupportSubgraph = () => {
  const supportGraph = new StateGraph(SupportState);

  const diagnoseError = async (state: typeof SupportState.State) => {
    return { errorSummary: "Diagnóstico: Falha na conexão com DB." };
  };

  const applyFix = async (state: typeof SupportState.State) => {
    return { errorSummary: "Fix aplicado: Timeout aumentado." };
  };

  supportGraph
    .addNode("diagnoseError", diagnoseError)
    .addNode("applyFix", applyFix)
    .setStartPoint("diagnoseError")
    .addEdge("diagnoseError", "applyFix")
    .addEdge("applyFix", "__end__");

  return supportGraph.compile();
};

// --- GRAFO PRINCIPAL ---

const mainGraph = new StateGraph(GlobalState);

// Nós principais
const categorizeQuery = async (state: typeof GlobalState.State) => {
  if (state.query.includes("fatura") || state.query.includes("pagamento")) {
    return { category: "billing" };
  }
  return { category: "support" };
};

const finalizarAtendimento = async (state: typeof GlobalState.State) => {
  // Aqui ocorre a mesclagem dos resultados
  return { finalResponse: `Atendimento concluído para: ${state.category}` };
};

// Adicionando nós e subgrafos ao grafo principal
mainGraph
  .addNode("categorizeQuery", categorizeQuery)
  .addNode("finalize", finalizarAtendimento);

// Integração dos Subgrafos (Sintaxe Conceitual de Wrapper)
// O LangGraph permite adicionar um nó que executa outro grafo compilado.
const billingSubgraph = buildBillingSubgraph();
const supportSubgraph = buildSupportSubgraph();

mainGraph.addNode("billing_subgraph", billingSubgraph);
mainGraph.addNode("support_subgraph", supportSubgraph);

// Lógica de entrada principal
mainGraph.setStartPoint("categorizeQuery");

// Condicional para delegar ao subgrafo correto
mainGraph.addConditionalEdges("categorizeQuery", (state) => {
  if (state.category === "billing") return "billing_subgraph";
  if (state.category === "support") return "support_subgraph";
  return "__end__";
});

// Conexão de saída dos subgrafos para o nó final
mainGraph.addEdge("billing_subgraph", "finalize");
mainGraph.addEdge("support_subgraph", "finalize");
mainGraph.addEdge("finalize", "__end__");

const compiledMainGraph = mainGraph.compile();

// Exemplo de execução conceitual
// compiledMainGraph.invoke({ query: "Preciso verificar minha fatura 1234 valor 500" });
