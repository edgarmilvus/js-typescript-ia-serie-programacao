/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.ts
// Description: Soluções e Explicações
// ==========================================

import { StateGraph, Annotation } from "@langchain/langgraph";

// 1. Definição do Estado
const GraphState = Annotation.Root({
  userQuery: Annotation<string>,
  intent: Annotation<string | null>({ default: null }),
  finalResponse: Annotation<string | null>({ default: null }),
  // Desafio interativo: Adicionando suporte a palavras-chave personalizáveis
  keywords: Annotation<{ technical: string[]; sales: string[] }>({
    default: {
      technical: ["erro", "bug", "não funciona", "falha"],
      sales: ["preço", "compra", "entrega", "custo"]
    }
  })
});

// 2. Nó de Raciocínio: Classificação da Intenção
const classifyIntent = async (state: typeof GraphState.State) => {
  const { userQuery, keywords } = state;
  const queryLower = userQuery.toLowerCase();

  // Verifica se há palavras-chave técnicas
  if (keywords.technical.some(word => queryLower.includes(word))) {
    return { intent: "technical" };
  }

  // Verifica se há palavras-chave de vendas
  if (keywords.sales.some(word => queryLower.includes(word))) {
    return { intent: "sales" };
  }

  // Desafio interativo: Retorno para fallback se nenhuma corresponder
  return { intent: "fallback" };
};

// 3. Nós de Ação
const handleTechnical = async (state: typeof GraphState.State) => {
  return { finalResponse: "Encaminhando para o suporte técnico. Um especialista analisará o erro." };
};

const handleSales = async (state: typeof GraphState.State) => {
  return { finalResponse: "Encaminhando para o departamento de vendas. Informações sobre preço e entrega a caminho." };
};

const handleFallback = async (state: typeof GraphState.State) => {
  return { finalResponse: "Não entendi sua solicitação. Posso ajudar com problemas técnicos ou dúvidas sobre compras." };
};

// 4. Construção do Grafo
const graph = new StateGraph(GraphState)
  .addNode("classifyIntent", classifyIntent)
  .addNode("handleTechnical", handleTechnical)
  .addNode("handleSales", handleSales)
  .addNode("handleFallback", handleFallback) // Adicionando o nó de fallback
  .setStartPoint("classifyIntent")
  // Condicional Edge: Direciona baseado no 'intent'
  .addConditionalEdges("classifyIntent", (state) => {
    switch (state.intent) {
      case "technical": return "handleTechnical";
      case "sales": return "handleSales";
      default: return "handleFallback";
    }
  })
  // As arelas finais não precisam de próximos nós, pois são terminais neste exemplo
  .addEdge("handleTechnical", "__end__")
  .addEdge("handleSales", "__end__")
  .addEdge("handleFallback", "__end__");

// 5. Compilação e Execução
const compiledGraph = graph.compile();

// Simulação
const runSimulation = async () => {
  console.log("--- Iniciando Simulação ---");
  const result = await compiledGraph.invoke({
    userQuery: "Estou com um erro no checkout",
    // O estado inicial usa as keywords padrão definidas na Annotation
  });
  console.log("Resultado Final:", result.finalResponse);
};

runSimulation();
