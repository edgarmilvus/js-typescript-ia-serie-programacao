/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.ts
// Description: Soluções e Explicações
// ==========================================

import { StateGraph, Annotation } from "@langchain/langgraph";

// 1. Definição do Estado (Atualizado para acumular resultados)
const TravelState = Annotation.Root({
  itinerary: Annotation<string[]>({ default: [] }),
  currentStepIndex: Annotation<number>({ default: 0 }),
  allResults: Annotation<string[]>({ default: [] }) // Acumulador de resultados
});

// 2. Nós de Ferramentas Simuladas
const fetchWeather = async (state: typeof TravelState.State) => {
  const step = state.itinerary[state.currentStepIndex];
  return { allResults: [...state.allResults, `Clima para ${step}: Ensolarado`] };
};

const findRestaurant = async (state: typeof TravelState.State) => {
  const step = state.itinerary[state.currentStepIndex];
  return { allResults: [...state.allResults, `Restaurante para ${step}: Bistrô Francês`] };
};

const bookTransport = async (state: typeof TravelState.State) => {
  const step = state.itinerary[state.currentStepIndex];
  return { allResults: [...state.allResults, `Transporte para ${step}: Táxi reservado`] };
};

// 3. Nó de Processamento e Decisão
const processStep = async (state: typeof TravelState.State) => {
  // Este nó apenas direciona, mas poderia fazer pré-processamento
  return {}; // O estado não muda aqui, apenas o fluxo
};

// 4. Nó de Progresso (Incrementa índice)
const nextStep = async (state: typeof TravelState.State) => {
  return { currentStepIndex: state.currentStepIndex + 1 };
};

// 5. Construção do Grafo
const graph = new StateGraph(TravelState)
  .addNode("processStep", processStep)
  .addNode("fetchWeather", fetchWeather)
  .addNode("findRestaurant", findRestaurant)
  .addNode("bookTransport", bookTransport) // Nova ferramenta
  .addNode("nextStep", nextStep)
  .setStartPoint("processStep");

// 6. Lógica de Ramificação (Conditional Edges)
graph.addConditionalEdges("processStep", (state) => {
  const currentStep = state.itinerary[state.currentStepIndex];

  if (!currentStep) {
    return "__end__"; // Fim do itinerário
  }

  // Lógica de decisão baseada no texto da etapa
  if (currentStep.includes("praia") || currentStep.includes("exterior")) {
    return "fetchWeather";
  } else if (currentStep.includes("jantar") || currentStep.includes("refeicao")) {
    return "findRestaurant";
  } else if (currentStep.includes("hotel")) {
    return "bookTransport";
  } else {
    // Se não corresponder a nenhuma ferramenta, vai para nextStep diretamente (ou fallback)
    return "nextStep";
  }
});

// 7. Conexões Padrão (Incondicionais)
graph.addEdge("fetchWeather", "nextStep");
graph.addEdge("findRestaurant", "nextStep");
graph.addEdge("bookTransport", "nextStep");

// Loop: Após nextStep, voltamos para processStep
graph.addEdge("nextStep", "processStep");

// Compilação
const compiledGraph = graph.compile();

// 8. Execução
const runSimulation = async () => {
  const result = await compiledGraph.invoke({
    itinerary: ["Praia da Costazul", "Jantar no centro", "Hotel Lux"],
    currentStepIndex: 0,
    allResults: []
  });
  
  console.log("--- Itinerário Processado ---");
  result.allResults.forEach((res: string, i: number) => console.log(`${i + 1}. ${res}`));
};

runSimulation();
