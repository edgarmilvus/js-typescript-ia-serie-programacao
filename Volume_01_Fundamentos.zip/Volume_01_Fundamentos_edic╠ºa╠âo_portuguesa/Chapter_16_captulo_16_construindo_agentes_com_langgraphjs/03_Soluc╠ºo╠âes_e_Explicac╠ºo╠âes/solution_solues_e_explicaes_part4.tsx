/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.tsx
// Description: Soluções e Explicações
// ==========================================

import React, { useState } from 'react';

// Interfaces tipadas para as props
interface AgentState {
  userQuery?: string;
  intent?: string | null;
  finalResponse?: string | null;
  generatedCode?: string;
  attempts?: number;
  // ... outras chaves possíveis
}

interface AgentVisualizerProps {
  state: AgentState;
  executionPath: string[];
}

// Sub-componente: Rastreador de Caminho (GraphStepTracker)
const GraphStepTracker: React.FC<{ steps: string[] }> = ({ steps }) => {
  return (
    <div style={{ marginBottom: '20px', padding: '10px', border: '1px solid #ddd' }}>
      <h4>Caminho de Execução:</h4>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
        {steps.map((step, index) => (
          <React.Fragment key={index}>
            <span style={{ 
              background: '#007bff', color: 'white', padding: '5px 10px', 
              borderRadius: '15px', fontSize: '0.9rem' 
            }}>
              {step}
            </span>
            {index < steps.length - 1 && <span style={{ color: '#666' }}>→</span>}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};

// Componente Principal: AgentVisualizer
export const AgentVisualizer: React.FC<AgentVisualizerProps> = ({ state, executionPath }) => {
  // Estado local para gerenciar o "Time Travel" (visualização de histórico)
  const [historyIndex, setHistoryIndex] = useState<number | null>(null);

  // Simulação de histórico (em uma aplicação real, viria de um backend/checkpointer)
  // Vamos criar um histórico fictício baseado no executionPath para demonstrar
  const mockHistory = executionPath.map((step, idx) => ({
    stepName: step,
    snapshotState: { ...state, stepSnapshot: `Estado no passo ${idx}` } // Snapshot simulado
  }));

  // Determina qual estado exibir (se está viajando no tempo ou vendo o atual)
  const displayedState = historyIndex !== null 
    ? mockHistory[historyIndex].snapshotState 
    : state;

  return (
    <div className="agent-dashboard" style={{ fontFamily: 'sans-serif', padding: '20px' }}>
      <h2>Visualizador do Agente LangGraph</h2>
      
      {/* Botões de Time Travel */}
      <div style={{ marginBottom: '15px' }}>
        <strong>Time Travel (Simulado): </strong>
        {mockHistory.map((_, idx) => (
          <button 
            key={idx}
            onClick={() => setHistoryIndex(idx === historyIndex ? null : idx)}
            style={{ 
              margin: '0 5px', 
              padding: '5px 10px',
              background: historyIndex === idx ? '#28a745' : '#e2e6ea',
              cursor: 'pointer'
            }}
          >
            Passo {idx}
          </button>
        ))}
        {historyIndex !== null && (
          <button onClick={() => setHistoryIndex(null)} style={{ marginLeft: '10px', background: '#dc3545', color: 'white', border: 'none', padding: '5px 10px', cursor: 'pointer' }}>
            Voltar ao Presente
          </button>
        )}
      </div>

      {/* Visualização do Caminho */}
      <GraphStepTracker steps={executionPath} />

      {/* Visualização do Estado */}
      <div style={{ background: '#f8f9fa', padding: '15px', borderRadius: '5px', border: '1px solid #dee2e6' }}>
        <h4>Estado Interno {historyIndex !== null && <span style={{color: 'red'}}>(Histórico: Passo {historyIndex})</span>}</h4>
        <ul style={{ listStyleType: 'none', padding: 0 }}>
          {Object.entries(displayedState).map(([key, value]) => (
            <li key={key} style={{ marginBottom: '8px', borderBottom: '1px solid #eee', paddingBottom: '4px' }}>
              <strong>{key}:</strong> {typeof value === 'object' ? JSON.stringify(value) : String(value)}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

// Exemplo de uso (simulado em uma aplicação React)
// <AgentVisualizer 
//   state={{ userQuery: "Erro no checkout", intent: "technical", finalResponse: null }} 
//   executionPath={["Start", "ClassifyIntent", "HandleTechnical"]} 
// />
