/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.ts
// Description: Script de Aplicação Avançada
// ==========================================

// app/api/agent/route.ts
import { NextResponse } from 'next/server';
import { StateGraph, END, Annotation } from '@langchain/langgraph';
import { ChatOpenAI } from '@langchain/openai';

// ==================================================================
// 1. DEFINIÇÃO DO ESTADO (State Schema)
// ==================================================================
// O estado centraliza todos os dados da conversa. Nós de ferramentas e raciocínio
// leem e escrevem neste objeto. Isso garante persistência de contexto entre ciclos.

type TravelState = {
  destination: string;
  dates: string;
  budget: number;
  flightPrice?: number; // Opcional: preenchido pela tool de avião
  weatherInfo?: string; // Opcional: preenchido pela tool de clima
  nextAction: 'search_flights' | 'check_weather' | 'summarize' | 'finish';
};

const StateAnnotation = Annotation.Root({
  destination: Annotation<string>,
  dates: Annotation<string>,
  budget: Annotation<number>,
  flightPrice: Annotation<number | undefined>,
  weatherInfo: Annotation<string | undefined>,
  // Controla o fluxo:决定了 qual nó será executado após o raciocínio
  nextAction: Annotation<'search_flights' | 'check_weather' | 'summarize' | 'finish'>({
    default: () => 'search_flights' // Padrão inicial
  }),
});

// ==================================================================
// 2. DEFINIÇÃO DAS FERRAMENTAS (Tool Invocation Signature)
// ==================================================================
// Assinatura compatível com LangGraph. Aceitam o estado e retornam atualizações parciais.
// Em um app real, aqui entrariam chamadas `fetch` para APIs externas.

/**
 * Simula uma busca de preços de passagens aéreas.
 * Lógica: Se o destino for "Paris", retorna um preço alto. Caso contrário, médio.
 */
async function searchFlights(state: typeof StateAnnotation.State): Promise<Partial<typeof StateAnnotation.State>> {
  console.log(`[Tool] Buscando voos para ${state.destination}...`);
  
  // Simulação de latência de API
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const price = state.destination.toLowerCase().includes('paris') ? 1200 : 600;
  
  return {
    flightPrice: price,
    // Reseta a ação para forçar reavaliação no próximo ciclo de raciocínio
    nextAction: 'check_weather' 
  };
}

/**
 * Simula a verificação da previsão do tempo.
 * Lógica: Adiciona uma string de clima baseada no destino.
 */
async function checkWeather(state: typeof StateAnnotation.State): Promise<Partial<typeof StateAnnotation.State>> {
  console.log(`[Tool] Verificando clima em ${state.destination}...`);
  
  await new Promise(resolve => setTimeout(resolve, 300));
  
  const weather = state.destination.toLowerCase().includes('paris') 
    ? "Chuvoso, 15°C" 
    : "Ensolarado, 28°C";
  
  return {
    weatherInfo: weather,
    nextAction: 'summarize'
  };
}

// ==================================================================
// 3. NÓ DE RACIOCÍNIO (LLM Node)
// ==================================================================
// O cérebro do agente. Analisa o estado atual e decide qual ferramenta usar ou se finaliza.

async function reasoningNode(state: typeof StateAnnotation.State): Promise<Partial<typeof StateAnnotation.State>> {
  console.log("[LLM] Analisando estado atual...");
  
  const llm = new ChatOpenAI({ 
    model: "gpt-3.5-turbo", 
    temperature: 0 
  });

  // Prompt baseado no estado. Em um app real, isso seria um prompt mais elaborado.
  const prompt = `
    Você é um agente de planejamento de viagem.
    Estado atual:
    - Destino: ${state.destination}
    - Orçamento: ${state.budget}
    - Preço do Voo: ${state.flightPrice ?? 'Não verificado'}
    - Clima: ${state.weatherInfo ?? 'Não verificado'}

    Baseado no estado acima, qual deve ser a próxima ação?
    Responda APENAS com o nome da ação: 'search_flights', 'check_weather', 'summarize' ou 'finish'.
    
    Regras:
    1. Se o preço do voo não estiver verificado, retorne 'search_flights'.
    2. Se o preço estiver verificado mas o clima não, retorne 'check_weather'.
    3. Se ambos estiverem verificados, retorne 'summarize'.
    4. Se o resumo foi gerado, retorne 'finish'.
  `;

  try {
    const response = await llm.invoke(prompt);
    const content = response.content as string;
    
    // Extraímos a decisão do LLM e atualizamos o estado
    const nextAction = content.trim().toLowerCase() as TravelState['nextAction'];
    
    return { nextAction };
  } catch (error) {
    console.error("Erro no LLM:", error);
    // Fallback seguro: se o LLM falhar, tentamos finalizar
    return { nextAction: 'finish' };
  }
}

// ==================================================================
// 4. NÓ DE SAÍDA (Output Node)
// ==================================================================
// Gera o resultado final para o usuário.

async function summaryNode(state: typeof StateAnnotation.State): Promise<Partial<typeof StateAnnotation.State>> {
  console.log("[Output] Gerando resumo final...");
  
  const summary = `
    ✈️ **Plano de Viagem para ${state.destination}**
    - Datas: ${state.dates}
    - Preço do Voo: $${state.flightPrice}
    - Previsão do Tempo: ${state.weatherInfo}
    - Análise de Orçamento: ${state.budget >= state.flightPrice ? '✅ Dentro do orçamento' : '❌ Acima do orçamento'}
  `;
  
  console.log(summary);
  
  // Retorna vazio pois é o fim do fluxo, mas poderia armazenar no estado
  return { nextAction: 'finish' };
}

// ==================================================================
// 5. CONSTRUÇÃO DO GRAFO (LangGraph Assembly)
// ==================================================================
// Montamos o grafo conectando nós e arestas condicionais.

function createTravelGraph() {
  const graph = new StateGraph(StateAnnotation)
    // 1. Adiciona os nós
    .addNode('reasoning', reasoningNode)
    .addNode('search_flights', searchFlights)
    .addNode('check_weather', checkWeather)
    .addNode('summary', summaryNode)
    
    // 2. Define o ponto de entrada
    .addEdge('__start__', 'reasoning')
    
    // 3. Define arestas condicionais baseadas no estado 'nextAction'
    // Esta é a lógica central: olhamos o estado para decidir o próximo nó.
    .addConditionalEdges(
      'reasoning',
      (state: typeof StateAnnotation.State) => {
        return state.nextAction; // Retorna o nome do próximo nó
      },
      {
        'search_flights': 'search_flights',
        'check_weather': 'check_weather',
        'summarize': 'summary',
        'finish': END
      }
    )
    
    // 4. Ciclos de loop: Após executar uma ferramenta, voltamos para o raciocínio
    .addEdge('search_flights', 'reasoning')
    .addEdge('check_weather', 'reasoning')
    .addEdge('summary', END);

  return graph.compile();
}

// ==================================================================
// 6. HANDLER DA API ROUTE (Next.js)
// ==================================================================
// Endpoint que recebe a solicitação do usuário e executa o grafo.

export async function POST(req: Request) {
  try {
    const { destination, dates, budget } = await req.json();

    // Validação básica
    if (!destination || !dates || !budget) {
      return NextResponse.json(
        { error: 'Dados incompletos: destino, datas e orçamento são obrigatórios.' },
        { status: 400 }
      );
    }

    // Inicializa o grafo
    const graph = createTravelGraph();

    // Estado inicial da execução
    const initialState: typeof StateAnnotation.State = {
      destination,
      dates,
      budget,
      flightPrice: undefined,
      weatherInfo: undefined,
      nextAction: 'search_flights' // Começa buscando preços
    };

    // Executa o grafo (o LangGraph gerencia os ciclos automaticamente)
    console.log("--- Iniciando Execução do Agente ---");
    const finalState = await graph.invoke(initialState);
    console.log("--- Execução do Agente Finalizada ---");

    // Extraímos o resumo final (em um cenário real, o estado conteria o texto final)
    // Aqui, como o summaryNode apenas loga, retornamos o estado final para depuração.
    return NextResponse.json({
      status: 'success',
      data: finalState,
      message: 'Agente concluiu o planejamento.'
    });

  } catch (error) {
    console.error("Erro na execução do agente:", error);
    return NextResponse.json(
      { error: 'Falha interna no agente.' },
      { status: 500 }
    );
  }
}
