/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.ts
// Description: Exemplo de Código Básico
// ==========================================

// src/realEstateAgent.ts
import { StateGraph, Annotation } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai"; // Simula o LLM
import { ToolNode } from "@langchain/langgraph/prebuilt"; // Nó pré-construído para ferramentas

// ==========================================
// 1. DEFINIÇÃO DO ESTADO (SHARED STATE)
// ==========================================
// O estado é o "saco de dados" compartilhado que circula pelo grafo.
// Usamos a API de Anotação do LangGraph para tipagem segura em TypeScript.

const GraphState = Annotation.Root({
  // A entrada do usuário (ex: "Qual o preço médio em São Paulo?")
  question: Annotation<string>,
  
  // A resposta final gerada pelo agente
  answer: Annotation<string>({
    reducer: (curr, update) => update ?? curr, // Garante que a resposta seja sobrescrita
    default: () => "",
  }),

  // O histórico de raciocínio (pensamentos) do LLM
  thoughts: Annotation<string[]>({
    reducer: (curr, update) => [...curr, update],
    default: () => [],
  }),

  // Se o agente deve parar ou continuar o loop
  should_continue: Annotation<boolean>({
    reducer: (curr, update) => update,
    default: () => true,
  }),
});

// ==========================================
// 2. FERRAMENTAS (TOOLS)
// ==========================================
// Simulação de uma API externa para obter dados imobiliários.

const fetchMarketData = async (location: string): Promise<string> => {
  // Simulação de delay de rede (latência da API)
  await new Promise((resolve) => setTimeout(resolve, 500));
  
  // Mock de dados reais
  const mockPrices: Record<string, string> = {
    "São Paulo": "R$ 8.500/m²",
    "Rio de Janeiro": "R$ 7.200/m²",
    "Belo Horizonte": "R$ 6.100/m²",
  };

  const price = mockPrices[location] || "R$ 5.000/m² (estimativa genérica)";
  return `Preço médio em ${location}: ${price}`;
};

// Wrapper da ferramenta para o LangGraph
const tools = [fetchMarketData];

// ==========================================
// 3. NÓS DO GRAFO (NODES)
// ==========================================

/**
 * Nó de Raciocínio (Reasoning Node).
 * Simula a escolha de uma ação pelo LLM.
 * Em um cenário real, aqui entraria o `model.bindTools(tools).invoke()`.
 * Para este exemplo "Hello World", simulamos a lógica de decisão.
 */
const reasoningNode = async (state: typeof GraphState.State) => {
  console.log("--- [Nó: Raciocínio] Processando pergunta... ---");
  
  const { question } = state;
  
  // Lógica simples de decisão (simulando a saída de um LLM)
  let decision: "tool" | "answer";
  let thought = "";

  if (question.toLowerCase().includes("preço") || question.toLowerCase().includes("custo")) {
    decision = "tool";
    thought = "O usuário está perguntando sobre preço. Preciso consultar a base de dados de mercado.";
  } else {
    decision = "answer";
    thought = "A pergunta parece geral. Posso responder diretamente.";
  }

  // Atualiza o estado com o pensamento
  const newThoughts = [...state.thoughts, thought];

  // Retorna o novo estado parcial
  return {
    thoughts: newThoughts,
    should_continue: decision === "tool", // Se for tool, continuamos o loop
  };
};

/**
 * Nó de Ação (Action Node).
 * Executa a ferramenta selecionada.
 * O LangGraph Prebuilt ToolNode faria isso automaticamente em um cenário real.
 */
const actionNode = async (state: typeof GraphState.State) => {
  console.log("--- [Nó: Ação] Executando ferramenta... ---");
  
  // Extraímos a localização da pergunta (lógica simples para o exemplo)
  const locationMatch = state.question.match(/em ([A-Za-z\s]+)/);
  const location = locationMatch ? locationMatch[1].trim() : "São Paulo"; // Default

  // Executa a função real
  const observation = await fetchMarketData(location);

  // Retorna a observação para o estado
  return {
    answer: `Dados obtidos: ${observation}`, // Armazena temporariamente os dados brutos
  };
};

/**
 * Nó de Finalização (End Node).
 * Formata a resposta final para o usuário.
 */
const finalNode = async (state: typeof GraphState.State) => {
  console.log("--- [Nó: Finalização] Gerando resposta... ---");
  
  let finalAnswer = "";

  // Se temos dados brutos da API, formatamos
  if (state.answer.includes("Dados obtidos:")) {
    const rawData = state.answer.replace("Dados obtidos: ", "");
    finalAnswer = `Com base nos dados atuais do mercado: ${rawData}.`;
  } else {
    // Resposta direta se não usamos a API
    finalAnswer = "Para dúvidas gerais, recomendamos consultar nosso blog.";
  }

  return {
    answer: finalAnswer,
    should_continue: false, // Para o loop
  };
};

// ==========================================
// 4. CONSTRUÇÃO DO GRAFO (GRAPH DEFINITION)
// ==========================================

// Inicializa o grafo de estado
const workflow = new StateGraph(GraphState);

// Adiciona os nós ao grafo
workflow.addNode("reasoning", reasoningNode);
workflow.addNode("action", actionNode);
workflow.addNode("final", finalNode);

// Define o ponto de entrada (Entry Point)
workflow.setEntryPoint("reasoning");

// Define as transições (Edges) condicionais
// O nó 'reasoning' decide para onde ir baseado no estado `should_continue`
workflow.addConditionalEdges(
  "reasoning",
  (state: typeof GraphState.State) => {
    if (state.should_continue) {
      return "action"; // Se verdadeiro, vá para a ação
    }
    return "final"; // Se falso, vá para o final
  }
);

// O nó 'action' sempre volta para 'reasoning' para reavaliar (Loop ReAct)
workflow.addEdge("action", "reasoning");

// Compila o grafo
const app = workflow.compile();

// ==========================================
// 5. EXECUÇÃO (ENTRY POINT)
// ==========================================

async function main() {
  console.log("🚀 Iniciando Agente Imobiliário...\n");

  // Input do usuário (simulação de request HTTP)
  const userInput = "Qual o preço médio em São Paulo?";

  // Invocação do grafo
  const finalState = await app.invoke({
    question: userInput,
    answer: "",
    thoughts: [],
    should_continue: true,
  });

  console.log("\n✅ Resultado Final:");
  console.log(`Pergunta: ${finalState.question}`);
  console.log(`Resposta: ${finalState.answer}`);
  console.log(`Raciocínio Interno: ${finalState.thoughts.join(" -> ")}`);
}

// Executa se este arquivo for o entry point
if (require.main === module) {
  main().catch(console.error);
}
