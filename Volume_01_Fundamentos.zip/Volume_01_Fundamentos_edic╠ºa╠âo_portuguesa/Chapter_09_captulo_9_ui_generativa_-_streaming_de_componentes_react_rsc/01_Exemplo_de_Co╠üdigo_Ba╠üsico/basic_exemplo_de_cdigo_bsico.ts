/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.ts
// Description: Exemplo de Código Básico
// ==========================================

// app/actions.ts
'use server';

import { ReactElement } from 'react';
import { streamToUI } from './stream-to-ui'; // Utilitário próprio (definido abaixo)

/**
 * Server Action principal que orquestra o fluxo de geração de UI.
 * @param formData - Dados do formulário contendo a solicitação do usuário.
 * @returns Uma stream de componentes React renderizados.
 */
export async function generateReportAction(formData: FormData) {
  const request = formData.get('request') as string;

  // 1. Simulamos uma resposta de LLM que gera texto token por token.
  // Em um cenário real, isso seria um fetch para a API da OpenAI com stream: true.
  const llmStream = createMockLLMStream(request);

  // 2. Transformamos o stream de texto bruto em um stream de componentes React.
  // O `streamToUI` é um utilitário que lê o stream e renderiza componentes dinamicamente.
  return streamToUI(llmStream);
}

/**
 * Simula uma LLM retornando tokens de texto sequencialmente.
 * Isso demonstra como dados assíncronos chegam ao servidor.
 */
function createMockLLMStream(prompt: string): AsyncIterable<string> {
  const phrases = [
    `Processando sua solicitação: "${prompt}"...\n`,
    `Analisando dados de vendas do Q3.\n`,
    `Identificando picos de crescimento.\n`,
    `Gerando visualização de gráfico de barras...\n`,
    `Concluído.`
  ];

  return {
    async *[Symbol.asyncIterator]() {
      for (const phrase of phrases) {
        // Simula latência de rede/token
        await new Promise(resolve => setTimeout(resolve, 300));
        yield phrase;
      }
    }
  };
}
