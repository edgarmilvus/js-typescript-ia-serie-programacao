/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico_part3.ts
// Description: Exemplo de Código Básico
// ==========================================

// app/page.tsx
'use client';

import { useTransition } from 'react';
import { generateReportAction } from './actions';

export default function DashboardPage() {
  const [isPending, startTransition] = useTransition();
  const [uiStream, setUiStream] = useState<React.ReactNode | null>(null);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);

    startTransition(async () => {
      // 1. Chama a Server Action.
      // 2. A resposta é um AsyncIterable de componentes React.
      const stream = await generateReportAction(formData);
      
      // 3. Consumimos o stream e atualizamos o estado local para renderizar.
      const components: React.ReactNode[] = [];
      for await (const component of stream) {
        components.push(component);
        // Otimização: Atualiza o estado a cada chunk para ver o progresso
        setUiStream(<>{components}</>);
      }
    });
  };

  return (
    <main className="max-w-2xl mx-auto p-8">
      <h1 className="text-2xl font-bold mb-6">Gerador de Relatórios IA</h1>
      
      <form onSubmit={handleSubmit} className="flex gap-2 mb-8">
        <input 
          name="request" 
          placeholder="Ex: Relatório de vendas Q3" 
          className="flex-1 p-2 border rounded text-black"
          disabled={isPending}
        />
        <button 
          type="submit" 
          className="px-4 py-2 bg-black text-white rounded disabled:opacity-50"
          disabled={isPending}
        >
          {isPending ? 'Processando...' : 'Gerar'}
        </button>
      </form>

      <div className="space-y-4 transition-all duration-300">
        {/* Aqui os componentes do servidor são renderizados dinamicamente */}
        {isPending && <div className="animate-pulse text-gray-400">Iniciando stream...</div>}
        {uiStream}
      </div>
    </main>
  );
}
