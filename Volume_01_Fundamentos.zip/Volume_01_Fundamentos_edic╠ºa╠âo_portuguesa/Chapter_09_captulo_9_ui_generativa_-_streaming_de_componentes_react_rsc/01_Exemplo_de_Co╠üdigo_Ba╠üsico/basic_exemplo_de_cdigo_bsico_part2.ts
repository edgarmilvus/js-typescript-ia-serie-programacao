/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico_part2.ts
// Description: Exemplo de Código Básico
// ==========================================

// app/stream-to-ui.tsx
'use server';

import { ReactNode } from 'react';

/**
 * Transforma um stream de texto em um stream de componentes React.
 * @param stream - Um AsyncIterable de strings (tokens de texto).
 * @returns Uma função que retorna um gerador de elementos React.
 */
export async function* streamToUI(stream: AsyncIterable<string>): AsyncGenerator<ReactNode> {
  let buffer = '';

  // Itera sobre cada chunk de texto recebido da LLM
  for await (const chunk of stream) {
    buffer += chunk;

    // Lógica de "Parsing" de UI:
    // Se detectarmos certas palavras-chave no buffer, renderizamos componentes específicos.
    
    if (buffer.includes('Processando')) {
      // Renderiza um componente de carregamento inicial
      yield (
        <div className="p-4 bg-blue-50 border-l-4 border-blue-500 text-blue-700">
          <strong>🔍 Investigando...</strong> Estamos coletando os dados necessários.
        </div>
      );
    }

    if (buffer.includes('Analisando')) {
      // Renderiza um componente de texto dinâmico
      yield (
        <div className="p-4 bg-gray-50 my-2 rounded">
          <p className="text-sm text-gray-600">Status: {buffer}</p>
        </div>
      );
    }

    if (buffer.includes('Gerando visualização')) {
      // Renderiza um componente visual complexo (simulado)
      yield (
        <div className="p-6 border-2 border-dashed border-gray-300 rounded-lg bg-white mt-4">
          <div className="flex items-end space-x-2 h-32">
            <div className="w-8 bg-green-500 h-1/3 animate-pulse"></div>
            <div className="w-8 bg-green-500 h-2/3 animate-pulse" style={{animationDelay: '0.1s'}}></div>
            <div className="w-8 bg-green-500 h-3/4 animate-pulse" style={{animationDelay: '0.2s'}}></div>
          </div>
          <p className="text-center mt-2 text-gray-500 text-xs">Gráfico Gerado via RSC</p>
        </div>
      );
    }
  }

  // Renderiza o componente final de ação
  yield (
    <div className="mt-4 flex gap-2">
      <button className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition">
        Exportar PDF
      </button>
      <button className="px-4 py-2 border border-gray-300 rounded hover:bg-gray-50 transition">
        Compartilhar
      </button>
    </div>
  );
}
