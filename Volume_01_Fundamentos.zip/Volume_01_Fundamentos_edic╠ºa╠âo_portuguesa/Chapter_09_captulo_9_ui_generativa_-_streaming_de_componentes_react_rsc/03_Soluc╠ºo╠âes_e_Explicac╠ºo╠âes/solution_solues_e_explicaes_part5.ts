/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part5.ts
// Description: Soluções e Explicações
// ==========================================

// app/dashboard/page.tsx
import { Suspense } from 'react';
import StatsCard from '@/components/StatsCard';
import { fetchStatsData } from '@/lib/data';
import { StreamableValue, createStreamableValue } from 'ai/rsc';

// Server Component
export default async function DashboardPage() {
  // 1. Busca de dados brutos (bloqueia até chegar, mas é rápida)
  const stats = await fetchStatsData(); 

  return (
    <div className="p-8">
      <h1>Dashboard</h1>
      <div className="grid grid-cols-3 gap-4">
        {/* O esqueleto é mostrado imediatamente enquanto o dado bruto chega */}
        <Suspense fallback={<div className="h-32 bg-slate-200 rounded animate-pulse"></div>}>
          <StatsCard data={stats} />
        </Suspense>
      </div>
    </div>
  );
}

// components/StatsCard.tsx
import { Suspense } from 'react';
import { generateDescription } from './actions'; // Server Action

export default async function StatsCard({ data }: { data: any }) {
  // 2. Iniciamos a geração do texto em paralelo com a renderização do layout
  const descriptionStream = await generateDescription(data);

  return (
    <div className="p-4 border rounded-lg shadow bg-white flex flex-col gap-2">
      <h3 className="font-bold text-lg">{data.title}</h3>
      <div className="text-2xl font-mono text-slate-700">{data.value}</div>
      
      {/* 3. Suspense interno para o stream de texto */}
      <div className="h-12 text-sm text-slate-500">
        <Suspense fallback={<span>Gerando insight...</span>}>
          <DescriptionView stream={descriptionStream} />
        </Suspense>
      </div>
    </div>
  );
}

// Componente Cliente para consumir o stream
'use client';
import { useStreamableValue } from 'ai/rsc';
import { StreamableValue } from 'ai/rsc';

function DescriptionView({ stream }: { stream: StreamableValue<string> }) {
  const [content, error, pending] = useStreamableValue(stream);
  
  return <span>{content}</span>;
}
