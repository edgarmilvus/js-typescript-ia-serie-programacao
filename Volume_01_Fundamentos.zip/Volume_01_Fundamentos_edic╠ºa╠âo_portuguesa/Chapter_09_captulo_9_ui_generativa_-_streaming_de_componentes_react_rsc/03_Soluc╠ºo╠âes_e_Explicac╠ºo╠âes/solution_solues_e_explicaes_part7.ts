/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part7.ts
// Description: Soluções e Explicações
// ==========================================

// lib/prompts.ts

// Template para a etapa de correção automática
export const correctionPromptTemplate = `
Você é um especialista em React, TypeScript e Tailwind CSS.
O código gerado anteriormente falhou na validação de compilação.

**Código TSX Gerado (Original):**
\`\`\`tsx
{original_code}
\`\`\`

**Erro de Compilação:**
{compilation_error}

**Instruções:**
1. Analise o erro acima e corrija o código.
2. Garanta que o código use apenas componentes do "shadcn/ui" (ex: Button, Card, Table).
3. Use classes Tailwind CSS válidas e consistentes (ex: bg-slate-50, text-sm, p-4).
4. **REGRAS ESTRICTAS DE SAÍDA:**
   - Retorne APENAS o bloco de código TSX corrigido.
   - NÃO use Markdown (não use \`\`\`tsx ou \`\`\`).
   - NÃO adicione explicações, comentários longos ou texto adicional.
   - O código deve ser um componente funcional React válido.

**Código Corrigido (Apenas TSX):**
`;

// Função para construir o prompt dinamicamente
export function buildCorrectionPrompt(originalCode: string, error: string): string {
  return correctionPromptTemplate
    .replace('{original_code}', originalCode)
    .replace('{compilation_error}', error);
}

// Exemplo de uso (Simulação)
const original = `import { Button } from '@/components/ui/button';
export default function MyComp() {
  return <Button onClick={123}>Clique</Button>`;
const error = `Property 'onClick' does not exist on type 'IntrinsicAttributes & ButtonProps'.`;

const finalPrompt = buildCorrectionPrompt(original, error);
console.log(finalPrompt);
