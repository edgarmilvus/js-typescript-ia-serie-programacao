/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part2.ts
// Description: Soluções e Explicações
// ==========================================

// components/ProductCardGenerator.tsx
'use client';

import { useState, useRef, useEffect } from 'react';

export default function ProductCardGenerator() {
  const [htmlContent, setHtmlContent] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const generate = async () => {
    setIsLoading(true);
    setHtmlContent(''); // Limpa conteúdo anterior

    const response = await fetch('/api/generate-product-card', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: "Um relógio inteligente esportivo" }),
    });

    if (!response.body) return;

    const reader = response.body.getReader();
    const decoder = new TextDecoder();

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value, { stream: true });
      // Appending chunks directly to HTML state
      setHtmlContent((prev) => prev + chunk);
    }

    setIsLoading(false);
  };

  return (
    <div className="p-4">
      <button 
        onClick={generate} 
        disabled={isLoading}
        className="px-4 py-2 bg-slate-900 text-white rounded disabled:opacity-50"
      >
        {isLoading ? 'Gerando...' : 'Gerar Produto'}
      </button>

      {/* Skeleton Loader */}
      {isLoading && !htmlContent && (
        <div className="mt-4 p-6 border rounded-lg shadow-md bg-white animate-pulse">
          <div className="h-6 bg-slate-200 rounded w-3/4 mb-2"></div>
          <div className="h-4 bg-slate-200 rounded w-full mb-2"></div>
          <div className="h-4 bg-slate-200 rounded w-5/6"></div>
        </div>
      )}

      {/* Container para renderização incremental */}
      <div 
        ref={containerRef}
        className="mt-4 space-y-4"
        // Permite HTML dinâmico vindo do stream
        dangerouslySetInnerHTML={{ __html: htmlContent }} 
      />
    </div>
  );
}
