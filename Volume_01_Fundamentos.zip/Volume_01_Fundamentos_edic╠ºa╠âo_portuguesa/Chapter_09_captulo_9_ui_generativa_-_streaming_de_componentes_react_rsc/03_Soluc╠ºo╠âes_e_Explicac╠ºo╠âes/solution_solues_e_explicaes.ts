/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.ts
// Description: Soluções e Explicações
// ==========================================

// app/api/generate-product-card/route.ts
import { OpenAIStream, StreamingTextResponse } from 'ai';
import OpenAI from 'openai';
import { NextRequest } from 'next/server';

// Configuração do Edge Runtime
export const runtime = 'edge';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

export async function POST(req: NextRequest) {
  const { prompt } = await req.json();

  // Prompt para garantir JSON estruturado
  const systemPrompt = `
    Gere um produto fictício baseado no prompt do usuário.
    Retorne APENAS um JSON válido no formato: 
    {"title": "Nome do Produto", "description": "Descrição detalhada", "price": 99.99}
    Não adicione texto antes ou depois do JSON.
  `;

  const response = await openai.chat.completions.create({
    model: 'gpt-3.5-turbo',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: prompt }
    ],
    stream: true,
  });

  // TransformStream para converter JSON parcial em HTML
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  
  let buffer = ''; // Buffer para acumular tokens JSON

  const transformStream = new TransformStream({
    async transform(chunk, controller) {
      const text = decoder.decode(chunk, { stream: true });
      buffer += text;

      // Tenta parsear o buffer. Se falhar, acumula mais tokens.
      try {
        // Remove possíveis quebras de linha ou espaços extras para tentar o parse
        const jsonCandidate = JSON.parse(buffer);
        
        // Se parse bem sucedido, gera o HTML e limpa o buffer
        const htmlChunk = `
          <div class="p-6 border rounded-lg shadow-md bg-white transition-all duration-500 opacity-0 animate-fade-in">
            <h2 class="text-xl font-bold text-slate-800 mb-2">${jsonCandidate.title}</h2>
            <p class="text-slate-600 mb-4">${jsonCandidate.description}</p>
            <div class="flex justify-between items-center">
              <span class="text-lg font-semibold text-green-600">R$ ${jsonCandidate.price.toFixed(2)}</span>
              <button class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
                Adicionar ao Carrinho
              </button>
            </div>
          </div>
        `;
        
        controller.enqueue(encoder.encode(htmlChunk));
        buffer = ''; // Reseta o buffer após sucesso
      } catch (e) {
        // Erro esperado se o JSON estiver incompleto. Apenas continue acumulando.
        // Não fazemos nada aqui para não quebrar o stream.
      }
    },
  });

  // Transforma o stream da OpenAI usando o nosso transformador
  const openaiStream = OpenAIStream(response);
  const stream = openaiStream.pipeThrough(transformStream);

  return new StreamingTextResponse(stream, {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
    },
  });
}
