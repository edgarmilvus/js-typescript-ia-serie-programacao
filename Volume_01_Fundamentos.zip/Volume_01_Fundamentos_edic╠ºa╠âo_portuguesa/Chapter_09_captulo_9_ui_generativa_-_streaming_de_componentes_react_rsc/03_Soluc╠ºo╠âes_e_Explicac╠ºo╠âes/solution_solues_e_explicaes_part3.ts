/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.ts
// Description: Soluções e Explicações
// ==========================================

// lib/langgraph-ui.ts
import { StateGraph, END, Annotation } from '@langchain/langgraph';
import { ChatOpenAI } from '@langchain/openai';

// Definição do Estado
const StateAnnotation = Annotation.Root({
  userQuery: Annotation<string>(),
  outputType: Annotation<'text' | 'ui' | null>(),
  generatedCode: Annotation<string>({ default: '' }),
  evaluationScore: Annotation<number>({ default: 0 }),
  iterations: Annotation<number>({ default: 0 }),
});

const model = new ChatOpenAI({ model: 'gpt-4-turbo', temperature: 0 });

// Nó 1: Decidir Saída
async function decideOutput(state: typeof StateAnnotation.State) {
  const prompt = `
    Analise a consulta: "${state.userQuery}".
    Responda apenas com JSON: {"type": "text" | "ui"}
    "ui" se for necessário um componente visual interativo.
  `;
  const response = await model.invoke(prompt);
  const parsed = JSON.parse(response.content as string);
  return { outputType: parsed.type };
}

// Nó 2: Gerar Código TSX
async function generateComponent(state: typeof StateAnnotation.State) {
  const prompt = `
    Gere um componente React (TSX) para: "${state.userQuery}".
    Use shadcn/ui e Tailwind CSS.
    Retorne APENAS o código, sem Markdown.
  `;
  const response = await model.invoke(prompt);
  return { generatedCode: response.content as string, iterations: state.iterations + 1 };
}

// Nó 3: Avaliação (O desafio interativo)
async function evaluateUI(state: typeof StateAnnotation.State) {
  const prompt = `
    Avalie se o código abaixo atende à consulta: "${state.userQuery}".
    Código: ${state.generatedCode}
    Dê uma nota de 0 a 10. Se for menor que 9, sugira uma melhoria.
    Responda com JSON: {"score": number, "suggestion": string}
  `;
  const response = await model.invoke(prompt);
  const result = JSON.parse(response.content as string);
  
  // Se a nota for baixa ou muitas iterações, refinamos (ciclo)
  if (result.score < 9 && state.iterations < 3) {
    // Aqui poderíamos injetar a sugestão no próximo prompt de geração
    console.log(`Refinando... (Tentativa ${state.iterations})`);
    return { evaluationScore: result.score, userQuery: `${state.userQuery}. Refine baseado na sugestão: ${result.suggestion}` };
  }
  
  return { evaluationScore: result.score };
}

// Construção do Grafo
const workflow = new StateGraph(StateAnnotation)
  .addNode('decide_output', decideOutput)
  .addNode('generate_component', generateComponent)
  .addNode('evaluate_ui', evaluateUI);

// Condições de Transição (Ciclo)
workflow.addConditionalEdges(
  'decide_output',
  (state) => {
    if (state.outputType === 'ui') return 'generate_component';
    return 'end'; // Se for texto, termina
  }
);

workflow.addEdge('generate_component', 'evaluate_ui');

workflow.addConditionalEdges(
  'evaluate_ui',
  (state) => {
    // Se a nota for boa ou iterações esgotarem, termina. Senão, volta para geração.
    if (state.evaluationScore >= 9 || state.iterations >= 3) return 'end';
    return 'generate_component'; // Ciclo fechado
  }
);

workflow.setStartPoint('decide_output');
workflow.addEdge('end', END);

export const app = workflow.compile();
