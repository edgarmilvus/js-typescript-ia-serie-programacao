/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part8.ts
// Description: Soluções e Explicações
// ==========================================

// hooks/useStreamComponent.ts
'use client';

import { useState, useEffect, useMemo } from 'react';
import * as React from 'react';
import { transform } from 'sucrase'; // Biblioteca para transformar TS/JSX em JS

interface UseStreamComponentResult {
  Component: React.ComponentType | null;
  isLoading: boolean;
  error: string | null;
}

export function useStreamComponent(apiUrl: string, prompt: string): UseStreamComponentResult {
  const [code, setCode] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadStream = async () => {
      try {
        const response = await fetch(apiUrl, {
          method: 'POST',
          body: JSON.stringify({ prompt }),
        });

        if (!response.body) return;
        const reader = response.body.getReader();
        const decoder = new TextDecoder();

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const chunk = decoder.decode(value, { stream: true });
          setCode((prev) => prev + chunk);
        }
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Erro desconhecido');
      } finally {
        setIsLoading(false);
      }
    };

    loadStream();
  }, [apiUrl, prompt]);

  // Compilação do código usando Sucrase (Biblioteca de runtime)
  // NOTA: Em produção, o ideal é usar esbuild-wasm ou um worker para não bloquear a UI.
  const Component = useMemo(() => {
    if (!code || isLoading) return null;

    try {
      // Transforma TSX/ES6 em JS executável pelo navegador
      const transformed = transform(code, {
        transforms: ['jsx', 'typescript', 'imports'],
      }).code;

      // Cria uma função construtora segura para evaluar o módulo
      // Isso é mais seguro que eval direto pois cria um escopo isolado
      const module = { exports: {} };
      const exports = module.exports;
      
      // Executa o código transformado
      const func = new Function('React', 'exports', 'module', transformed);
      func(React, exports, module);

      // Retorna o componente exportado default
      return module.exports.default || null;
    } catch (e) {
      console.error("Erro ao compilar componente dinâmico:", e);
      return null;
    }
  }, [code, isLoading]);

  return { Component, isLoading, error };
}
