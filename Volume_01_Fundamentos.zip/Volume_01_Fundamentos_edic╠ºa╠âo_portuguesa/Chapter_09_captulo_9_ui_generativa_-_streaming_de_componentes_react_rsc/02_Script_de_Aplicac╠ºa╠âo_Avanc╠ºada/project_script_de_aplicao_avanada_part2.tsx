/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada_part2.tsx
// Description: Script de Aplicação Avançada
// ==========================================

// app/components/DynamicComponentRenderer.tsx
'use client'; // Este é um Client Component para gerenciar o estado de montagem

import { Suspense } from 'react';
import { useStreamableUI } from './useStreamableUI'; // Hook personalizado (abaixo)

/**
 * @description Componente que recebe o stream de dados do servidor e renderiza
 * dinamicamente os componentes conforme chegam.
 */
export default function DynamicComponentRenderer({ initialPrompt }: { initialPrompt: string }) {
  // Hook que gerencia a conexão SSE (Server-Sent Events) ou fetch stream
  const uiComponents = useStreamableUI(initialPrompt);

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-xl font-bold">Dashboard Gerado</h2>
      
      {/* Container onde os componentes são injetados */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {uiComponents.map((componentData, index) => {
          // Renderização dinâmica baseada no tipo retornado pelo LLM
          switch (componentData.type) {
            case 'MetricCard':
              return <MetricCard key={index} {...componentData.props} />;
            case 'BarChart':
              return <BarChart key={index} {...componentData.props} />;
            case 'UserTable':
              return <UserTable key={index} {...componentData.props} />;
            default:
              return null;
          }
        })}
      </div>
      
      {uiComponents.length === 0 && <p>Gerando UI...</p>}
    </div>
  );
}

// --- Sub-componentes Simples (Podem ser Server Components se não tiverem interatividade) ---

function MetricCard({ label, value, trend }: any) {
  return (
    <div className="bg-white p-4 rounded shadow border">
      <h3 className="text-sm text-gray-500">{label}</h3>
      <p className="text-2xl font-bold">{value}</p>
      <span className="text-green-500 text-sm">{trend}</span>
    </div>
  );
}

function BarChart({ data, labels }: any) {
  return (
    <div className="bg-white p-4 rounded shadow border flex items-end h-40 gap-2">
      {data.map((val: number, i: number) => (
        <div key={i} className="bg-blue-500 w-full rounded-t" style={{ height: `${(val / 400) * 100}%` }}>
          <span className="sr-only">{labels[i]}: {val}</span>
        </div>
      ))}
    </div>
  );
}

function UserTable({ users }: any) {
  return (
    <div className="bg-white p-4 rounded shadow border overflow-x-auto">
      <table className="w-full text-left">
        <thead><tr><th>Nome</th><th>Role</th></tr></thead>
        <tbody>
          {users.map((u: any, i: number) => (
            <tr key={i} className="border-t"><td className="py-1">{u.name}</td><td className="py-1">{u.role}</td></tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
