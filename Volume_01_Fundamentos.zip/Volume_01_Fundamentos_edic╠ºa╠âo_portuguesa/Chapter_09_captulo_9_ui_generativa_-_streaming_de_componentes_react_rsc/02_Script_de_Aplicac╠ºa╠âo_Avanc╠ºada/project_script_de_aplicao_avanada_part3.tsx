/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada_part3.tsx
// Description: Script de Aplicação Avançada
// ==========================================

// app/components/useStreamableUI.ts
'use client';

import { useState, useEffect, useRef } from 'react';

/**
 * @description Hook personalizado para consumir o stream de componentes do servidor.
 * Processa o stream linha por linha (JSONL), valida e atualiza o estado local.
 */
export function useStreamableUI(prompt: string) {
  const [components, setComponents] = useState<any[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Referência para evitar re-renderizações desnecessárias do effect
  const hasStarted = useRef(false);

  useEffect(() => {
    if (!prompt || hasStarted.current) return;
    hasStarted.current = true;
    setIsGenerating(true);

    const controller = new AbortController();
    const signal = controller.signal;

    const fetchStream = async () => {
      try {
        const response = await fetch('/api/generate-ui', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt }),
          signal,
        });

        if (!response.body) return;

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value, { stream: true });
          buffer += chunk;

          // Processamento de streaming: Quebra por linha (JSONL)
          const lines = buffer.split('\n');
          // Mantém a última linha incompleta no buffer
          buffer = lines.pop() || '';

          for (const line of lines) {
            if (line.trim() === '') continue;
            try {
              const parsed = JSON.parse(line);
              // Atualização otimista do estado
              setComponents((prev) => [...prev, parsed]);
            } catch (e) {
              console.error('Erro ao parsear JSON do stream:', e);
            }
          }
        }
      } catch (error) {
        if ((error as Error).name !== 'AbortError') {
          console.error('Stream error:', error);
        }
      } finally {
        setIsGenerating(false);
      }
    };

    fetchStream();

    return () => controller.abort();
  }, [prompt]);

  return components;
}
