/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.tsx
// Description: Script de Aplicação Avançada
// ==========================================

// app/api/generate-ui/route.ts
import { NextResponse } from 'next/server';
import { OpenAIStream, StreamingTextResponse } from 'ai'; // Simularemos o uso da lib 'ai'
import { z } from 'zod';

/**
 * @description Schema que define a estrutura da UI gerada pelo LLM.
 * O LLM deve retornar JSON válido que se encaixe neste schema.
 */
const ComponentSchema = z.object({
  type: z.enum(['BarChart', 'MetricCard', 'UserTable']),
  props: z.record(z.any()), // Dados dinâmicos para o componente
});

const ResponseSchema = z.array(ComponentSchema);

// Mock do LLM para fins didáticos (substituir por `new OpenAI()` em produção)
const mockLLMStream = async (prompt: string) => {
  // Simula componentes sendo gerados sequencialmente
  const components = [
    { type: 'MetricCard', props: { label: 'Receita Total', value: '$12,450', trend: '+12%' } },
    { type: 'BarChart', props: { data: [120, 200, 150, 300], labels: ['Jan', 'Feb', 'Mar', 'Apr'] } },
    { type: 'UserTable', props: { users: [{ name: 'João Silva', role: 'Admin' }, { name: 'Maria Souza', role: 'User' }] } },
  ];

  // Simula o tempo de processamento do LLM
  for (const component of components) {
    await new Promise(resolve => setTimeout(resolve, 500));
    // Em um stream real, isto seria um chunk JSON
    yield JSON.stringify(component) + '\n';
  }
};

export async function POST(req: Request) {
  const { prompt } = await req.json();

  // 1. Configuração do Stream de texto (simulando o provider de AI)
  // Em produção, usaria `new OpenAI().chat.completions.stream(...)` ou similar.
  const stream = new ReadableStream({
    async start(controller) {
      const llmStream = mockLLMStream(prompt);
      
      for await (const chunk of llmStream) {
        // 2. Envio do chunk JSON para o cliente
        controller.enqueue(new TextEncoder().encode(chunk));
      }
      
      controller.close();
    },
  });

  // 3. Retorno da resposta de streaming
  return new StreamingTextResponse(stream);
}
