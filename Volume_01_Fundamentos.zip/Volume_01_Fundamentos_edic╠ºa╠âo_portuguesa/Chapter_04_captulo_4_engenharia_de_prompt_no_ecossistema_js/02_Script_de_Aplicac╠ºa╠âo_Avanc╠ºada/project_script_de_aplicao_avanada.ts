/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.ts
// Description: Script de Aplicação Avançada
// ==========================================

// app/api/analyze-feedback/route.ts
import { NextResponse } from 'next/server';
import OpenAI from 'openai';

/**
 * @fileoverview Script de Engenharia de Prompt avançada para análise de feedback.
 * Objetivo: Demonstrar Tool Calling para gerenciar Context Window e processar
 * grandes volumes de texto (reviews) de forma eficiente.
 * 
 * Conceitos aplicados:
 * 1. Tool Calling: O modelo decide quando e como usar uma função definida.
 * 2. Context Window Management: Divisão de texto em lotes para evitar truncamento.
 * 3. Few-Shot Prompting (implícito na descrição da ferramenta): Definição clara do formato de saída esperado.
 */

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Interface para a resposta da ferramenta de análise.
 * Define a estrutura estrita que o LLM deve retornar.
 */
interface SentimentAnalysisResult {
  batchId: number;
  sentiment: 'positive' | 'negative' | 'neutral';
  confidenceScore: number;
  keyTopics: string[];
  summary: string;
}

/**
 * Ferramenta disponível para o LLM.
 * Esta função simula o processamento de um lote de texto.
 * Em uma aplicação real, esta seria uma função complexa de NLP ou consulta a um banco de dados.
 * 
 * @param text - O texto do lote a ser analisado.
 * @param batchId - Identificador do lote.
 * @returns Promise<SentimentAnalysisResult>
 */
async function analyzeSentimentBatch(text: string, batchId: number): Promise<SentimentAnalysisResult> {
  // Simulação de processamento pesado fora do contexto do LLM
  // Isso demonstra como o Tool Calling delega lógica externa.
  console.log(`Processando lote ${batchId} com ${text.length} caracteres...`);
  
  // Retorno simulado baseado na lógica real (em um cenário real, o LLM geraria isso)
  // Para este exemplo, retornamos um mock, mas o código abaixo mostra como o LLM invoca isso.
  return {
    batchId,
    sentiment: 'positive', // Determinado pelo LLM
    confidenceScore: 0.85,
    keyTopics: ['usabilidade', 'performance'],
    summary: 'Feedback geralmente positivo com ressalvas técnicas.'
  };
}

/**
 * POST /api/analyze-feedback
 * Endpoint da API Next.js que orquestra a Engenharia de Prompt.
 */
export async function POST(req: Request) {
  try {
    const { reviews } = await req.json();

    if (!reviews || !Array.isArray(reviews)) {
      return NextResponse.json({ error: 'Array de reviews inválido.' }, { status: 400 });
    }

    // 1. CONSTRUÇÃO DO PROMPT COM TOOL CALLING
    // Definimos a ferramenta que o modelo pode usar. O schema JSON descreve o que a função faz.
    // Nota: Em modelos como GPT-4, o 'strict: true' garante que o output siga exatamente o schema.
    const tools: OpenAI.Chat.ChatCompletionTool[] = [
      {
        type: 'function',
        function: {
          name: 'analyze_sentiment_batch',
          description: 'Análise de sentimento para um único lote de reviews de clientes. Use esta função sempre que precisar processar texto.',
          parameters: {
            type: 'object',
            properties: {
              text: {
                type: 'string',
                description: 'O texto concatenado dos reviews a serem analisados neste lote.',
              },
              batchId: {
                type: 'number',
                description: 'ID do lote (ex: 1, 2, 3) para rastreamento.',
              },
            },
            required: ['text', 'batchId'],
          },
        },
      },
    ];

    // 2. ESTRUTURAÇÃO DO CONTEXTO (PROMPT SYSTEM)
    // Instruções claras sobre o comportamento esperado (Chain of Thought).
    const systemPrompt = `
      Você é um assistente de IA para análise de dados de clientes. 
      Objetivo: Analisar sentimentos de reviews de forma estruturada.
      
      Regras:
      1. Leitura Critica: Leia o texto fornecido para identificar tópicos e tom geral.
      2. Gerenciamento de Contexto: Se o texto for muito longo, divida-o mentalmente em lotes.
      3. Tool Calling: Para cada lote de texto, chame a ferramenta 'analyze_sentiment_batch'.
      4. Formato: Retorne apenas os resultados JSON gerados pela ferramenta.
    `;

    // 3. CHAMADA DA API COM O HISTÓRICO
    // Enviamos o prompt e instruímos o modelo a usar a ferramenta.
    const completion = await openai.chat.completions.create({
      model: 'gpt-4-turbo-preview', // Modelo com suporte a Tool Calling
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Analise os seguintes reviews: ${reviews.join(' ')}` }
      ],
      tools: tools,
      tool_choice: 'auto', // Deixa o modelo decidir se chama a ferramenta
    });

    const output = completion.choices[0];

    // 4. PROCESSAMENTO DA RESPOSTA
    // Se o modelo optou por chamar a ferramenta, processamos o resultado.
    if (output.message.tool_calls) {
      const toolCall = output.message.tool_calls[0];
      
      if (toolCall.function.name === 'analyze_sentiment_batch') {
        // Parse dos argumentos que o modelo gerou
        const args = JSON.parse(toolCall.function.arguments);
        
        // Execução da função real (simulada)
        const result = await analyzeSentimentBatch(args.text, args.batchId);

        // Retorno da resposta final para o cliente
        return NextResponse.json({
          analysis: result,
          usage: completion.usage,
          message: 'Análise completada via Tool Calling.'
        });
      }
    }

    // Caso o modelo não chame a ferramenta (resposta direta)
    return NextResponse.json({
      analysis: null,
      message: output.message.content
    });

  } catch (error) {
    console.error('Erro na análise:', error);
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 });
  }
}
