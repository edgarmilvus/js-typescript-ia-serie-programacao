/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.ts
// Description: Exemplo de Código Básico
// ==========================================

// index.ts
import { z } from "zod";
import { ChatOpenAI } from "@langchain/openai";
import { DynamicStructuredTool } from "@langchain/core/tools";
import { AgentExecutor, createOpenAIFunctionsAgent } from "langchain/agents";
import { ChatPromptTemplate } from "@langchain/core/prompts";

// 1. DEFINIÇÃO DAS FERRAMENTAS (MOCKADAS PARA O EXEMPLO)
// Em uma aplicação real, estas funções fariam chamadas de API (ex: Alpha Vantage, OpenWeatherMap).

/**
 * Ferramenta para simular a obtenção do preço de uma ação.
 * Retorna uma string formatada com o preço atual.
 */
const getStockPriceTool = new DynamicStructuredTool({
  name: "get_stock_price",
  description: "Obtém o preço atual de uma ação específica usando seu símbolo (ticker).",
  schema: z.object({
    symbol: z.string().describe("O símbolo da ação, ex: 'AAPL', 'GOOGL'"),
  }),
  func: async ({ symbol }) => {
    // Simulação de latência de API (500ms)
    await new Promise((resolve) => setTimeout(resolve, 500));
    const mockPrices: Record<string, string> = {
      AAPL: "$182.52",
      GOOGL: "$141.80",
      TSLA: "$248.50",
    };
    const price = mockPrices[symbol.toUpperCase()] || "$100.00";
    return `O preço atual da ação ${symbol} é ${price}.`;
  },
});

/**
 * Ferramenta para simular a obtenção do clima de uma cidade.
 * Retorna uma string descrevendo as condições climáticas.
 */
const getWeatherTool = new DynamicStructuredTool({
  name: "get_weather",
  description: "Obtém as condições climáticas atuais para uma cidade específica.",
  schema: z.object({
    city: z.string().describe("O nome da cidade, ex: 'São Paulo', 'Nova York'"),
  }),
  func: async ({ city }) => {
    // Simulação de latência de API (800ms)
    await new Promise((resolve) => setTimeout(resolve, 800));
    const mockWeather: Record<string, string> = {
      "São Paulo": "Chuvoso e frio (18°C)",
      "Nova York": "Ensolarado e quente (32°C)",
      "Tóquio": "Nublado (22°C)",
    };
    const weather = mockWeather[city] || "Condições desconhecidas";
    return `O clima em ${city} está ${weather}.`;
  },
});

// 2. CONFIGURAÇÃO DO LLM E PROMPT
// O modelo GPT-4 é instruído a usar as ferramentas fornecidas.
const llm = new ChatOpenAI({
  model: "gpt-4-turbo-preview",
  temperature: 0,
});

// Template de prompt que orienta o agente a executar ferramentas em paralelo quando possível.
const prompt = ChatPromptTemplate.fromMessages([
  ["system", "Você é um assistente financeiro e de viagens útil. Você deve executar ferramentas em paralelo sempre que possível para responder rapidamente."],
  ["human", "{input}"],
  ["assistant", "{agent_scratchpad}"],
]);

// 3. CRIAÇÃO DO AGENTE E EXECUTOR
async function createTravelAgent() {
  // Cria o agente que suporta funções (tools)
  const agent = await createOpenAIFunctionsAgent({
    llm,
    tools: [getStockPriceTool, getWeatherTool],
    prompt,
  });

  // O Executor de Agente gerencia a execução das ferramentas
  const executor = new AgentExecutor({
    agent,
    tools: [getStockPriceTool, getWeatherTool],
    // Configuração crítica: Permite que o agente execute múltiplas ferramentas em um único passo
    maxIterations: 5,
    returnIntermediateSteps: true,
  });

  return executor;
}

// 4. FUNÇÃO PRINCIPAL DE EXECUÇÃO (ENTRYPOINT)
async function main() {
  console.log("🚀 Iniciando Agente de Execução Paralela...\n");
  
  const executor = await createTravelAgent();
  
  // Input do usuário (simulado via SaaS/Web App)
  const userInput = "Qual o preço da ação AAPL e como está o clima em Nova York? Quero saber se é uma boa hora para investir e viajar.";

  try {
    console.log(`👤 Usuário: ${userInput}\n`);
    
    // Chamada para o executor
    const result = await executor.invoke({
      input: userInput,
    });

    console.log("🤖 Resposta do Agente:");
    console.log(result.output);
    
    // Detalhamento técnico (para debug de engenharia de prompt)
    if (result.intermediateSteps && result.intermediateSteps.length > 0) {
      console.log("\n📊 Detalhes da Execução (Passos Intermediários):");
      result.intermediateSteps.forEach((step: any, index: number) => {
        console.log(`   Passo ${index + 1}: Chamou ferramenta '${step.action.tool}' com input: ${JSON.stringify(step.action.toolInput)}`);
        console.log(`   Resultado: ${step.observation}`);
      });
    }

  } catch (error) {
    console.error("❌ Erro na execução do agente:", error);
  }
}

// Executa a função principal
main();
