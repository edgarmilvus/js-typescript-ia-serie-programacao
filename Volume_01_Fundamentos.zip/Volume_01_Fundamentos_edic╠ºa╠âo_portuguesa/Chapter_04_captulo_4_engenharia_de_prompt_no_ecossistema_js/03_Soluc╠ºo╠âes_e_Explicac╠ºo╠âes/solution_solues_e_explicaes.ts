/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.ts
// Description: Soluções e Explicações
// ==========================================

import { ChatOpenAI } from "@langchain/openai";
import { PromptTemplate } from "@langchain/core/prompts";
import { LLMChain } from "langchain/chains";
import { z } from "zod";

// Schema para validação da saída JSON usando Zod
const MathResponseSchema = z.object({
  reasoning: z.array(z.string()), // Array de strings explicando os passos
  final_answer: z.string()        // A resposta final em string
});

export async function solveMathProblem(problem: string) {
  // 1. Inicializar o modelo LLM
  const model = new ChatOpenAI({
    modelName: "gpt-3.5-turbo",
    temperature: 0, // Foco na precisão, não na criatividade
  });

  // 2. Definir o System Prompt para forçar o formato JSON
  const systemPrompt = `
    Você é um Matemático Lógico. Sua tarefa é resolver problemas matemáticos passo a passo.
    
    Regras estritas:
    1. Pense passo a passo (Chain of Thought).
    2. A resposta final DEVE ser um objeto JSON válido com duas chaves: "reasoning" (array de strings) e "final_answer" (string).
    3. Não adicione texto antes ou depois do JSON.

    Exemplo de saída:
    {{
      "reasoning": ["Passo 1: Identificar valores...", "Passo 2: Calcular..."],
      "final_answer": "42"
    }}
  `;

  // 3. Criar o PromptTemplate
  const prompt = new PromptTemplate({
    template: "{system_prompt}\n\nProblema: {problem}",
    inputVariables: ["system_prompt", "problem"],
  });

  // 4. Criar a cadeia (Chain)
  const chain = new LLMChain({ llm: model, prompt });

  // 5. Executar a cadeia
  const result = await chain.invoke({
    system_prompt: systemPrompt,
    problem: problem,
  });

  // 6. Fazer o parse e validação do JSON retornado
  try {
    // O LLM retorna uma string, precisamos limpar e parsear
    const parsedResult = MathResponseSchema.parse(JSON.parse(result.text));
    return parsedResult;
  } catch (error) {
    console.error("Falha ao fazer parse do JSON:", error);
    throw new Error("A resposta do modelo não seguiu o formato JSON esperado.");
  }
}

// Exemplo de uso:
// solveMathProblem("Qual é a área de um triângulo retângulo com base 10 e altura 5?")
//   .then(console.log);
