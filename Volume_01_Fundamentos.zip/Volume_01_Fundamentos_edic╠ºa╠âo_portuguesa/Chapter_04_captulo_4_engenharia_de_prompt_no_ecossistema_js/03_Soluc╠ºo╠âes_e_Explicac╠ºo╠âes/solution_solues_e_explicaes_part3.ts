/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.ts
// Description: Soluções e Explicações
// ==========================================

import { ChatOpenAI } from "@langchain/openai";
import { PromptTemplate } from "@langchain/core/prompts";
import { LLMChain } from "langchain/chains";
import { z } from "zod";

// Schema para validação da decisão do supervisor
const SupervisorSchema = z.object({
  next: z.enum(["Vendas", "Suporte Técnico", "Faturamento", "Human"]),
});

// Estado da conversa (simulado)
interface ConversationState {
  message: string;
  transferCount?: number; // Para rastrear quantas vezes foi transferido
}

export async function routeCustomerMessage(state: ConversationState) {
  const model = new ChatOpenAI({ modelName: "gpt-3.5-turbo", temperature: 0 });

  // 1. Lógica de detecção de estresse alto (regra explícita)
  const stressKeywords = ["cancelar conta", "processo", "advogado", "processo judicial"];
  const hasHighStress = stressKeywords.some(keyword => 
    state.message.toLowerCase().includes(keyword)
  );

  // Se já foi transferido 2 vezes ou tem palavras de estresse, roteia direto para Human
  if (hasHighStress || (state.transferCount && state.transferCount >= 2)) {
    return "Human";
  }

  // 2. Prompt do Supervisor
  const systemPrompt = `
    Você é um Supervisor de Atendimento ao Cliente.
    Analise a mensagem do cliente e decida qual agente deve responder.
    
    Opções de roteamento:
    - "Vendas": Para dúvidas sobre produtos, preços, promoções.
    - "Suporte Técnico": Para problemas técnicos, erros, configurações.
    - "Faturamento": Para cobranças, notas fiscais, pagamentos.
    - "Human": Para reclamações graves, ameaças ou clientes insatisfeitos.

    Responda APENAS com um JSON válido: {{"next": "NomeDoAgente"}}`;
  
  const prompt = new PromptTemplate({
    template: "{system_prompt}\n\nMensagem do Cliente: {message}",
    inputVariables: ["system_prompt", "message"],
  });

  const chain = new LLMChain({ llm: model, prompt });
  const result = await chain.invoke({ 
    system_prompt: systemPrompt, 
    message: state.message 
  });

  // 3. Parse e Validação
  try {
    const parsed = JSON.parse(result.text);
    const validated = SupervisorSchema.parse(parsed);
    return validated.next;
  } catch (error) {
    console.error("Erro na validação do supervisor, assumindo fallback:", error);
    return "Human"; // Fallback seguro
  }
}

// Exemplo de uso:
// routeCustomerMessage({ message: "Quero processar um estorno urgente." })
//   .then(console.log); // Deve retornar "Faturamento" ou "Human" dependendo do contexto
