/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part2.ts
// Description: Soluções e Explicações
// ==========================================

import { ChatOpenAI } from "@langchain/openai";
import { FewShotPromptTemplate, PromptTemplate } from "@langchain/core/prompts";
import { LLMChain } from "langchain/chains";

// Interface para os exemplos de treinamento
interface Example {
  review: string;
  classification: "Positivo" | "Negativo" | "Neutro" | "Crítico";
}

// Banco de dados simulado de exemplos
const allExamples: Example[] = [
  { review: "O produto é incrível, superou minhas expectativas.", classification: "Positivo" },
  { review: "Chegou atrasado e com a embalagem violada.", classification: "Crítico" },
  { review: "Funciona bem, mas nada demais.", classification: "Neutro" },
  { review: "Péssima qualidade, não recomendo.", classification: "Negativo" },
  { review: "Atendimento ao cliente excelente!", classification: "Positivo" },
  { review: "O item veio faltando peça.", classification: "Crítico" },
];

// Função para selecionar exemplos aleatórios
function getRandomExamples(count: number): Example[] {
  const shuffled = [...allExamples].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
}

export async function classifySentiment(reviewText: string) {
  const model = new ChatOpenAI({ modelName: "gpt-3.5-turbo", temperature: 0 });

  // 1. Preparar os exemplos dinamicamente
  const selectedExamples = getRandomExamples(2); // Seleciona 2 exemplos aleatórios
  
  const formattedExamples = selectedExamples.map(ex => ({
    review: ex.review,
    classification: ex.classification,
  }));

  // 2. Configurar o FewShotPromptTemplate
  const examplePrompt = new PromptTemplate({
    template: "Review: {review}\nClassificação: {classification}",
    inputVariables: ["review", "classification"],
  });

  const fewShotPrompt = new FewShotPromptTemplate({
    examples: formattedExamples,
    examplePrompt: examplePrompt,
    prefix: "Classifique o sentimento da review em uma das categorias: Positivo, Negativo, Neutro, Crítico.\nRetorne APENAS a palavra da classificação, sem texto adicional.",
    suffix: "Review: {review}\nClassificação:",
    inputVariables: ["review"],
  });

  // 3. Criar e executar a cadeia
  const chain = new LLMChain({ llm: model, prompt: fewShotPrompt });
  const result = await chain.invoke({ review: reviewText });

  // 4. Limpar a resposta (remover espaços em branco ou quebras de linha)
  return result.text.trim();
}

// Exemplo de uso:
// classifySentiment("Adorei o atendimento, mas o produto demorou muito.")
//   .then(console.log);
