/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part5.ts
// Description: Soluções e Explicações
// ==========================================

import { RecursiveCharacterTextSplitter } from "@langchain/textsplitters";
import { ChatOpenAI } from "@langchain/openai";
import { PromptTemplate } from "@langchain/core/prompts";
import { LLMChain } from "langchain/chains";

// Função auxiliar para estimar tokens (regra 1 token ≈ 4 caracteres)
const estimateTokens = (text: string): number => Math.ceil(text.length / 4);

export async function summarizeLongDocument(document: string) {
  const model = new ChatOpenAI({ 
    modelName: "gpt-3.5-turbo", 
    temperature: 0 
  });

  // 1. Configurar o Splitter (Chunking)
  const splitter = new RecursiveCharacterTextSplitter({
    chunkSize: 1000, // ~1000 tokens
    chunkOverlap: 200, // ~200 tokens
  });

  const chunks = await splitter.createDocuments([document]);
  console.log(`Documento dividido em ${chunks.length} chunks.`);

  // 2. Cadeia de Sumarização de Chunks Individuais
  const summaryTemplate = `
    Resuma o texto a seguir de forma concisa e objetiva.
    Texto: {text}
    Resumo:
  `;
  const summaryPrompt = new PromptTemplate({ template: summaryTemplate, inputVariables: ["text"] });
  const summaryChain = new LLMChain({ llm: model, prompt: summaryPrompt });

  const chunkSummaries: string[] = [];
  let totalTokensUsed = 0;

  // Processar cada chunk
  for (let i = 0; i < chunks.length; i++) {
    const chunkText = chunks[i].pageContent;
    const tokenCount = estimateTokens(chunkText);
    totalTokensUsed += tokenCount;

    console.log(`Processando Chunk ${i + 1} (${tokenCount} tokens estimados)...`);
    
    // Verificação de Janela Deslizante (Sliding Window Check)
    // Se o chunk for muito grande (próximo ao limite do modelo), avisa.
    // O limite do gpt-3.5-turbo é 4096 tokens. Nosso chunk é 1000, seguro.
    if (tokenCount > 3000) {
      console.warn(`Atenção: Chunk ${i + 1} é muito grande (${tokenCount} tokens). Risco de truncamento.`);
      // Aqui poderíamos ajustar dinamicamente o chunkSize e refazer o split
    }

    const res = await summaryChain.invoke({ text: chunkText });
    chunkSummaries.push(res.text);
  }

  // 3. Cadeia de Sumarização Consolidada
  const consolidatedText = chunkSummaries.join("\n\n");
  const consolidatedTokenCount = estimateTokens(consolidatedText);
  
  // Validação Final: O texto consolidado respeita o limite de contexto?
  const CONTEXT_LIMIT = 4096; // Limite estimado para gpt-3.5-turbo
  if (consolidatedTokenCount > CONTEXT_LIMIT) {
    console.error(`Erro: O resumo consolidado (${consolidatedTokenCount} tokens) excede o limite de contexto (${CONTEXT_LIMIT}).`);
    throw new Error("Limite de contexto excedido. Aplique recursão ou reduza o tamanho dos chunks.");
  }

  console.log(`Resumo consolidado pronto (${consolidatedTokenCount} tokens). Gerando relatório final...`);

  const finalTemplate = `
    Com base nos resumos parciais abaixo, gere um relatório final coeso.
    Resumos: {summaries}
    Relatório Final:
  `;
  const finalPrompt = new PromptTemplate({ template: finalTemplate, inputVariables: ["summaries"] });
  const finalChain = new LLMChain({ llm: model, prompt: finalPrompt });

  const finalResult = await finalChain.invoke({ summaries: consolidatedText });
  
  // Log final de custos
  console.log(`Total de tokens consumidos (estimado): ${totalTokensUsed + consolidatedTokenCount}`);

  return finalResult.text;
}

// Exemplo de uso com um texto longo fictício
// const longText = "..." // texto muito longo
// summarizeLongDocument(longText).then(console.log);
