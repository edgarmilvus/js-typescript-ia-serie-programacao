/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.tsx
// Description: Soluções e Explicações
// ==========================================

'use client';

import { useState } from 'react';

// Interface para os títulos gerados
interface GeneratedTitle {
  title: string;
}

export default function BlogTitleGenerator() {
  const [draft, setDraft] = useState('');
  const [titles, setTitles] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedTitle, setSelectedTitle] = useState('');
  const [refinementInstruction, setRefinementInstruction] = useState('');

  // Função para chamar a API (Server Action ou Route Handler)
  const generateTitles = async (text: string, instruction?: string) => {
    setLoading(true);
    try {
      // Supondo uma API route em /api/generate-titles
      const response = await fetch('/api/generate-titles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ draft: text, instruction }),
      });
      
      if (!response.ok) throw new Error('Falha na geração');
      
      const data = await response.json();
      
      // Se for refinamento, substitui o título selecionado
      if (instruction) {
        setTitles(prev => prev.map(t => t === selectedTitle ? data.titles[0] : t));
        setModalOpen(false);
      } else {
        setTitles(data.titles);
      }
    } catch (error) {
      console.error(error);
      alert('Erro ao gerar títulos');
    } finally {
      setLoading(false);
    }
  };

  // Função para copiar para clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Título copiado!');
  };

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Gerador de Títulos de Blog</h1>
      
      <textarea
        className="w-full p-3 border rounded mb-4"
        rows={5}
        placeholder="Cole seu rascunho aqui..."
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
      />

      <button
        onClick={() => generateTitles(draft)}
        disabled={loading || !draft}
        className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50"
      >
        {loading ? 'Gerando...' : 'Gerar Títulos'}
      </button>

      {titles.length > 0 && (
        <ul className="mt-6 space-y-2">
          {titles.map((title, index) => (
            <li 
              key={index} 
              className="flex justify-between items-center p-3 bg-gray-50 border rounded cursor-pointer hover:bg-gray-100"
              onClick={() => copyToClipboard(title)}
              title="Clique para copiar"
            >
              <span>{title}</span>
              <div className="flex gap-2">
                <button 
                  className="text-sm text-blue-600 underline"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedTitle(title);
                    setModalOpen(true);
                  }}
                >
                  Refinar
                </button>
                <span className="text-xs text-gray-400">Clique para copiar</span>
              </div>
            </li>
          ))}
        </ul>
      )}

      {/* Modal de Refinamento */}
      {modalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded w-96">
            <h2 className="text-xl font-bold mb-2">Refinar Título</h2>
            <p className="mb-2 text-sm text-gray-600">Atual: "{selectedTitle}"</p>
            <textarea
              className="w-full p-2 border rounded mb-4"
              placeholder="Ex: Torne mais formal, adicione urgência..."
              value={refinementInstruction}
              onChange={(e) => setRefinementInstruction(e.target.value)}
            />
            <div className="flex justify-end gap-2">
              <button onClick={() => setModalOpen(false)} className="px-3 py-1 text-gray-600">Cancelar</button>
              <button 
                onClick={() => generateTitles(draft, refinementInstruction)} 
                className="px-3 py-1 bg-green-600 text-white rounded"
              >
                Refazer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
