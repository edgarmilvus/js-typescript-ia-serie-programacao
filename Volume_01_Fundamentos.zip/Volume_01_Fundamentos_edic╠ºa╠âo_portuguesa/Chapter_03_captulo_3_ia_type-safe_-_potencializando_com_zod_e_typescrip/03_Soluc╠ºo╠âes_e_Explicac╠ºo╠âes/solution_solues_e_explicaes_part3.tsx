/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.tsx
// Description: Soluções e Explicações
// ==========================================

import React, { useState } from 'react';
import { z } from 'zod';

// 1. Definição do Schema da Mensagem
const messageSchema = z.object({
  content: z.string().min(1, "O conteúdo não pode estar vazio."),
  role: z.enum(['user', 'system']),
  metadata: z.object({
    timestamp: z.string().datetime(),
    source: z.string(),
  }),
});

// Tipo inferido
type MessagePayload = z.infer<typeof messageSchema>;

// Tipo parcial para o estado inicial (rascunho)
type DraftMessage = Partial<MessagePayload>;

interface Props {
  initialDraft?: DraftMessage;
}

export const ChatInput: React.FC<Props> = ({ initialDraft }) => {
  // 2. Estado tipado estritamente
  // Garantimos que campos obrigatórios possam ser undefined durante a edição, mas não no envio
  const [message, setMessage] = useState<DraftMessage>({
    content: initialDraft?.content || '',
    role: initialDraft?.role || 'user',
    metadata: initialDraft?.metadata || { timestamp: new Date().toISOString(), source: 'web' }
  });

  const [error, setError] = useState<string | null>(null);

  // 3. Atualização do estado
  const handleChange = (field: keyof DraftMessage, value: any) => {
    setMessage((prev) => ({ ...prev, [field]: value }));
    setError(null); // Limpa erro ao digitar
  };

  // 4. Submissão com Validação
  const handleSubmit = () => {
    // Adiciona timestamp automático se não existir
    const payloadToValidate = {
      ...message,
      metadata: {
        ...message.metadata,
        timestamp: message.metadata?.timestamp || new Date().toISOString(),
      }
    };

    const result = messageSchema.safeParse(payloadToValidate);

    if (!result.success) {
      // Exibe erro detalhado
      const errorMsg = result.error.errors.map(e => `${e.path.join('.')}: ${e.message}`).join(', ');
      setError(`Erro de validação: ${errorMsg}`);
      return;
    }

    // Simulação de envio
    console.log("Enviando payload validado:", result.data);
    alert("Mensagem enviada com sucesso!");
  };

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc' }}>
      <h3>Chat Input</h3>
      
      <textarea
        value={message.content || ''}
        onChange={(e) => handleChange('content', e.target.value)}
        placeholder="Digite sua mensagem..."
        rows={3}
        style={{ width: '100%' }}
      />
      
      <div style={{ marginTop: '10px' }}>
        <label>
          Role:
          <select 
            value={message.role || 'user'} 
            onChange={(e) => handleChange('role', e.target.value)}
          >
            <option value="user">User</option>
            <option value="system">System</option>
          </select>
        </label>
      </div>

      {error && <div style={{ color: 'red', marginTop: '10px' }}>{error}</div>}

      <button onClick={handleSubmit} style={{ marginTop: '10px' }}>
        Enviar
      </button>
    </div>
  );
};
