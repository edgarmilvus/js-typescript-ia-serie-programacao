/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.ts
// Description: Soluções e Explicações
// ==========================================

import { z } from 'zod';

// 1. Definição do Schema com Coerção de Tipos
const promptSchema = z.object({
  tema: z.string().min(3, "O tema deve ter pelo menos 3 caracteres."),
  complexidade: z.enum(["basico", "intermediario", "avancado"]),
  formatoSaida: z.object({
    tipo: z.enum(["json", "texto"]),
    // Schema opcional apenas se o tipo for 'json'
    schema: z.string().optional(),
  }),
  // Coerção: transforma string "500" em número 500
  maxTokens: z.coerce.number().int().min(1).max(2000).default(100),
});

// Inferência do tipo baseado no schema (Strict Type Discipline)
type PromptInput = z.infer<typeof promptSchema>;

// 2. Função de Validação e Construção
export function construirPromptValidado(inputRaw: unknown): PromptInput {
  try {
    // Tenta validar e parsear os dados
    const dadosValidados = promptSchema.parse(inputRaw);
    
    // Construção do prompt (simulação)
    console.log(`Prompt gerado para o tema: ${dadosValidados.tema}`);
    
    return dadosValidados;
  } catch (error) {
    if (error instanceof z.ZodError) {
      // Tratamento de erro detalhado
      const mensagensErro = error.errors.map((err) => 
        `${err.path.join('.')}: ${err.message}`
      ).join('; ');
      
      throw new Error(`Falha na validação do prompt: ${mensagensErro}`);
    }
    // Re-throw para erros inesperados
    throw error;
  }
}

// --- Cenário Interativo (Simulação de Erro e Correção) ---
// const inputComErro = { tema: "Teste", complexidade: "invalida", maxTokens: "500" }; // Falha
// const inputCorreto = { tema: "Futuro da IA", complexidade: "avancado", maxTokens: "500" }; // Passa (coerção)

// construirPromptValidado(inputCorreto); 
