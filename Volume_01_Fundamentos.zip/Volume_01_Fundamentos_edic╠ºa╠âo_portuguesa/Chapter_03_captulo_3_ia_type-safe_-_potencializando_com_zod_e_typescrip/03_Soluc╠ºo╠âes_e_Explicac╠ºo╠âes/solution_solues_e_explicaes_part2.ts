/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part2.ts
// Description: Soluções e Explicações
// ==========================================

import { z } from 'zod';

// 1. Definição de Interfaces Base
interface RetrievalResult {
  id: string;
  content: string;
  metadata: Record<string, unknown>;
}

interface BaseLLMResponse {
  resposta: string;
  usage?: number;
}

// 2. Definição de Interfaces Derivadas (Utility Types)
// Usando Omit para criar um tipo específico para o parser final
type FormattedOutput = Omit<BaseLLMResponse, 'usage'> & {
  status: 'success' | 'error';
};

// 3. Schemas Zod para Validação Intermediária
const retrievalSchema = z.object({
  id: z.string().uuid(),
  content: z.string().min(1),
  metadata: z.record(z.unknown())
});

// Schema flexível para o LLM (aceita objeto ou array)
const llmOutputSchema = z.union([
  z.object({ respostaFinal: z.string() }),
  z.array(z.object({ respostaFinal: z.string() }))
]);

// 4. Função Tipada da Cadeia
async function executarCadeiaTipada(contextoBruto: unknown): Promise<FormattedOutput> {
  // Etapa 1: Retriever (Validação e Tipagem)
  const retrievalValidado: RetrievalResult = retrievalSchema.parse(contextoBruto);

  // Simulação de geração de prompt com o contexto recuperado
  const prompt = `Contexto: ${retrievalValidado.content}. Gere uma resposta.`;
  
  // Simulação de resposta do LLM (pode ser objeto único ou array)
  const llmResponseRaw: unknown = await simularLLM(prompt);

  // Etapa 2: Validação do Output do LLM
  const parsedLLM = llmOutputSchema.parse(llmResponseRaw);

  // Etapa 3: Parser Final (Normalização do dado)
  let respostaFinal: string;
  
  if (Array.isArray(parsedLLM)) {
    // Se for array, pega o primeiro item (exemplo de lógica)
    respostaFinal = parsedLLM[0].respostaFinal;
  } else {
    respostaFinal = parsedLLM.respostaFinal;
  }

  // Retorno tipado com Utility Type
  return {
    resposta: respostaFinal,
    status: 'success'
  };
}

// Simulação de uma função externa (LLM)
async function simularLLM(prompt: string): Promise<unknown> {
  // Simula retorno variado (objeto ou array) para testar a validação
  return Math.random() > 0.5 
    ? { respostaFinal: "Resposta única." } 
    : [{ respostaFinal: "Resposta em array." }];
}
