/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.ts
// Description: Soluções e Explicações
// ==========================================

import { z } from 'zod';

// 1. Schema de Documento com Coerção de Data
const documentSchema = z.object({
  id: z.string().uuid(),
  titulo: z.string().min(1),
  tags: z.array(z.string()).min(1).max(5),
  // Desafio Interativo: Aceita string ISO ou number (timestamp) e converte para string ISO
  dataPublicacao: z.preprocess((val) => {
    if (typeof val === 'number') {
      return new Date(val).toISOString();
    }
    if (typeof val === 'string') {
      // Valida se é uma data válida
      const date = new Date(val);
      return isNaN(date.getTime()) ? null : date.toISOString();
    }
    return null;
  }, z.string().datetime()),
});

// Tipo do Documento Validado
type Documento = z.infer<typeof documentSchema>;

// 2. Interface de Citação usando Utility Type Pick
// Extrai apenas 'id' e 'titulo' de Documento
type Citation = Pick<Documento, 'id' | 'titulo'>;

// 3. Função de Processamento de Recuperação
function processarRecuperacao(rawDocs: unknown[]): Documento[] {
  return rawDocs.map((doc) => documentSchema.parse(doc));
}

// 4. Função de Formatação de Resposta
function formatarRespostaComCitacoes(
  respostaLLM: string, 
  documentos: Documento[]
): { resposta: string; citacoes: Citation[] } {
  // Projeção dos dados para citações
  const citacoes: Citation[] = documentos.map(doc => ({
    id: doc.id,
    titulo: doc.titulo
  }));

  return {
    resposta: respostaLLM,
    citacoes: citacoes
  };
}

// --- Simulação ---
const rawInput = [
  { 
    id: "123e4567-e89b-12d3-a456-426614174000", 
    titulo: "Artigo IA", 
    tags: ["tech", "ai"], 
    dataPublicacao: 1672531200000 // Timestamp numérico
  },
  { 
    id: "123e4567-e89b-12d3-a456-426614174001", 
    titulo: "Guia RAG", 
    tags: ["tutorial"], 
    dataPublicacao: "2023-01-01T00:00:00Z" // String ISO
  }
];

const docsValidados = processarRecuperacao(rawInput);
const resultadoFinal = formatarRespostaComCitacoes("A IA evoluiu muito...", docsValidados);

console.log(resultadoFinal);
