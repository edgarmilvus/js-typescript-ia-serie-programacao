/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part5.ts
// Description: Soluções e Explicações
// ==========================================

import { z } from 'zod';

// 1. Schema de Validação de Ambiente
const envSchema = z.object({
  OPENAI_API_KEY: z.string().refine((val) => val.startsWith('sk-'), {
    message: "A chave da API deve começar com 'sk-'",
  }),
  DATABASE_URL: z.string().url().optional(),
});

// Tipo baseado no schema
type EnvConfig = z.infer<typeof envSchema>;

// 2. Função de Carga Flexível (Desafio Interativo)
// Aceita um objeto opcional (para testes) e retorna a configuração validada.
// Em produção, exige a chave da API.
export function loadConfig(overrideEnvs?: Partial<Record<keyof EnvConfig, string>>): EnvConfig {
  // Combina variáveis reais do sistema com overrides de teste
  const rawEnv = {
    OPENAI_API_KEY: process.env.OPENAI_API_KEY,
    DATABASE_URL: process.env.DATABASE_URL,
    ...overrideEnvs,
  };

  // Validação
  const result = envSchema.safeParse(rawEnv);

  if (!result.success) {
    console.error("Erro na validação de ambiente:", result.error.format());
    throw new Error("Configuração inválida. Verifique as variáveis de ambiente.");
  }

  return result.data;
}

// 3. Configuração do Cliente (Simulação)
export function initializeClient(config: EnvConfig) {
  // Aqui criariamos o cliente real (ex: new OpenAI({ apiKey: config.OPENAI_API_KEY }))
  console.log("Cliente inicializado com chave:", config.OPENAI_API_KEY.substring(0, 7) + "...");
  return { status: "connected" };
}
