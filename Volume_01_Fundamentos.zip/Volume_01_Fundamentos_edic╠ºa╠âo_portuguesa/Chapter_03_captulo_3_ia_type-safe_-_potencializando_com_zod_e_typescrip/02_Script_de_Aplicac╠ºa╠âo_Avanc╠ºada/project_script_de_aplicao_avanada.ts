/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.ts
// Description: Script de Aplicação Avançada
// ==========================================

// app/api/feedback/route.ts
// Este arquivo define o endpoint da API que recebe o feedback do usuário.
// Ele atua como a primeira linha de defesa, validando os dados brutos da requisição HTTP.

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { OpenAI } from 'openai';
import { zodResponseFormat } from 'openai/helpers/zod';

// ==============================================================================
// 1. DEFINIÇÃO DE ESQUEMAS (ZOD) - O CONTRATO DE TIPO SEGURO
// ==============================================================================

/**
 * Schema de entrada: Valida os dados que chegam do frontend.
 * Garante que o texto não esteja vazio e que a categoria seja uma das permitidas.
 */
const FeedbackInputSchema = z.object({
  text: z.string().min(10, "O feedback deve ter pelo menos 10 caracteres."),
  category: z.enum(['bug', 'feature', 'general'], {
    errorMap: (issue, ctx) => ({ message: 'Categoria inválida. Use bug, feature ou general.' })
  }),
  urgency: z.number().min(1).max(5).optional()
});

/**
 * Schema de saída (LLM): Define a estrutura que esperamos da resposta da OpenAI.
 * Isso força o modelo a retornar dados estruturados (JSON) em vez de texto livre.
 */
const AnalysisResultSchema = z.object({
  summary: z.string().describe("Resumo conciso do feedback."),
  sentiment: z.enum(['positive', 'negative', 'neutral']).describe("Sentimento geral do usuário."),
  priority: z.enum(['low', 'medium', 'high']).describe("Nível de prioridade baseado na urgência e impacto."),
  actionItems: z.array(z.string()).describe("Lista de ações sugeridas para a equipe de produto.")
});

// Tipos derivados dos schemas (Type Inference)
type FeedbackInput = z.infer<typeof FeedbackInputSchema>;
type AnalysisResult = z.infer<typeof AnalysisResultSchema>;

// ==============================================================================
// 2. AGENTE ESPECIALIZADO (WORKER AGENT)
// ==============================================================================

/**
 * Agente responsável por analisar o feedback usando a OpenAI.
 * Ele recebe dados já validados e retorna dados validados.
 * 
 * @param input - Objeto de feedback validado pelo Supervisor.
 * @returns Promise<AnalysisResult> - Objeto analisado validado pelo schema.
 * @throws Error - Se a análise falhar ou a resposta não corresponder ao schema.
 */
async function analyzeFeedbackAgent(input: FeedbackInput): Promise<AnalysisResult> {
  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

  try {
    // Construção do prompt com contexto do input validado
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'Você é um analista de produto especializado. Analise o feedback do usuário e retorne JSON estruturado.' },
        { role: 'user', content: `Categoria: ${input.category}\nUrgência: ${input.urgency || 'Não informada'}\nFeedback: ${input.text}` }
      ],
      // Garantia de Type Safety: Forçamos a API a retornar JSON válido baseado no nosso schema Zod
      response_format: zodResponseFormat(AnalysisResultSchema, "analysis")
    });

    const rawContent = completion.choices[0].message.content;
    
    if (!rawContent) {
      throw new Error("A IA retornou uma resposta vazia.");
    }

    // Runtime Validation: Mesmo a IA sendo confiável, validamos a saída.
    // Se a IA alucinar um campo faltante, o Zod lançará um erro aqui.
    return AnalysisResultSchema.parse(JSON.parse(rawContent));

  } catch (error) {
    console.error("Erro no agente de análise:", error);
    throw new Error("Falha ao processar a análise com a IA.");
  }
}

// ==============================================================================
// 3. NÓ SUPERVISOR (SUPERVISOR NODE)
// ==============================================================================

/**
 * O Supervisor orquestra o fluxo de trabalho.
 * 1. Valida o input do usuário (Runtime Validation).
 * 2. Delega para o agente especializado.
 * 3. Captura e valida a resposta do agente.
 * 
 * @param rawData - Dados brutos recebidos da requisição HTTP.
 * @returns Promise<AnalysisResult> - O resultado final validado.
 */
async function supervisorNode(rawData: unknown): Promise<AnalysisResult> {
  // Passo 1: Validação de Input (Type Narrowing)
  // Se a validação falhar, o Zod lança um erro que será capturado pela API Route.
  // Se passar, 'parsedData' é tipado como 'FeedbackInput' (Type Narrowing).
  const parsedData = FeedbackInputSchema.parse(rawData);

  // Passo 2: Delegação ao Worker
  // Apenas dados válidos chegam aqui.
  const analysis = await analyzeFeedbackAgent(parsedData);

  // Passo 3: Validação de Output (Defesa em profundidade)
  // Garantimos que o agente cumpriu o contrato antes de retornar ao cliente.
  return AnalysisResultSchema.parse(analysis);
}

// ==============================================================================
// 4. SERVIÇO DE API (NEXT.JS ROUTE HANDLER)
// ==============================================================================

export async function POST(request: NextRequest) {
  try {
    // Leitura do corpo da requisição
    const body = await request.json();

    // Execução do Supervisor
    const result = await supervisorNode(body);

    // Retorno bem-sucedido
    return NextResponse.json({ success: true, data: result }, { status: 200 });

  } catch (error) {
    // Tratamento de erros de validação do Zod
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: 'Dados inválidos', details: error.errors },
        { status: 400 } // Bad Request
      );
    }

    // Erros genéricos (ex: falha de conexão com a IA)
    console.error(error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
