/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_fundamentos_tericos_part2.ts
// Description: Fundamentos Teóricos
// ==========================================

import { z } from 'zod';

// 1. Definição do Schema com Zod (Fonte Única da Verdade)
const ChatStateSchema = z.object({
  messages: z.array(
    z.object({
      role: z.enum(['user', 'assistant']), // Garante que o papel seja apenas um dos dois
      content: z.string().min(1, "O conteúdo da mensagem não pode estar vazio."), // Validação de formato e regra
    })
  ),
  userId: z.string().optional(), // Opcional, mas se presente, deve ser string
  metadata: z.object({
    sessionId: z.string().uuid(), // Valida formato de UUID
    timestamp: z.number().int().positive(), // Deve ser um inteiro positivo
  }),
});

// 2. Inferência de Tipo do TypeScript a partir do Schema
type ChatState = z.infer<typeof ChatStateSchema>;
