/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.ts
// Description: Exemplo de Código Básico
// ==========================================

// Importações necessárias para o funcionamento do Zod
// Certifique-se de ter instalado: npm install zod
import { z } from 'zod';

/**
 * 1. DEFINIÇÃO DO SCHEMA (A "Lei" dos Dados)
 * Aqui definimos a estrutura exata que esperamos receber.
 * O Zod cria uma descrição runtime dos dados que também serve como definição de tipo para o TypeScript.
 */
const UserSchema = z.object({
  id: z.number().int().positive(), // Deve ser um inteiro positivo
  nome: z.string().min(1),         // Não pode ser string vazia
  email: z.string().email(),       // Deve ter formato de email válido
  cargo: z.enum(['admin', 'user', 'editor']), // Deve ser um desses valores específicos
  ativo: z.boolean(),              // Booleano obrigatório
});

/**
 * 2. TIPO INFERIDO PELO ZOD
 * Extraímos o tipo TypeScript a partir do schema.
 * Isso garante que a definição de tipo e a validação nunca fiquem dessincronizadas.
 */
type User = z.infer<typeof UserSchema>;

/**
 * 3. FUNÇÃO TIPO GUARD (O Guardião)
 * Esta função encapsula a validação e atua como um Type Guard.
 * Ela verifica se o dado bruto (input) corresponde ao schema.
 * Se sim, o TypeScript sabe que 'data' é do tipo 'User' dentro do bloco if.
 * 
 * @param data - Qualquer objeto recebido (possivelmente da API da IA)
 * @returns boolean - True se válido, False caso contrário
 */
function isValidUser(data: unknown): data is User {
  // Tenta validar os dados contra o schema
  const result = UserSchema.safeParse(data);
  
  // Retorna true se a validação for bem-sucedida
  return result.success;
}

/**
 * 4. SIMULAÇÃO DE RESPOSTA DA IA
 * Em um cenário real, isso viria de uma chamada fetch() para a OpenAI ou LangChain.
 * Aqui, criamos um objeto deliberadamente incompleto ou incorreto para testar a validação.
 */
const rawResponseFromAI: unknown = {
  id: 101,
  nome: "Alice Silva",
  email: "alice.exemplo.com", // Email inválido propositalmente
  cargo: "admin",
  // Falta a propriedade 'ativo'
};

/**
 * 5. LÓGICA DA APLICAÇÃO (Web App / SaaS)
 * Esta função processa a resposta da IA.
 * Ela só avança se os dados forem validados com sucesso.
 */
function processUserRegistration(dataFromAI: unknown) {
  console.log("--- Iniciando Processamento ---");

  // O Type Guard aqui é crucial. Dentro do if, 'dataFromAI' é tipado como 'User'.
  if (isValidUser(dataFromAI)) {
    // Acessamos propriedades com segurança total. O TS sabe que 'email' é string.
    console.log(`[Sucesso] Usuário ${dataFromAI.nome} validado.`);
    console.log(`[DB] Salvando usuário com email: ${dataFromAI.email}`);
    
    // Aqui poderíamos prosseguir para o banco de dados ou UI
    return dataFromAI; 
  } else {
    // Se falhar, entramos no bloco de erro.
    // O Zod nos dá detalhes precisos sobre o que deu errado.
    const parsed = UserSchema.safeParse(dataFromAI);
    if (!parsed.success) {
      console.error("[Erro de Validação] Os dados recebidos são inválidos:");
      // Detalhando os erros para o desenvolvedor
      parsed.error.errors.forEach((err) => {
        console.error(`  - Campo '${err.path.join('.')}' falhou: ${err.message}`);
      });
    }
    return null;
  }
}

// Execução do exemplo
processUserRegistration(rawResponseFromAI);
