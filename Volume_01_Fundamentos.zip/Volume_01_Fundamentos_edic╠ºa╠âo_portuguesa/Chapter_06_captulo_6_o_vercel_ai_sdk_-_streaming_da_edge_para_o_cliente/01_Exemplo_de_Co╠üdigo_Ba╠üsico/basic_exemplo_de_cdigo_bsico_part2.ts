/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico_part2.ts
// Description: Exemplo de Código Básico
// ==========================================

// app/page.tsx
'use client'; // Componente de cliente para interatividade e estado local

import { useState } from 'react';
import { readStreamableValue } from 'ai/rsc'; // Função para ler o stream no cliente
import { generateStreamResponse } from './actions'; // Importa a Server Action

export default function ChatPage() {
  const [input, setInput] = useState(''); // Estado para o input do usuário
  const [response, setResponse] = useState(''); // Estado para acumular a resposta do stream
  const [isLoading, setIsLoading] = useState(false); // Estado de carregamento

  /**
   * Manipula o envio do formulário.
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input) return;

    setIsLoading(true);
    setResponse(''); // Limpa a resposta anterior

    try {
      // 1. Chama a Server Action passando o input.
      const { uiStream } = await generateStreamResponse(input);

      // 2. Itera sobre o stream recebido.
      // readStreamableValue retorna um AsyncIterable.
      for await (const chunk of readStreamableValue(uiStream)) {
        // 3. Atualiza o estado do React com cada chunk recebido.
        // Isso causa a re-renderização do componente palavra por palavra.
        if (chunk) {
          setResponse((prev) => prev + chunk);
        }
      }
    } catch (error) {
      console.error('Erro no stream:', error);
      setResponse('Erro ao gerar resposta.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h1>Chat com Streaming (Vercel AI SDK)</h1>
      
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Digite algo..."
          disabled={isLoading}
          style={{ padding: '10px', width: '300px', marginRight: '10px' }}
        />
        <button type="submit" disabled={isLoading} style={{ padding: '10px' }}>
          {isLoading ? 'Processando...' : 'Enviar'}
        </button>
      </form>

      <div style={{ marginTop: '20px', padding: '10px', border: '1px solid #ccc', minHeight: '100px' }}>
        <strong>Resposta:</strong>
        <p>{response}</p>
        {/* Indicador visual de que o stream está ativo */}
        {isLoading && <span style={{ color: '#999' }}>|</span>}
      </div>
    </div>
  );
}
