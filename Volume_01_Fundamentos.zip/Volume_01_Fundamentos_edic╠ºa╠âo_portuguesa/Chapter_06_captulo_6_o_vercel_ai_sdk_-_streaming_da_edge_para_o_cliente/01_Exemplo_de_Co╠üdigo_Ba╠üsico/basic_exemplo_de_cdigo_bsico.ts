/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.ts
// Description: Exemplo de Código Básico
// ==========================================

// app/actions.ts
'use server'; // Marca este arquivo como Server Actions (execução no servidor/edge)

import { generateText } from 'ai'; // Importa a função principal do Vercel AI SDK
import { openai } from '@ai-sdk/openai'; // Provider da OpenAI
import { createStreamableValue } from 'ai/rsc'; // Utilitário para criar streams reativos

/**
 * Função Server Action que recebe um prompt e retorna um stream de texto.
 * @param {string} input - O prompt do usuário.
 * @returns {Promise<{uiStream: import('ai/rsc').StreamableValue<string>}>} - Um objeto contendo o stream.
 */
export async function generateStreamResponse(input: string) {
  // 1. Cria um objeto streamable que pode ser "pushado" incrementalmente.
  const stream = createStreamableValue('');

  // 2. Inicia a geração da resposta em segundo plano (não bloqueia a resposta inicial).
  (async () => {
    try {
      // 3. Usa a API do Vercel AI SDK para gerar texto.
      // O SDK lida com o chunking e o parsing de resposta da OpenAI automaticamente.
      const { text } = await generateText({
        model: openai('gpt-3.5-turbo'),
        prompt: input,
      });

      // 4. Simula o streaming palavra por palavra para demonstração visual.
      // Em produção, o SDK já faz isso internamente, mas aqui explicitamos o loop
      // para garantir que o cliente veja o progresso.
      const words = text.split(' ');
      for (const word of words) {
        // Aguarda um breve momento para simular o tempo de processamento
        await new Promise(resolve => setTimeout(resolve, 50));
        
        // Adiciona a palavra (e um espaço) ao stream
        stream.update(word + ' ');
      }

    } catch (error) {
      // 5. Em caso de erro, envia o erro para o stream e fecha.
      stream.error(error);
    } finally {
      // 6. Fecha o stream quando todos os dados foram enviados.
      stream.done();
    }
  })();

  // Retorna o objeto stream imediatamente para o cliente.
  return {
    uiStream: stream.value,
  };
}
