/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part9.ts
// Description: Soluções e Explicações
// ==========================================

// /app/form-component.tsx (Frontend)
'use client';

import { useFormState } from 'react-dom';
import { generateContent } from './actions';
import { formSchema } from '@/lib/validators';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';

export function ContentForm() {
  // 2. Validação no Cliente (Rápida)
  const { register, handleSubmit, formState: { errors: clientErrors } } = useForm({
    resolver: zodResolver(formSchema),
  });

  // 3. Integração com Server Action
  const [state, formAction] = useFormState(generateContent, null);

  const onSubmit = (data: any) => {
    // Dispara a Server Action
    formAction(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      {/* Campo Style */}
      <select {...register('style')}>
        <option value="formal">Formal</option>
        <option value="casual">Casual</option>
      </select>
      {clientErrors.style && <span>{clientErrors.style.message}</span>}

      {/* Campo Tone */}
      <input {...register('tone')} placeholder="Tom (ex: amigável)" />
      {clientErrors.tone && <span>{clientErrors.tone.message}</span>}

      {/* Campo Length */}
      <input type="number" {...register('length', { valueAsNumber: true })} />
      {clientErrors.length && <span>{clientErrors.length.message}</span>}

      <button type="submit">Gerar</button>

      {/* Exibição de Erros do Servidor */}
      {state?.errors && (
        <div className="server-errors">
          {/* Renderiza erros vindos do servidor (fallback) */}
        </div>
      )}
      
      {/* Renderização do Stream */}
      {state?.status === 'success' && (
        <div className="stream-output">
          {/* Lógica para renderizar o stream text */}
        </div>
      )}
    </form>
  );
}
