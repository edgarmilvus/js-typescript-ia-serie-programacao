/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.ts
// Description: Soluções e Explicações
// ==========================================

// /app/actions.ts
'use server';

import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { prisma } from './lib/prisma'; // Assume Prisma configurado
import { revalidatePath } from 'next/cache';

// Função para salvar mensagem completa (não fragmentada)
async function saveMessage(chatId: string, role: 'user' | 'assistant', content: string) {
  await prisma.message.create({
    data: {
      chatId,
      role,
      content,
    },
  });
}

export async function sendMessage(chatId: string, content: string) {
  // 1. Salva a mensagem do usuário imediatamente
  await saveMessage(chatId, 'user', content);

  // 2. Inicia o stream
  const result = await streamText({
    model: openai('gpt-4o'),
    prompt: content,
  });

  // 3. Estratégia de Persistência durante o Streaming
  // Criamos um ReadableStream customizado para interceptar o stream completo
  const stream = new ReadableStream({
    async start(controller) {
      let fullResponse = '';

      // Consumimos o stream do SDK
      for await (const chunk of result.textStream) {
        fullResponse += chunk;
        // Envia o chunk para o cliente (mantendo a UI responsiva)
        controller.enqueue(chunk);
      }

      // 4. Salva a mensagem da IA APENAS AQUI, após o término
      if (fullResponse.length > 0) {
        await saveMessage(chatId, 'assistant', fullResponse);
        // Revalida o cache se necessário para mostrar o histórico atualizado
        revalidatePath(`/chat/${chatId}`);
      }

      controller.close();
    },
  });

  return { stream, text: result.text }; // Retorna o stream para o cliente
}

// 5. Carregar Histórico
export async function loadChatHistory(chatId: string) {
  const messages = await prisma.message.findMany({
    where: { chatId },
    orderBy: { createdAt: 'asc' },
  });
  return messages;
}
