/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.ts
// Description: Soluções e Explicações
// ==========================================

// /app/actions.ts
'use server';

import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

// 1. Schema de Saída do Supervisor
const supervisorSchema = z.object({
  agent_type: z.enum(['sales', 'support']),
  context_summary: z.string(),
});

export async function delegateTask(userMessage: string) {
  // 2. Chamada ao modelo com schema estruturado
  const result = await streamText({
    model: openai('gpt-4o'),
    prompt: `Classifique a seguinte mensagem do usuário para 'sales' ou 'support': ${userMessage}`,
    experimental_providerMetadata: {
      openai: {
        response_format: { type: 'json_object' },
      },
    },
    // Forçando o modelo a retornar JSON válido baseado no schema
    system: `Você deve retornar um JSON válido com as chaves "agent_type" e "context_summary".`,
  });

  // Consumimos o texto completo para extrair o JSON (pois streamText retorna tokens)
  const textStream = await result.textStream;
  let fullText = '';
  
  for await (const chunk of textStream) {
    fullText += chunk;
    // Opcional: Enviar chunks de "Processando..." para o cliente se necessário
  }

  // 3. Validação e Lógica de Fallback
  let parsedData;
  try {
    // Tentativa de parse do JSON retornado pelo modelo
    const jsonStart = fullText.indexOf('{');
    const jsonEnd = fullText.lastIndexOf('}') + 1;
    const jsonString = fullText.substring(jsonStart, jsonEnd);
    parsedData = JSON.parse(jsonString);
  } catch (error) {
    // Fallback: Se o JSON for mal formado
    return { 
      agent: 'support', 
      message: 'Ocorreu um erro de classificação. Conectando com suporte técnico para assistência imediata.',
      error: 'JSON_PARSE_ERROR' 
    };
  }

  const validation = supervisorSchema.safeParse(parsedData);

  if (!validation.success) {
    // Fallback: Se o schema não for validado (ex: agent_type inválido)
    return {
      agent: 'support', // Agente padrão de segurança
      message: 'Não foi possível determinar a natureza da sua solicitação com precisão. Por favor, aguarde enquanto transfero para um especialista.',
      error: 'VALIDATION_ERROR',
      details: validation.error.errors
    };
  }

  const { agent_type, context_summary } = validation.data;

  // 4. Execução do Agente Específico (Simulação)
  if (agent_type === 'sales') {
    // Chama função de vendas
    return { agent: 'sales', message: `Oferta especial baseada em: ${context_summary}` };
  } else {
    // Chama função de suporte
    return { agent: 'support', message: `Solução técnica para: ${context_summary}` };
  }
}
