/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.ts
// Description: Soluções e Explicações
// ==========================================

// /app/actions.ts
'use server';

import { streamUI } from '@ai-sdk/react'; // Assumindo o pacote correto para server actions
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

// 1. Definição dos Componentes Renderizáveis
const TextResponse = ({ content }: { content: string }) => (
  <div className="p-4 bg-gray-100 rounded-lg">
    <p>{content}</p>
  </div>
);

const TaskList = ({ tasks }: { tasks: string[] }) => (
  <ul className="list-disc pl-5 space-y-2 bg-blue-50 p-4 rounded-lg">
    {tasks.map((task, index) => (
      <li key={index} className="flex items-center">
        <input type="checkbox" className="mr-2" />
        {task}
      </li>
    ))}
  </ul>
);

// 2. Schema JSON esperado da IA
const responseSchema = z.object({
  type: z.enum(['text', 'task_list']),
  content: z.string().optional(),
  tasks: z.array(z.string()).optional(),
});

export async function generateResponse(prompt: string) {
  const result = await streamUI({
    model: openai('gpt-4o'),
    prompt,
    // 3. Configuração do render para mapear a resposta
    text: ({ content }) => <TextResponse content={content} />,
    tools: {
      // Ferramenta para retornar JSON estruturado
      renderComponent: {
        description: 'Renderiza um componente específico com dados',
        parameters: responseSchema,
        generate: async function* ({ type, content, tasks }) {
          // Lógica de streaming para o desafio interativo
          if (type === 'text' && content) {
            yield <TextResponse content={content} />;
          } else if (type === 'task_list' && tasks) {
            // Simula um delay para o streaming da lista
            await new Promise(resolve => setTimeout(resolve, 500));
            return <TaskList tasks={tasks} />;
          }
        },
      },
    },
  });

  return result;
}
