/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part5.ts
// Description: Soluções e Explicações
// ==========================================

// /app/actions.ts
'use server';

import { streamUI } from '@ai-sdk/react';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

// 1. Componente de Gráfico (Exemplo simplificado)
const ChartRenderer = ({ data }: { data: { label: string; values: number[] }[] }) => (
  <div className="chart-container">
    {data.map((series, i) => (
      <div key={i}>
        <strong>{series.label}:</strong>
        <div className="bar" style={{ width: series.values.reduce((a,b)=>a+b, 0) }}></div>
      </div>
    ))}
  </div>
);

// 2. Schema para múltiplas séries de dados
const chartDataSchema = z.object({
  datasets: z.array(
    z.object({
      label: z.string(),
      values: z.array(z.number()),
    })
  ),
});

export async function getSalesData(query: string) {
  const result = await streamUI({
    model: openai('gpt-4o'),
    prompt: `Analise a consulta: "${query}" e gere dados JSON para um gráfico com datasets contendo label e values (array de números).`,
    
    // 3. Render function para mapear JSON -> Componente
    text: ({ content }) => <div className="p-2 text-gray-500">{content}</div>,
    
    tools: {
      chart: {
        description: 'Renderiza um gráfico com dados',
        parameters: chartDataSchema,
        generate: async function* ({ datasets }) {
          // Validação interna extra (opcional)
          if (!datasets || datasets.length === 0) {
            yield <div>Gerando dados do gráfico...</div>;
            return;
          }
          
          // Retorna o componente preenchido
          return <ChartRenderer data={datasets} />;
        },
      },
    },
  });

  return result;
}
