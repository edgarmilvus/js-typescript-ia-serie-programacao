/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.tsx
// Description: Script de Aplicação Avançada
// ==========================================

// app/page.tsx
'use client';

import { useActionState } from 'react';
import { useStreamableValue } from '@ai-sdk/react';
import { generateChartAction } from '@/app/actions/generateChart';
import { useEffect, useRef } from 'react';

/**
 * Componente de Página Principal para o Chat de Análise de Dados.
 * Utiliza o App Router do Next.js com Server Actions para processar a IA.
 * 
 * Fluxo de Dados:
 * 1. Usuário insere texto.
 * 2. Submissão chama `generateChartAction` (Server Action).
 * 3. A Server Action retorna um `StreamableValue` (stream JSON).
 * 4. O hook `useStreamableValue` consome o stream e atualiza a UI token a token.
 */
export default function DataAnalysisPage() {
  // Referência para o formulário, útil para limpar o input após o envio
  const formRef = useRef<HTMLFormElement>(null);

  // `useActionState` gerencia o estado da submissão da Server Action.
  // O primeiro argumento é a ação, o segundo o estado inicial.
  // `pending` indica se a requisição está em andamento.
  const [state, action, pending] = useActionState(generateChartAction, {
    status: 'idle',
    ui: null,
  });

  // `useStreamableValue` é o hook principal do Vercel AI SDK para o cliente.
  // Ele transforma o stream de bytes/chunks do servidor em um objeto JavaScript atualizável.
  // Isso habilita o "Non-Blocking I/O" no cliente: a UI não congela esperando a resposta completa.
  const [data] = useStreamableValue(state.ui);

  // Efeito para limpar o formulário após uma conclusão bem-sucedida
  useEffect(() => {
    if (state.status === 'success' && formRef.current) {
      formRef.current.reset();
    }
  }, [state.status]);

  return (
    <main className="min-h-screen p-8 bg-gray-50 flex flex-col items-center">
      <div className="w-full max-w-2xl bg-white rounded-xl shadow-lg overflow-hidden">
        
        {/* Cabeçalho da Aplicação */}
        <div className="p-6 border-b border-gray-100">
          <h1 className="text-2xl font-bold text-gray-800">Gerador de Gráficos via IA</h1>
          <p className="text-gray-500 mt-1">
            Descreva seus dados e veja o gráfico ser construído em tempo real.
          </p>
        </div>

        {/* Área de Conteúdo Dinâmico */}
        <div className="p-6 min-h-[300px] bg-gray-50/50">
          {data && (
            <div className="animate-fade-in">
              {/* 
                O JSON retornado pela IA contém a estrutura do gráfico (Chart.js).
                Aqui simulamos a renderização de um componente de gráfico baseado nos dados recebidos.
                Em uma aplicação real, isto alimentaria um <ChartComponent />.
              */}
              <div className="bg-white p-4 rounded border border-gray-200">
                <h3 className="font-semibold mb-2 text-gray-700">Visualização Gerada:</h3>
                <pre className="text-xs text-blue-600 bg-blue-50 p-4 rounded overflow-x-auto">
                  {JSON.stringify(data, null, 2)}
                </pre>
                {/* Nota: Para um gráfico real, você passaria `data` para uma biblioteca como recharts ou chart.js */}
              </div>
            </div>
          )}

          {/* Indicador de Streaming Ativo */}
          {pending && (
            <div className="flex items-center space-x-2 text-gray-400">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-sky-500"></span>
              </span>
              <span>Processando dados...</span>
            </div>
          )}

          {/* Mensagem de Erro */}
          {state.status === 'error' && (
            <div className="text-red-600 bg-red-50 p-4 rounded">
              Erro: {state.error}
            </div>
          )}
        </div>

        {/* Área de Entrada */}
        <div className="p-6 border-t border-gray-100 bg-white">
          <form ref={formRef} action={action} className="flex gap-4">
            <input
              type="text"
              name="prompt"
              placeholder="Ex: Gráfico de barras comparando vendas Q1 vs Q2..."
              required
              className="flex-1 rounded-lg border-gray-300 border px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none transition"
              disabled={pending}
            />
            <button
              type="submit"
              disabled={pending}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 transition"
            >
              {pending ? 'Gerando...' : 'Criar Gráfico'}
            </button>
          </form>
        </div>
      </div>
    </main>
  );
}
