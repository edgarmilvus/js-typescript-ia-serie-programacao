/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada_part2.ts
// Description: Script de Aplicação Avançada
// ==========================================

// app/actions/generateChart.ts
'use server';

import { streamObject } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

/**
 * Server Action: Geração de Gráfico via Streaming.
 * 
 * Esta função atua como a "Edge" da aplicação (mesmo rodando no servidor Node.js).
 * Ela recebe o prompt do usuário, invoca o modelo da OpenAI e retorna um objeto
 * `StreamableValue` que o cliente consome.
 * 
 * Técnica de Streaming: Usamos `streamObject` em vez de `streamText` para garantir
 * que a resposta seja um JSON válido estruturado, ideal para alimentar componentes de UI.
 * O SDK empacota cada chunk JSON parcial em um Uint8Array e o envia via Response Stream.
 */
export async function generateChartAction(
  previousState: any,
  formData: FormData
) {
  const prompt = formData.get('prompt') as string;

  if (!prompt) {
    return { status: 'error', error: 'Prompt vazio' };
  }

  try {
    // Definição do Schema com Zod.
    // A IA será instruída a gerar dados que correspondam a este schema.
    // Isso garante tipagem segura no frontend.
    const chartSchema = z.object({
      type: z.enum(['bar', 'line', 'pie']).describe('Tipo de gráfico mais adequado para os dados'),
      title: z.string().describe('Título do gráfico'),
      labels: z.array(z.string()).describe('Eixo X ou categorias'),
      datasets: z.array(z.object({
        label: z.string(),
        data: z.array(z.number()).describe('Valores numéricos correspondentes às labels'),
        backgroundColor: z.string().optional(),
      })).describe('Conjuntos de dados para plotagem'),
    });

    // Chamada ao Modelo de LLM (OpenAI gpt-4o-mini).
    // O prompt é refinado para focar na estrutura de dados do gráfico.
    const result = await streamObject({
      model: openai('gpt-4o-mini'),
      prompt: `Crie uma estrutura de dados para um gráfico baseado em: "${prompt}".
               Retorne apenas o JSON válido baseado no schema fornecido.`,
      schema: chartSchema,
      // O modo 'json' força a IA a seguir o schema estritamente, otimizando para parsing automático.
      mode: 'json',
    });

    // `result.output` é um `StreamableValue`.
    // O Next.js/RSC serializa isso automaticamente para o cliente.
    // O streaming ocorre aqui: tokens são gerados e enviados conforme a IA os produz.
    return {
      status: 'success',
      ui: result.output, // O atributo 'ui' é convencional para dados de UI no Vercel AI SDK
    };

  } catch (error) {
    console.error('Erro na geração de gráfico:', error);
    return { status: 'error', error: 'Falha ao gerar gráfico' };
  }
}
