/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part2.ts
// Description: Soluções e Explicações
// ==========================================

// summarize.test.ts
import { summarizeText } from './summarize';
import OpenAI from 'openai';

// Mock da biblioteca OpenAI
// Isso intercepta qualquer chamada à instância do OpenAI e retorna um valor simulado
jest.mock('openai', () => {
  return {
    OpenAI: jest.fn().mockImplementation(() => {
      return {
        chat: {
          completions: {
            create: jest.fn(),
          },
        },
      };
    }),
  };
});

// Recuperamos a instância mockada para configurar os comportamentos nos testes
const mockOpenAI = new OpenAI() as any;

describe('summarizeText', () => {
  beforeEach(() => {
    jest.clearAllMocks(); // Limpa mocks entre os testes
  });

  it('deve retornar um resumo esperado quando o input é válido e contém a palavra-chave', async () => {
    // Configuração do mock para sucesso
    const mockResponse = {
      choices: [
        {
          message: {
            content: 'Resumo mockado sobre tópicos importantes.',
          },
        },
      ],
    };
    mockOpenAI.chat.completions.create.mockResolvedValue(mockResponse);

    const text = 'Este é um texto sobre tópicos importantes.';
    const result = await summarizeText(text);

    expect(result).toBe('Resumo mockado sobre tópicos importantes.');
    expect(mockOpenAI.chat.completions.create).toHaveBeenCalledTimes(1);
    
    // Verifica se os parâmetros foram passados corretamente (incluindo temperatura padrão)
    expect(mockOpenAI.chat.completions.create).toHaveBeenCalledWith({
      model: 'gpt-3.5-turbo',
      messages: expect.any(Array),
      temperature: 0.7, // Verifica o padrão
    });
  });

  it('deve lançar um erro quando o input está vazio', async () => {
    const emptyText = '';
    
    // Usamos .rejects para testar erros assíncronos
    await expect(summarizeText(emptyText)).rejects.toThrow('Input text cannot be empty');
    
    // Garante que a API não foi chamada
    expect(mockOpenAI.chat.completions.create).not.toHaveBeenCalled();
  });

  it('deve verificar se o parâmetro de temperatura é passado corretamente', async () => {
    const mockResponse = {
      choices: [{ message: { content: 'Resumo com temperatura alterada.' } }],
    };
    mockOpenAI.chat.completions.create.mockResolvedValue(mockResponse);

    const text = 'Texto de teste.';
    const customTemp = 0.2;
    await summarizeText(text, { temperature: customTemp });

    // Verifica se a temperatura customizada foi passada
    expect(mockOpenAI.chat.completions.create).toHaveBeenCalledWith(
      expect.objectContaining({
        temperature: customTemp,
      })
    );
  });
});
