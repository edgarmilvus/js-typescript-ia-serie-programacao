/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.ts
// Description: Soluções e Explicações
// ==========================================

// productExtractor.ts
import { z } from 'zod';
import { ChatOpenAI } from '@langchain/openai';
import { PromptTemplate } from '@langchain/core/prompts';
import { StructuredOutputParser } from '@langchain/core/output_parsers';

// 1. Definição do Schema com Zod
const ProductSchema = z.object({
  nome: z.string().describe("O nome do produto"),
  preco: z.number().positive().describe("O preço do produto em número decimal"),
  emEstoque: z.boolean().describe("Se o produto está disponível em estoque"),
});

type Product = z.infer<typeof ProductSchema>;

// 2. Função auxiliar para limpar string de preço (Custom Parser)
function cleanPriceString(priceStr: string): number {
  // Remove "R$", vírgulas e espaços
  const cleaned = priceStr.replace(/[R$\s]/g, '').replace(',', '.');
  const parsed = parseFloat(cleaned);
  if (isNaN(parsed)) throw new Error("Formato de preço inválido");
  return parsed;
}

// 3. Função principal de extração
export async function extractProductData(description: string): Promise<Product> {
  const model = new ChatOpenAI({ 
    model: "gpt-3.5-turbo", 
    temperature: 0 
  });

  // Prompt template
  const prompt = new PromptTemplate({
    template: `
      Extract the product information from the description below.
      If the price is in currency format (e.g., "R$ 100,00"), convert it to a number.
      
      Description: {description}
      
      {format_instructions}
    `,
    inputVariables: ["description"],
    partialVariables: {
      format_instructions: StructuredOutputParser.fromZodSchema(ProductSchema).getFormatInstructions(),
    },
  });

  // O LangChain retorna a string, mas podemos usar o parser do Zod diretamente
  // ou o parser do LangChain. Aqui usaremos o parser do LangChain para integração.
  const parser = StructuredOutputParser.fromZodSchema(ProductSchema);

  const chain = prompt.pipe(model).pipe(parser);

  try {
    // Tenta a extração direta
    const result = await chain.invoke({ description });
    return result as Product;
  } catch (error) {
    // Se falhar (ex: preço como string quebra o parser numérico do LLM),
    // podemos tentar uma abordagem de fallback ou limpeza.
    // Nota: Em produção, o ideal é que o LLM seja instruído a retornar números.
    // Mas se recebermos uma string suja:
    
    // Simulação de fallback: extrair texto bruto e limpar
    // (Em um cenário real, talvez pedir ao LLM para retornar JSON bruto e processar manualmente)
    const rawResponse = await prompt.pipe(model).invoke({ description });
    const jsonPart = JSON.parse(rawResponse.content as string); // Supondo JSON válido
    
    if (typeof jsonPart.preco === 'string') {
      jsonPart.preco = cleanPriceString(jsonPart.preco);
    }
    
    // Validação final com Zod
    return ProductSchema.parse(jsonPart);
  }
}
