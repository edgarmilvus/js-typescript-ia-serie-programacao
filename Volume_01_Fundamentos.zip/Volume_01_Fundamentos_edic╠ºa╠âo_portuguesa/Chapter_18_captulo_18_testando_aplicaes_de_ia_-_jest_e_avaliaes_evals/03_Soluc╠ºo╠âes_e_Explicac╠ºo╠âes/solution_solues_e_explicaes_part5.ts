/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part5.ts
// Description: Soluções e Explicações
// ==========================================

// vectorService.ts
import { HNSWLib } from '@langchain/community/vectorstores/hnswlib';
import { OpenAIEmbeddings } from '@langchain/openai';
import { Document } from '@langchain/core/documents';
import { v4 as uuidv4 } from 'uuid';

// Interface para documentos de entrada
interface IngestionDocument {
  content: string;
  metadata?: Record<string, any>;
}

export class VectorService {
  private vectorStore: HNSWLib | null = null;

  // Inicializa o vector store (em memória)
  async initialize() {
    // Usamos embeddings mockados ou locais. Para testes, podemos usar um mock de embeddings.
    // Aqui instanciamos real, mas em testes unitários mocks o construtor.
    const embeddings = new OpenAIEmbeddings(); 
    this.vectorStore = await HNSWLib.fromDocuments([], embeddings);
  }

  // Função de ingestão com Vector ID único
  async ingestAndSearch(docs: IngestionDocument[], query: string): Promise<Document[]> {
    if (!this.vectorStore) await this.initialize();

    // 1. Gerar UUIDs únicos para cada chunk
    const documentsWithIds = docs.map(doc => {
      const vectorId = uuidv4();
      return new Document({
        pageContent: doc.content,
        metadata: {
          ...doc.metadata,
          vectorId, // Armazenamos o ID no metadata para recuperação
        },
      });
    });

    // 2. Adicionar documentos ao store
    await this.vectorStore.addDocuments(documentsWithIds);

    // 3. Realizar busca
    const results = await this.vectorStore.similaritySearch(query, 1);
    return results;
  }

  // Função para deletar por Vector ID
  async deleteByVectorId(vectorId: string): Promise<void> {
    if (!this.vectorStore) throw new Error("Vector store not initialized");

    // O HNSWLib não suporta deleção direta por ID nativamente de forma simples sem um mapa de índices.
    // Para simular isso em uma estrutura real (como Pinecone), teríamos um método delete.
    // No HNSWLib, precisamos gerenciar os IDs manualmente ou reconstruir o índice.
    // Para o propósito do exercício, vamos simular a lógica de filtragem ou uso de um store que suporte deleção.
    
    // Abordagem de simulação: Remover o documento do store interno se possível
    // Nota: HNSWLib em memória é estático a menos que recriado. 
    // Vamos simular a deleção filtrando os metadados se a estrutura permitisse,
    // ou usando uma implementação alternativa para o teste.
    
    // Para este exercício, assumimos que temos um método `delete` disponível (comum em Pinecone, Qdrant).
    // Se estivéssemos usando Pinecone, seria: await this.vectorStore.delete({ ids: [vectorId] });
    
    // Simulação para o teste:
    // Como HNSWLib não deleta facilmente, vamos apenas retornar vazio se o ID for o alvo no teste,
    // ou manter um registro de IDs deletados lógicos (apenas para demonstração).
    console.log(`Deletando documento com ID: ${vectorId} (Simulação)`);
  }
}
