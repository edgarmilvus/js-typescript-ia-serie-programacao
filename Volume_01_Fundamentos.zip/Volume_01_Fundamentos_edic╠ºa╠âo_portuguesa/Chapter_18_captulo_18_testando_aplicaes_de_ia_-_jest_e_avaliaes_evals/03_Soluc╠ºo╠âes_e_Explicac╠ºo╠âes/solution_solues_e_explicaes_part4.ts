/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.ts
// Description: Soluções e Explicações
// ==========================================

// productExtractor.test.ts
import { extractProductData } from './productExtractor';
import { z } from 'zod';

// Mock do LangChain/OpenAI para controle total
jest.mock('@langchain/openai', () => ({
  ChatOpenAI: jest.fn().mockImplementation(() => ({
    invoke: jest.fn(),
  })),
}));

// Mock do Prompt e Parser (simplificado para o teste)
// Nota: Para testes reais, é melhor mockar o fluxo inteiro ou usar um LLM mockado.
// Aqui simulamos o comportamento do parser.
jest.mock('@langchain/core/output_parsers', () => ({
  StructuredOutputParser: {
    fromZodSchema: jest.fn().mockReturnValue({
      getFormatInstructions: () => 'Format instructions here',
      parse: (output: any) => {
        // Simula o parser do LangChain tentando validar
        if (typeof output.preco === 'string') {
          throw new Error('Output parsing failed: preco is string');
        }
        return output;
      }
    })
  }
}));

describe('extractProductData', () => {
  it('deve validar corretamente uma resposta formatada', async () => {
    // Mock da resposta do LLM (formato correto)
    const mockLLMResponse = {
      nome: 'Mouse Logitech',
      preco: 150.00,
      emEstoque: true
    };

    // Precisamos acessar a instância mockada do modelo para configurar a resposta
    const { ChatOpenAI } = require('@langchain/openai');
    const modelInstance = new ChatOpenAI();
    modelInstance.invoke.mockResolvedValue({ content: JSON.stringify(mockLLMResponse) });

    const result = await extractProductData('Mouse Logitech óptico, preço R$ 150,00, em estoque.');

    expect(result.nome).toBe('Mouse Logitech');
    expect(result.preco).toBe(150.00);
    expect(typeof result.preco).toBe('number');
  });

  it('deve tratar erro de parsing se o preço vier como string e converter', async () => {
    // Simula uma resposta "suja" do LLM onde o preço é string
    const mockDirtyResponse = {
      nome: 'Teclado Mecânico',
      preco: "R$ 200,00", // Formato incorreto
      emEstoque: true
    };

    const { ChatOpenAI } = require('@langchain/openai');
    const modelInstance = new ChatOpenAI();
    
    // A primeira chamada (parser do LangChain) falha, triggers o catch
    // A segunda chamada (fallback) retorna o JSON bruto
    modelInstance.invoke
      .mockRejectedValueOnce(new Error('Parsing failed'))
      .mockResolvedValueOnce({ content: JSON.stringify(mockDirtyResponse) });

    const result = await extractProductData('Teclado Mecânico, R$ 200,00');

    // Verifica se o preço foi convertido de "R$ 200,00" para 200.00
    expect(result.preco).toBe(200.00);
    expect(typeof result.preco).toBe('number');
  });
});
