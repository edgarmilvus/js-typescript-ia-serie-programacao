/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part10.ts
// Description: Soluções e Explicações
// ==========================================

// evaluator.ts
import * as fs from 'fs';
import * as path from 'path';

// Interface para o dataset
interface TestCase {
  context: string;
  question: string;
  groundTruth: string;
}

// Interface para a resposta gerada (mockada)
interface GeneratedResponse {
  answer: string;
}

/**
 * Função auxiliar para detectar negação.
 * Retorna true se encontrar termos de negação no início da frase.
 */
function detectNegation(text: string): boolean {
  const negationKeywords = ['não sei', 'não tenho', 'não consigo', 'não há informação', 'desconheço'];
  const lowerText = text.toLowerCase();
  return negationKeywords.some(keyword => lowerText.startsWith(keyword));
}

/**
 * Calcula uma pontuação de similaridade simples (0 a 1).
 * Aqui usamos uma lógica de sobreposição de palavras básicas para simplificar,
 * mas em produção, usaríamos cosine similarity com embeddings.
 */
function calculateSimilarity(str1: string, str2: string): number {
  const words1 = new Set(str1.toLowerCase().split(/\s+/));
  const words2 = new Set(str2.toLowerCase().split(/\s+/));
  
  const intersection = new Set([...words1].filter(x => words2.has(x)));
  const union = new Set([...words1, ...words2]);
  
  return union.size === 0 ? 0 : intersection.size / union.size;
}

/**
 * Função principal de avaliação.
 * Compara a resposta gerada com a ground truth aplicando penalidades.
 */
function evaluateAnswer(testCase: TestCase, generatedResponse: GeneratedResponse): number {
  const { groundTruth, context } = testCase;
  const { answer } = generatedResponse;

  // 1. Verificação de Negação
  // Se o contexto contém a resposta (simulação simples: se a ground truth está no contexto)
  // e a resposta do LLM contém negação, penalizamos severamente.
  const hasContextualAnswer = context.toLowerCase().includes(groundTruth.toLowerCase().split(' ')[0]); // Simples verificação
  
  if (detectNegation(answer) && hasContextualAnswer) {
    // Penalidade máxima: 0.0 (ou negativo, dependendo da métrica)
    // Neste caso, retornamos 0 imediatamente.
    return 0.0;
  }

  // 2. Cálculo de Similaridade
  const similarity = calculateSimilarity(answer, groundTruth);
  
  // Ajuste fino: se a resposta contém negação mas o contexto NÃO tem a info, a pontuação não é penalizada tanto,
  // mas o LLM está sendo honesto. Para este exercício, focamos na penalidade de alucinação (negar o presente).
  
  return similarity;
}

// Script de Execução
async function runEvaluation() {
  const datasetPath = path.join(__dirname, 'dataset.json');
  const rawData = fs.readFileSync(datasetPath, 'utf-8');
  const dataset: TestCase[] = JSON.parse(rawData);

  // Simulamos respostas do LLM (Mock)
  const mockLLMResponses: GeneratedResponse[] = [
    { answer: "Outubro de 2021." }, // Correta
    { answer: "Não tenho essa informação." }, // Alucinação (negativa incorretamente)
    { answer: "Brasília." }, // Correta
    { answer: "Sim, a água ferve a 100 graus." }, // Correta (parcialmente)
    { answer: "Não sei." }, // Alucinação (negativa incorretamente)
  ];

  let totalScore = 0;
  const maxScore = dataset.length;

  console.log('Iniciando Avaliação...\n');

  dataset.forEach((testCase, index) => {
    const response = mockLLMResponses[index];
    const score = evaluateAnswer(testCase, response);
    
    totalScore += score;
    
    console.log(`Caso ${index + 1}:`);
    console.log(`  Pergunta: ${testCase.question}`);
    console.log(`  Resposta: ${response.answer}`);
    console.log(`  Pontuação: ${score.toFixed(2)}`);
    console.log('---');
  });

  const averageScore = totalScore / maxScore;
  console.log(`\nPontuação Média de Precisão: ${(averageScore * 100).toFixed(2)}%`);
  
  // Impacto no Recall:
  // Se penalizarmos negações severamente, o recall aparente pode cair, 
  // pois respostas "não sei" são consideradas incorretas mesmo quando o modelo não tem informação.
  // No entanto, para RAG, é preferível baixa precisão a alucinações.
}

runEvaluation();
