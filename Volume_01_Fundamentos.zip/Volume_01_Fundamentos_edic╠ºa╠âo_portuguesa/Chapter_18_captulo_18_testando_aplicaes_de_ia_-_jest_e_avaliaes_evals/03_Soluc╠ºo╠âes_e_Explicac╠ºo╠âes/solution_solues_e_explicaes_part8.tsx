/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part8.tsx
// Description: Soluções e Explicações
// ==========================================

// AIChat.tsx
import React, { useState, Suspense, lazy, useEffect } from 'react';
import { useLatencyTracker } from './useLatencyTracker';

// Simula uma API lenta
const simulateAPI = (message: string): Promise<string> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(`Resposta da IA para: "${message}" - Gerada com sucesso.`);
    }, 3000); // 3 segundos de latência
  });
};

// Componente de Esqueleto (Skeleton)
const SkeletonLoader = () => (
  <div className="skeleton">
    <div className="skeleton-bar" style={{ width: '80%', height: '20px', marginBottom: '10px' }}></div>
    <div className="skeleton-bar" style={{ width: '60%', height: '20px' }}></div>
    <style jsx>{`
      .skeleton { background: #f0f0f0; padding: 10px; border-radius: 8px; }
      .skeleton-bar { background: #e0e0e0; animation: pulse 1.5s infinite; }
      @keyframes pulse { 0% { opacity: 0.6; } 50% { opacity: 1; } 100% { opacity: 0.6; } }
    `}</style>
  </div>
);

// Componente de Resposta (Lazy Loading)
const ResponseDisplay = ({ text }: { text: string }) => {
  // Simula um componente pesado
  return <div className="response-box">{text}</div>;
};

export const AIChat = () => {
  const [input, setInput] = useState('');
  const [messageHistory, setMessageHistory] = useState<Array<{ user: string; ai: string | null }>>([]);
  const { latency, startTracking, stopTracking } = useLatencyTracker();

  const handleSend = async () => {
    if (!input.trim()) return;

    // 1. Resposta Otimista: Adiciona à UI imediatamente com status "carregando"
    const optimisticId = Date.now();
    setMessageHistory((prev) => [
      ...prev,
      { user: input, ai: null }, // AI null indica carregamento
    ]);
    
    setInput('');
    startTracking();

    try {
      // Simula chamada API
      const response = await simulateAPI(input);
      stopTracking();

      // Atualiza o estado com a resposta real
      setMessageHistory((prev) =>
        prev.map((msg) =>
          msg.user === input && msg.ai === null ? { ...msg, ai: response } : msg
        )
      );
    } catch (error) {
      stopTracking();
      console.error(error);
    }
  };

  // Hook para evitar "flash" do skeleton se a requisição for muito rápida
  // (Desafio interativo)
  const [showSkeleton, setShowSkeleton] = useState(false);
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (messageHistory.some((msg) => msg.ai === null)) {
      // Só mostra o skeleton após 200ms
      timer = setTimeout(() => setShowSkeleton(true), 200);
    } else {
      setShowSkeleton(false);
    }
    return () => clearTimeout(timer);
  }, [messageHistory]);

  return (
    <div className="chat-container">
      <div className="chat-log">
        {messageHistory.map((msg, idx) => (
          <div key={idx} className="message-row">
            <div className="user-msg"><strong>Você:</strong> {msg.user}</div>
            <div className="ai-msg">
              {msg.ai === null ? (
                // Condiciona a exibição do skeleton baseado no timer
                showSkeleton ? <SkeletonLoader /> : <span>...</span>
              ) : (
                <Suspense fallback={<SkeletonLoader />}>
                  <ResponseDisplay text={msg.ai} />
                </Suspense>
              )}
            </div>
          </div>
        ))}
      </div>
      
      <div className="input-area">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Pergunte algo..."
        />
        <button onClick={handleSend}>Enviar</button>
      </div>

      {/* Métrica de Latência (Apenas Dev) */}
      {latency !== null && (
        <div className="metrics">
          Latência: {latency}ms
        </div>
      )}
    </div>
  );
};
