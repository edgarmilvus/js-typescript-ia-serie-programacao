/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.ts
// Description: Exemplo de Código Básico
// ==========================================

/**
 * ------------------------------------------------------------------
 * 1. DEFINIÇÃO DE TIPOS E INTERFACES
 * ------------------------------------------------------------------
 * Definimos estruturas de dados claras para garantir tipagem segura
 * e evitar erros em tempo de execução (runtime errors).
 */

// Representa a entrada do usuário ou do sistema.
interface UserRequest {
  id: string;
  content: string;
}

// Enumera os possíveis agentes especializados (Worker Agents).
// Isso evita erros de digitação e torna o código mais legível.
enum AgentType {
  BILLING = 'billing_agent',
  TECHNICAL = 'technical_agent',
  GENERAL = 'general_agent',
}

// Interface que define o contrato de um agente especializado.
// Cada worker deve ser capaz de processar uma requisição e retornar uma resposta.
interface WorkerAgent {
  type: AgentType;
  process(request: UserRequest): Promise<string>;
}

// Interface para o Supervisor Node.
interface Supervisor {
  decideAgent(request: UserRequest): AgentType;
  delegate(request: UserRequest, agentType: AgentType): Promise<string>;
}

/**
 * ------------------------------------------------------------------
 * 2. IMPLEMENTAÇÃO DOS WORKER AGENTS (Especialistas)
 * ------------------------------------------------------------------
 * Cada classe abaixo representa um agente de propósito único.
 * Em um cenário real, esses agentes poderiam fazer chamadas à API da OpenAI,
 * consultar um banco de dados ou executar cálculos complexos.
 */

class BillingAgent implements WorkerAgent {
  type: AgentType = AgentType.BILLING;

  async process(request: UserRequest): Promise<string> {
    // Simula processamento de lógica de negócios (ex: consulta a fatura)
    console.log(`[BillingAgent] Processando fatura para ID: ${request.id}`);
    return `Relatório Financeiro: O valor devido para o pedido ${request.id} é R$ 150,00. Pagamento pendente.`;
  }
}

class TechnicalAgent implements WorkerAgent {
  type: AgentType = AgentType.TECHNICAL;

  async process(request: UserRequest): Promise<string> {
    // Simula processamento técnico (ex: consulta de logs, debug)
    console.log(`[TechnicalAgent] Analisando logs para ID: ${request.id}`);
    return `Relatório Técnico: Erro detectado no servidor 'us-east-1'. Reinicialização recomendada para o pedido ${request.id}.`;
  }
}

class GeneralAgent implements WorkerAgent {
  type: AgentType = AgentType.GENERAL;

  async process(request: UserRequest): Promise<string> {
    // Simula processamento genérico (ex: FAQ, saudações)
    console.log(`[GeneralAgent] Respondendo consulta geral para ID: ${request.id}`);
    return `Olá! Recebemos sua solicitação (${request.id}). Um de nossos especialistas entrará em contato em breve.`;
  }
}

/**
 * ------------------------------------------------------------------
 * 3. IMPLEMENTAÇÃO DO SUPERVISOR NODE
 * ------------------------------------------------------------------
 * O Supervisor atua como um roteador de tráfego. Ele não processa a tarefa
 * pesada, mas sim decide quem deve fazê-lo.
 */

class SupervisorNode implements Supervisor {
  private agents: Map<AgentType, WorkerAgent>;

  constructor(agents: WorkerAgent[]) {
    this.agents = new Map();
    agents.forEach((agent) => this.agents.set(agent.type, agent));
  }

  /**
   * Lógica de roteamento baseada em "Regras de Negócio" (Simples).
   * Em aplicações de IA real, esta função seria substituída por um LLM
   * que analisa o texto e retorna o tipo de agente.
   */
  decideAgent(request: UserRequest): AgentType {
    const content = request.content.toLowerCase();

    if (content.includes('fatura') || content.includes('pagamento') || content.includes('cartão')) {
      return AgentType.BILLING;
    }
    if (content.includes('erro') || content.includes('bug') || content.includes('lento')) {
      return AgentType.TECHNICAL;
    }
    
    // Fallback padrão
    return AgentType.GENERAL;
  }

  /**
   * Delega a tarefa ao agente especializado e retorna o resultado.
   * Esta função encapsula a chamada do worker.
   */
  async delegate(request: UserRequest, agentType: AgentType): Promise<string> {
    const agent = this.agents.get(agentType);
    
    if (!agent) {
      throw new Error(`Agente do tipo '${agentType}' não foi encontrado.`);
    }

    // Simula a execução do agente (pode ser assíncrono)
    const result = await agent.process(request);
    return result;
  }
}

/**
 * ------------------------------------------------------------------
 * 4. ORQUESTRAÇÃO DO FLUXO (MAIN EXECUTION)
 * ------------------------------------------------------------------
 * Simula uma requisição chegando via API HTTP (ex: Next.js Route Handler).
 */

// Mock de dados de entrada (simula um JSON recebido do frontend)
const incomingRequests: UserRequest[] = [
  { id: 'REQ-001', content: 'Não consigo visualizar minha fatura do último mês.' },
  { id: 'REQ-002', content: 'O sistema está muito lento ao carregar o dashboard.' },
  { id: 'REQ-003', content: 'Como resetar minha senha?' },
];

// Inicialização dos Agentes
const agents: WorkerAgent[] = [
  new BillingAgent(),
  new TechnicalAgent(),
  new GeneralAgent(),
];

// Inicialização do Supervisor
const supervisor = new SupervisorNode(agents);

// Função principal para processar o lote de requisições
async function processSupportQueue() {
  console.log('--- Iniciando Orquestração de Agentes ---\n');

  for (const req of incomingRequests) {
    try {
      // 1. Supervisor analisa a requisição
      const agentType = supervisor.decideAgent(req);
      console.log(`[Supervisor] Requisição '${req.id}' direcionada para: ${agentType}`);

      // 2. Supervisor delega a execução
      const result = await supervisor.delegate(req, agentType);

      // 3. Resultado final (poderia ser salvo no banco de dados ou enviado ao usuário)
      console.log(`[Resultado Final] ID: ${req.id} | Resposta: ${result}\n`);
    } catch (error) {
      console.error(`[Erro] Falha ao processar ${req.id}:`, error);
    }
  }
}

// Executa a simulação
processSupportQueue();
