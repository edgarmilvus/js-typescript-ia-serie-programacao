/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.ts
// Description: Script de Aplicação Avançada
// ==========================================

/**
 * ARQUIVO: app/api/feedback/evals.test.ts
 * DESCRIÇÃO: Script de teste avançado para validar o classificador de feedback.
 * FOCO: Combinação de Jest, LangGraph e Evals quantitativos/qualitativos.
 */

import { StateGraph, END, State } from '@langchain/langgraph';
import { z } from 'zod';

// ==========================================
// 1. DEFINIÇÃO DE TIPOS E GENERICS (TypeScript)
// ==========================================

/**
 * @description Interface Genérica para garantir a segurança de tipos nas operações de IA.
 * O uso de <T> permite que o schema de saída seja dinâmico, mas sempre validado.
 */
interface IAOperation<T> {
  input: string;
  outputSchema: z.ZodSchema<T>;
}

// Schema de validação Zod para a resposta da IA (Garante a estrutura do JSON)
const ClassificationSchema = z.object({
  intent: z.enum(['bug', 'feature', 'support']),
  confidence: z.number().min(0).max(1),
  summary: z.string(),
});

type Classification = z.infer<typeof ClassificationSchema>;

// ==========================================
// 2. LÓGICA DA APLICAÇÃO (LangGraph)
// ==========================================

/**
 * @description Estado compartilhado do grafo de classificação.
 * Contém o feedback bruto e o resultado processado.
 */
interface GraphState {
  feedback: string;
  sentiment?: 'positive' | 'negative' | 'neutral';
  classification?: Classification;
}

/**
 * @description Simula a chamada à OpenAI API para analisar o sentimento.
 * Em produção, aqui estaria o `chat.invoke()`.
 */
const analyzeSentiment = async (state: GraphState): Promise<GraphState> => {
  // Mock simples para fins de demonstração do script de teste
  const isNegative = state.feedback.toLowerCase().includes('erro') || state.feedback.toLowerCase().includes('lento');
  return {
    ...state,
    sentiment: isNegative ? 'negative' : 'positive',
  };
};

/**
 * @description Simula a chamada à OpenAI API para classificar a intenção.
 * Aplica a lógica de prompt baseada no sentimento analisado.
 */
const classifyIntent = async (state: GraphState): Promise<GraphState> => {
  // Lógica condicional baseada no fluxo do Grafo
  let intent: 'bug' | 'feature' | 'support' = 'support';
  
  if (state.feedback.toLowerCase().includes('bug') || state.sentiment === 'negative') {
    intent = 'bug';
  } else if (state.feedback.toLowerCase().includes('adicionar') || state.feedback.toLowerCase().includes('novo')) {
    intent = 'feature';
  }

  // Simulando a saída estruturada da IA
  const result: Classification = {
    intent,
    confidence: 0.95,
    summary: `Feedback classificado como ${intent} baseado no sentimento ${state.sentiment}`,
  };

  return {
    ...state,
    classification: result,
  };
};

/**
 * @description Construção do Grafo de Estado (StateGraph).
 * Define os nós (computação) e arestas (transições).
 */
const buildClassifierGraph = () => {
  const workflow = new StateGraph<GraphState>({
    channels: {
      feedback: { value: (x, y) => (y ?? x), default: () => '' },
      sentiment: { value: (x, y) => (y ?? x) },
      classification: { value: (x, y) => (y ?? x) },
    },
  });

  workflow.addNode('analyze_sentiment', analyzeSentiment);
  workflow.addNode('classify_intent', classifyIntent);

  // Fluxo: Análise -> Classificação -> Fim
  workflow.addEdge('analyze_sentiment', 'classify_intent');
  workflow.addEdge('classify_intent', END);
  
  workflow.setEntryPoint('analyze_sentiment');

  return workflow.compile();
};

// ==========================================
// 3. MÓDULO DE EVALS (Jest)
// ==========================================

/**
 * @description Conjunto de dados de teste (Evals Dataset).
 * Cada item representa um caso real que o SaaS deve lidar.
 */
const EVAL_DATASET = [
  { input: 'O sistema está com bug de login, não consigo acessar.', expected: 'bug' },
  { input: 'Adicionar suporte a PDF seria ótimo para meu fluxo.', expected: 'feature' },
  { input: 'Preciso de ajuda para resetar minha senha.', expected: 'support' },
  { input: 'Está muito lento e trava constantemente.', expected: 'bug' }, // Teste de borda (sentimento negativo sem palavra chave)
];

/**
 * @description Função utilitária para executar o grafo e validar a saída.
 * Esta função encapsula a lógica de "Prompt Isolation" mencionada no capítulo.
 */
async function runEvaluation(feedback: string): Promise<Classification> {
  const graph = buildClassifierGraph();
  const result = await graph.invoke({ feedback });
  
  if (!result.classification) {
    throw new Error('Falha na classificação: Output vazio.');
  }

  // Validação qualitativa: Garantir que o formato é correto (Zod)
  return ClassificationSchema.parse(result.classification);
}

/**
 * @description Suite de Testes Jest.
 * Aqui aplicamos as métricas quantitativas e qualitativas.
 */
describe('Sistema de Classificação de Feedback (Evals)', () => {
  
  // TESTE 1: Precisão Quantitativa (Accuracy Metric)
  test('Deve atingir precisão acima de 80% no dataset de validação', async () => {
    let correctPredictions = 0;

    for (const item of EVAL_DATASET) {
      try {
        const result = await runEvaluation(item.input);
        if (result.intent === item.expected) {
          correctPredictions++;
        }
      } catch (error) {
        // Se houver erro de validação Zod, conta como falha
        console.error(`Falha no item: ${item.input}`, error);
      }
    }

    const accuracy = correctPredictions / EVAL_DATASET.length;
    
    // Assegura que o modelo não degradou
    expect(accuracy).toBeGreaterThanOrEqual(0.80);
  });

  // TESTE 2: Robustez e Validação de Schema (Qualitativo)
  test('Deve retornar JSON válido com confiança para inputs maliciosos ou vazios', async () => {
    const graph = buildClassifierGraph();
    
    // Teste de input vazio
    const emptyResult = await graph.invoke({ feedback: '' });
    expect(emptyResult.classification).toBeDefined();
    
    // Teste de input ruidoso
    const noiseResult = await runEvaluation('!!!@#$%^&*()');
    expect(noiseResult).toHaveProperty('confidence');
    expect(typeof noiseResult.confidence).toBe('number');
  });

  // TESTE 3: Integração com LangGraph (Fluxo de Estado)
  test('Deve preservar o estado do sentimento entre os nós do grafo', async () => {
    const graph = buildClassifierGraph();
    const result = await graph.invoke({ feedback: 'Erro crítico no servidor' });

    // Verifica se o nó de análise de sentimento foi executado antes da classificação
    expect(result.sentiment).toBe('negative');
    // Verifica se a classificação usou essa informação
    expect(result.classification?.intent).toBe('bug');
  });
});
