/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_exerccios_prticos_part6.tsx
// Description: Exercícios Práticos
// ==========================================

// Arquivo: src/components/DiagnosticsDashboard.tsx
import React, { useEffect, useState } from 'react';
import { detectHardwareCapabilities, HardwareCapabilities } from '../utils/hardwareDetector';

export const DiagnosticsDashboard: React.FC = () => {
    const [caps, setCaps] = useState<HardwareCapabilities | null>(null);
    
    useEffect(() => {
        detectHardwareCapabilities().then(setCaps);
    }, []);

    if (!caps) return <div>Diagnosticando hardware...</div>;

    return (
        <div style={{ border: '1px solid #ccc', padding: '10px' }}>
            <h3>Diagnóstico de Hardware</h3>
            <p>WebGPU: {caps.webgpu ? '✅ Suportado' : '❌ Não Suportado'}</p>
            <p>Memória: {caps.deviceMemory} GB</p>
            <p>Backend Preferido: {caps.backend}</p>
            {/* TODO: Adicionar botão para forçar backend manualmente */}
        </div>
    );
};
