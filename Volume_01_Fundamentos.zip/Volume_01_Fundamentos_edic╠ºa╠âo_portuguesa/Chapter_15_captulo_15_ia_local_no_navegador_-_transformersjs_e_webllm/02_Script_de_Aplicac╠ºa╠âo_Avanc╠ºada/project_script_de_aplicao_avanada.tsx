/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.tsx
// Description: Script de Aplicação Avançada
// ==========================================

/**
 * @fileoverview Componente de Classificação de Sentimento Zero-Shot Local.
 * Utiliza Transformers.js para inferência client-side com WebGPU/Wasm.
 * Arquitetura: Next.js (App Router) + React Hooks + Transformers.js
 */

import React, { useState, useRef, useEffect } from 'react';

// --- Tipagem e Interfaces ---

interface Score {
  label: string;
  score: number;
}

interface InferenceState {
  status: 'idle' | 'loading' | 'ready' | 'classifying' | 'error';
  results: Score[] | null;
  progress: number;
  logs: string[];
}

// --- Constantes de Configuração ---

const MODEL_ID = 'Xenova/bert-base-uncased-mnli'; // Modelo leve para Zero-Shot
const CANDIDATE_LABELS = ['positivo', 'negativo', 'neutro'];

// --- Componente Principal ---

/**
 * Componente que encapsula a lógica de IA Local.
 * Otimizado para Next.js Server Components (usa 'use client' para interatividade).
 */
export default function LocalSentimentAnalyzer() {
  // Estado da aplicação
  const [state, setState] = useState<InferenceState>({
    status: 'idle',
    results: null,
    progress: 0,
    logs: ['Aguardando inicialização...'],
  });

  // Referência para o objeto do pipeline de IA (para evitar recargas desnecessárias)
  const classifierRef = useRef<any>(null);

  // --- Lógica de Inicialização do Modelo ---

  /**
   * Carrega o pipeline de classificação do Transformers.js.
   * Otimiza o carregamento usando cache de navegador e WebGPU se disponível.
   */
  const loadModel = async () => {
    setState((prev) => ({
      ...prev,
      status: 'loading',
      logs: [...prev.logs, 'Iniciando download do modelo (Isso pode levar alguns segundos)...'],
    }));

    try {
      // Dynamically import Transformers.js para manter o bundle do Next.js leve inicialmente
      const { pipeline } = await import('@xenova/transformers');

      // Configura o pipeline para Zero-Shot Classification
      // 'quantized: true' usa modelos otimizados (8-bit) para download mais rápido e menor uso de memória
      classifierRef.current = await pipeline(
        'zero-shot-classification',
        MODEL_ID,
        {
          quantized: true,
          progress_callback: (data: any) => {
            // Atualiza barra de progresso visual durante o download
            setState((prev) => ({
              ...prev,
              progress: data.progress || 0,
            }));
          },
        }
      );

      setState((prev) => ({
        ...prev,
        status: 'ready',
        logs: [...prev.logs, 'Modelo carregado com sucesso! WebGPU/Wasm pronto.'],
        progress: 100,
      }));
    } catch (error) {
      console.error(error);
      setState((prev) => ({
        ...prev,
        status: 'error',
        logs: [...prev.logs, `Erro ao carregar modelo: ${error}`],
      }));
    }
  };

  // --- Lógica de Inferência (Classificação) ---

  /**
   * Executa a classificação do texto inserido pelo usuário.
   * @param {string} text - O texto a ser analisado.
   */
  const classifyText = async (text: string) => {
    if (!classifierRef.current || !text.trim()) return;

    setState((prev) => ({
      ...prev,
      status: 'classifying',
      logs: [...prev.logs, `Processando: "${text.substring(0, 30)}..."`],
      results: null,
    }));

    try {
      // Execução da inferência local (tudo acontece no thread principal ou web worker via Wasm)
      const result = await classifierRef.current(text, CANDIDATE_LABELS, {
        // Opção para multi-label (permite múltiplas classificações se aplicável)
        multi_label: false, 
      });

      // Mapeia o resultado para o formato de exibição
      const formattedResults: Score[] = result.labels.map((label: string, idx: number) => ({
        label: label.charAt(0).toUpperCase() + label.slice(1), // Capitaliza
        score: result.scores[idx],
      }));

      setState((prev) => ({
        ...prev,
        status: 'ready',
        results: formattedResults,
        logs: [...prev.logs, 'Classificação concluída.'],
      }));
    } catch (error) {
      setState((prev) => ({
        ...prev,
        status: 'error',
        logs: [...prev.logs, `Erro na inferência: ${error}`],
      }));
    }
  };

  // Hook para inicialização automática ao montar o componente (opcional, pode ser via botão)
  useEffect(() => {
    // Pré-carrega o modelo suavemente se o usuário interagir, ou em background
    // Aqui deixamos explícito via botão para controle de banda e UX
  }, []);

  // --- Renderização da Interface ---

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-xl shadow-lg border border-gray-200 font-sans">
      <header className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Sentimento AI - Local</h1>
        <p className="text-sm text-gray-500 mt-1">
          Processamento 100% no navegador. Sem envio de dados para servidores.
        </p>
      </header>

      {/* Seção de Controle e Status */}
      <div className="space-y-4 mb-8">
        {state.status === 'idle' && (
          <button
            onClick={loadModel}
            className="w-full py-3 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-semibold"
          >
            Inicializar Motor de IA (Download Modelo)
          </button>
        )}

        {state.status === 'loading' && (
          <div className="w-full bg-gray-200 rounded-full h-4 overflow-hidden">
            <div 
              className="bg-blue-500 h-4 transition-all duration-300" 
              style={{ width: `${state.progress}%` }}
            ></div>
          </div>
        )}

        {state.status === 'ready' && (
          <div className="flex items-center gap-2 text-green-600 font-medium">
            <span className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></span>
            Modelo Pronto (WebGPU/Wasm)
          </div>
        )}
      </div>

      {/* Área de Input (Habilitada apenas quando o modelo está pronto) */}
      {state.status !== 'idle' && state.status !== 'loading' && (
        <div className="space-y-4">
          <textarea
            className="w-full p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition resize-none"
            rows={4}
            placeholder="Digite um feedback de cliente aqui (ex: 'O produto é ótimo, mas a entrega demorou.')..."
            disabled={state.status === 'classifying'}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                classifyText((e.target as HTMLTextAreaElement).value);
              }
            }}
          />
          <button
            onClick={() => {
              const textarea = document.querySelector('textarea');
              if (textarea) classifyText(textarea.value);
            }}
            disabled={state.status === 'classifying'}
            className={`w-full py-2 px-4 rounded-lg font-semibold transition ${
              state.status === 'classifying'
                ? 'bg-gray-400 cursor-not-allowed text-gray-200'
                : 'bg-gray-800 text-white hover:bg-gray-900'
            }`}
          >
            {state.status === 'classifying' ? 'Analisando...' : 'Classificar Sentimento'}
          </button>
        </div>
      )}

      {/* Exibição de Resultados */}
      {state.results && (
        <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-700 mb-3">Resultado da Análise</h3>
          <div className="space-y-3">
            {state.results.map((item, idx) => (
              <div key={idx} className="flex items-center gap-3">
                <span className="w-20 text-sm font-medium text-gray-600">{item.label}</span>
                <div className="flex-1 bg-gray-200 rounded-full h-2 overflow-hidden">
                  <div
                    className={`h-2 ${
                      item.label === 'Positivo'
                        ? 'bg-green-500'
                        : item.label === 'Negativo'
                        ? 'bg-red-500'
                        : 'bg-gray-500'
                    }`}
                    style={{ width: `${(item.score * 100).toFixed(0)}%` }}
                  ></div>
                </div>
                <span className="w-12 text-sm text-right font-mono">
                  {(item.score * 100).toFixed(0)}%
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Log de Sistema (Debug/UX) */}
      <div className="mt-6 text-xs font-mono text-gray-400 bg-black p-3 rounded-lg h-24 overflow-y-auto">
        {state.logs.map((log, i) => (
          <div key={i}>[{new Date().toLocaleTimeString()}] {log}</div>
        ))}
      </div>
    </div>
  );
}
