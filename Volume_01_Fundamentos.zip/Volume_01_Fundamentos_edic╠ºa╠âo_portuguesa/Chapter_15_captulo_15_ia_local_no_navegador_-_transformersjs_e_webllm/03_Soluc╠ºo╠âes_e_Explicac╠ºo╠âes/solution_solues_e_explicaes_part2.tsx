/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part2.tsx
// Description: Soluções e Explicações
// ==========================================

// Arquivo: src/components/LocalChatUI.tsx
import React, { useState, useRef, useEffect } from 'react';
// Supondo a importação do pacote web-llm via CDN ou bundler
import * as webllm from "@mlc-ai/web-llm";

export const LocalChatUI: React.FC = () => {
    const [messages, setMessages] = useState<Array<{role: string, content: string}>>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    
    // Referência para manter a instância do engine fora do ciclo de renderização
    const engineRef = useRef<webllm.MLCEngine | null>(null);

    // Inicialização do modelo
    const initChat = async () => {
        if (engineRef.current) return; // Já inicializado

        const initProgressCallback = (report: { progress: number }) => {
            console.log(`Initializing: ${report.progress * 100}%`);
            setIsLoading(true);
        };

        // Escolha um modelo leve compatível com WebGPU
        const modelId = "Phi-3-mini-4k-instruct-q4f16_1-MLC"; 

        try {
            const engine = new webllm.MLCEngine();
            engine.setInitProgressCallback(initProgressCallback);
            
            await engine.reload(modelId);
            
            // Configuração para usar WebGPU se disponível, senão fallback
            // O WebLLM geralmente tenta WebGPU por padrão se disponível
            engineRef.current = engine;
            setIsLoading(false);
        } catch (err) {
            console.error("Erro ao inicializar WebLLM:", err);
            setIsLoading(false);
        }
    };

    // Limpeza de memória ao desmontar o componente
    useEffect(() => {
        return () => {
            if (engineRef.current) {
                engineRef.current.unload(); // Libera a memória da GPU/CPU
                engineRef.current = null;
            }
        };
    }, []);

    const handleSendMessage = async () => {
        if (!input.trim() || !engineRef.current) return;

        const userMessage = { role: 'user', content: input };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        // Adiciona espaço para a resposta do assistente
        setMessages(prev => [...prev, { role: 'assistant', content: '' }]);

        try {
            const reply = await engineRef.current.chat.completions.create({
                stream: true, // Habilita o streaming
                messages: [...messages, userMessage],
            });

            let fullContent = "";
            const lastIndex = messages.length; // Índice da mensagem assistente atual

            // Streaming token a token
            for await (const chunk of reply) {
                const delta = chunk.choices[0].delta.content;
                if (delta) {
                    fullContent += delta;
                    // Atualiza o estado otimisticamente para o efeito typewriter
                    setMessages(prev => {
                        const newMessages = [...prev];
                        newMessages[lastIndex].content = fullContent;
                        return newMessages;
                    });
                }
            }
        } catch (err) {
            console.error("Erro na geração:", err);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div style={{ padding: '20px', border: '1px solid #ddd' }}>
            <div style={{ height: '300px', overflowY: 'scroll', marginBottom: '10px', border: '1px solid #eee' }}>
                {messages.map((msg, idx) => (
                    <div key={idx} style={{ textAlign: msg.role === 'user' ? 'right' : 'left', margin: '5px' }}>
                        <strong>{msg.role.toUpperCase()}:</strong> {msg.content}
                    </div>
                ))}
                {isLoading && <div>Digitando...</div>}
            </div>
            <div style={{ display: 'flex', gap: '10px' }}>
                <input 
                    type="text" 
                    value={input} 
                    onChange={(e) => setInput(e.target.value)} 
                    disabled={isLoading}
                    placeholder="Digite sua mensagem..."
                    style={{ flex: 1 }}
                />
                <button onClick={handleSendMessage} disabled={isLoading || !engineRef.current}>
                    {isLoading ? 'Processando...' : 'Enviar'}
                </button>
            </div>
            <button onClick={initChat} disabled={!!engineRef.current} style={{ marginTop: '10px' }}>
                Inicializar Motor Local (WebGPU)
            </button>
        </div>
    );
};
