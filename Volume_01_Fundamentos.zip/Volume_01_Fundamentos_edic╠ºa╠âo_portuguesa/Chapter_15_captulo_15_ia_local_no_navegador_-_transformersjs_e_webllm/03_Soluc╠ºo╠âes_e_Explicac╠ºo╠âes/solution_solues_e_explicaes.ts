/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.ts
// Description: Soluções e Explicações
// ==========================================

// Arquivo: src/hooks/useModelLoader.ts
import { useState, useEffect, useCallback } from 'react';

// Importação dinâmica típica do Transformers.js (assumindo a estrutura de módulos)
// Nota: Em um projeto real, você pode precisar configurar o bundler para lidar com módulos ES ou UMD.
import { pipeline, env, PipelineType } from '@xenova/transformers';

// Configuração do ambiente para rodar no navegador com WebAssembly
env.allowLocalModels = false;
env.allowRemoteModels = true;
env.useBrowserCache = true;

type ModelStatus = 'idle' | 'loading' | 'ready' | 'error';

export const useModelLoader = (modelId: string) => {
    const [status, setStatus] = useState<ModelStatus>('idle');
    const [classifier, setClassifier] = useState<any>(null);
    const [error, setError] = useState<string | null>(null);

    // Função de aquecimento (Warm-up) para otimizar a primeira inferência
    const warmUp = useCallback(async (pipelineInstance: any) => {
        if (!pipelineInstance) return;
        
        setStatus('loading');
        try {
            // Envia um texto vazio ou curto para inicializar o tokenizer e o modelo na memória
            await pipelineInstance('Apenas um teste rápido para aquecer.');
            setStatus('ready');
        } catch (err) {
            console.error("Erro no warm-up:", err);
            setStatus('error');
            setError("Falha ao inicializar o modelo.");
        }
    }, []);

    useEffect(() => {
        let isMounted = true;

        const loadModel = async () => {
            if (status !== 'idle') return;
            
            setStatus('loading');
            try {
                // Inicializa o pipeline de classificação de sentimentos
                // O 'pipeline' retorna uma Promise
                const pipe = await pipeline('sentiment-analysis', modelId);
                
                if (isMounted) {
                    setClassifier(() => pipe);
                    // Dispara o warm-up após o carregamento dos pesos
                    await warmUp(pipe);
                }
            } catch (err) {
                if (isMounted) {
                    console.error("Erro ao carregar modelo:", err);
                    setStatus('error');
                    setError("Não foi possível carregar o modelo da Hugging Face.");
                }
            }
        };

        loadModel();

        return () => {
            isMounted = false;
        };
    }, [modelId, status, warmUp]);

    return { status, classifier, error, warmUp };
};
