/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.ts
// Description: Soluções e Explicações
// ==========================================

digraph G {
    rankdir=LR;
    node [shape=box, style="rounded,filled", color="#3498db", fontname="Arial"];
    
    Start [label="Início / Entrada", fillcolor="#e1f5fe"];
    CheckpointLoad [label="Verificar Checkpoint\n(LocalStorage)", fillcolor="#fff3e0"];
    
    subgraph cluster_graph {
        label="LangGraph Execution";
        style="dashed";
        node [color="#2ecc71"];
        
        Node1 [label="Processar Entrada\n(LLM Local)"];
        Node2 [label="Verificar Ferramentas"];
        Node3 [label="Tomar Decisão"];
        
        Node1 -> Node2;
        Node2 -> Node3;
    }

    Decision [label="Necessita\nLoop?", shape=diamond, fillcolor="#f8c471"];
    SaveState [label="Salvar Estado\n(Checkpoint)", fillcolor="#d5f4e6"];
    End [label="Saída Final", fillcolor="#e8f5e8"];

    Start -> CheckpointLoad;
    CheckpointLoad -> Node1 [label="Se existe"];
    CheckpointLoad -> Node1 [label="Novo"];
    
    Node3 -> Decision;
    Decision -> Node1 [label="Sim"];
    Decision -> SaveState [label="Não"];
    
    SaveState -> End;
}
