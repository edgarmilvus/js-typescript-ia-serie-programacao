/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.tsx
// Description: Exemplo de Código Básico
// ==========================================

// Arquivo: src/components/ZeroShotClassifier.tsx
// Dependências necessárias: @xenova/transformers (via npm ou CDN script)
// Para este exemplo, assumimos o uso de um ambiente React com TypeScript.

import React, { useState, useRef, useEffect } from 'react';

// Tipagem estrita para os resultados do modelo
interface ClassificationResult {
    label: string;
    score: number;
}

// Interface para o objeto do pipeline (simplificada para evitar declarações complexas de tipos)
interface Pipeline {
    (text: string, candidate_labels: string[]): Promise<ClassificationResult[]>;
}

/**
 * Componente ZeroShotClassifier
 * Demonstração de classificação de texto local no navegador usando Transformers.js
 */
export const ZeroShotClassifier: React.FC = () => {
    // Estado para armazenar a frase de entrada
    const [inputText, setInputText] = useState<string>("");
    
    // Estado para as categorias (separadas por vírgula na UI)
    const [categories, setCategories] = useState<string>("Sentimento Positivo, Tecnologia, Esportes");
    
    // Estado para os resultados da classificação
    const [results, setResults] = useState<ClassificationResult[] | null>(null);
    
    // Estado para controle de carregamento e erros
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [status, setStatus] = useState<string>("Aguardando entrada...");

    // Referência para armazenar o pipeline do modelo (para evitar recarregar a cada render)
    const pipelineRef = useRef<any>(null);

    // Efeito para inicializar o pipeline do modelo (Warm Start)
    useEffect(() => {
        const loadModel = async () => {
            try {
                setStatus("Carregando modelo local (isso pode levar alguns segundos)...");

                // Verifica se a biblioteca está disponível (assumindo CDN script ou npm import)
                // @ts-ignore: A biblioteca é carregada globalmente ou via import dinâmico
                if (window.transformers) {
                    // Inicializa o pipeline de classificação zero-shot
                    // 'Xenova/mbart-large-mnli' é otimizado para tarefas NLI (Natural Language Inference)
                    pipelineRef.current = await window.transformers.pipeline(
                        'zero-shot-classification',
                        'Xenova/mbart-large-mnli',
                        {
                            quantized: true, // Usa versão quantizada para menor tamanho e velocidade
                            progress_callback: (data: any) => {
                                // Exibe progresso do download (opcional)
                                if (data.status === 'progress') {
                                    setStatus(`Baixando pesos: ${data.progress}%`);
                                }
                            }
                        }
                    );
                    setStatus("Modelo pronto! Insira o texto.");
                } else {
                    setStatus("Erro: Biblioteca Transformers.js não encontrada.");
                }
            } catch (error) {
                console.error(error);
                setStatus("Erro ao carregar o modelo. Verifique a conexão.");
            }
        };

        loadModel();
    }, []);

    /**
     * Função principal de classificação
     * Acionada pelo botão "Classificar"
     */
    const classifyText = async () => {
        if (!pipelineRef.current || !inputText.trim()) return;

        setIsLoading(true);
        setStatus("Processando inferência local...");
        setResults(null);

        try {
            // Divide as categorias inseridas pelo usuário (vírgula como separador)
            const candidateLabels = categories.split(',').map(c => c.trim()).filter(c => c);

            // Executa a inferência NO NAVEGADOR
            // O modelo analisa a compatabilidade semântica entre o texto e cada label
            const output = await pipelineRef.current(inputText, candidateLabels);

            // Atualiza o estado com os resultados
            setResults(output);
            setStatus("Classificação concluída.");
        } catch (error) {
            console.error("Erro na inferência:", error);
            setStatus("Erro durante a classificação.");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div style={{ padding: '20px', fontFamily: 'sans-serif', maxWidth: '600px', margin: '0 auto' }}>
            <h2>Classificador Zero-Shot Local</h2>
            <p style={{ fontSize: '0.9em', color: '#555' }}>
                Modelo: <code>mbart-large-mnli</code> (Executando via WebAssembly)
            </p>

            {/* Seção de Entrada */}
            <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                    Texto para analisar:
                </label>
                <textarea
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="Ex: O novo processador é extremamente rápido."
                    rows={3}
                    style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
                />
            </div>

            <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                    Categorias (separadas por vírgula):
                </label>
                <input
                    type="text"
                    value={categories}
                    onChange={(e) => setCategories(e.target.value)}
                    style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
                />
            </div>

            <button
                onClick={classifyText}
                disabled={isLoading || !pipelineRef.current}
                style={{
                    padding: '10px 20px',
                    backgroundColor: isLoading || !pipelineRef.current ? '#ccc' : '#007bff',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: isLoading || !pipelineRef.current ? 'not-allowed' : 'pointer'
                }}
            >
                {isLoading ? 'Processando...' : 'Classificar Localmente'}
            </button>

            {/* Status e Resultados */}
            <div style={{ marginTop: '20px', padding: '10px', backgroundColor: '#f9f9f9', borderRadius: '4px' }}>
                <p><strong>Status:</strong> {status}</p>
            </div>

            {results && (
                <div style={{ marginTop: '20px' }}>
                    <h3>Resultados:</h3>
                    <ul style={{ listStyle: 'none', padding: 0 }}>
                        {results.map((res, index) => (
                            <li key={index} style={{
                                marginBottom: '8px',
                                padding: '8px',
                                backgroundColor: '#eef',
                                borderRadius: '4px',
                                borderLeft: `5px solid ${res.score > 0.5 ? '#28a745' : '#ffc107'}`
                            }}>
                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <span><strong>{res.label}</strong></span>
                                    <span>{(res.score * 100).toFixed(2)}%</span>
                                </div>
                                {/* Barra de progresso visual */}
                                <div style={{ 
                                    height: '4px', 
                                    backgroundColor: '#ddd', 
                                    marginTop: '4px', 
                                    borderRadius: '2px',
                                    overflow: 'hidden'
                                }}>
                                    <div style={{ 
                                        width: `${res.score * 100}%`, 
                                        height: '100%', 
                                        backgroundColor: '#007bff' 
                                    }}></div>
                                </div>
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};
