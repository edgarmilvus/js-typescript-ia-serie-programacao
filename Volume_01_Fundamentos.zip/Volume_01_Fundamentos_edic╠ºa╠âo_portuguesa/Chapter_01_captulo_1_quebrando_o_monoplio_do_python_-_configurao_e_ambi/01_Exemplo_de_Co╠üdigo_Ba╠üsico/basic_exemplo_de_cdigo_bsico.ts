/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.ts
// Description: Exemplo de Código Básico
// ==========================================

/**
 * @fileoverview "Hello World" de IA com Node.js e LangChain.
 * Este script simula uma função de backend (Serverless Function) que processa
 * uma lista de tarefas e retorna um resumo executivo gerado por IA.
 * 
 * Pré-requisitos:
 * 1. Node.js instalado.
 * 2. Bibliotecas instaladas: npm install langchain @langchain/openai dotenv
 * 3. Arquivo .env na raiz com: OPENAI_API_KEY=sua_chave_secreta_aqui
 */

// 1. Importação de Módulos
// -----------------------------------------------------------
// 'dotenv' carrega variáveis de ambiente do arquivo .env para process.env.
import * as dotenv from 'dotenv';

// 'ChatOpenAI' é a classe de conexão com os modelos da OpenAI (GPT-3.5, GPT-4).
import { ChatOpenAI } from '@langchain/openai';

// 'PromptTemplate' permite estruturar a entrada do usuário com lógica.
import { PromptTemplate } from '@langchain/core/prompts';

// 'SimpleSequentialChain' é um tipo de cadeia (chain) que executa passos em ordem.
import { SimpleSequentialChain } from 'langchain/chains';

// 2. Configuração de Ambiente
// -----------------------------------------------------------
// Carrega as variáveis do .env para o objeto 'process.env' do Node.js.
// Isso garante que a chave da API não esteja hard-coded no código.
dotenv.config();

/**
 * Função principal assíncrona que orquestra a geração de resumo.
 * Em um ambiente real (Next.js, Express), esta seria a lógica de um endpoint API.
 * 
 * @param tasks - Array de strings contendo as tarefas pendentes.
 * @returns O resumo gerado pelo modelo de linguagem.
 */
async function gerarResumoExecutivo(tasks: string[]): Promise<string> {
    
    // 3. Validação de Segurança
    // -----------------------------------------------------------
    // Verifica críticamente se a chave API existe antes de prosseguir.
    // Se estiver faltando, lança um erro explícito para evitar falhas silenciosas.
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
        throw new Error("Erro Crítico: OPENAI_API_KEY não encontrada no arquivo .env.");
    }

    // 4. Inicialização do Modelo (LLM)
    // -----------------------------------------------------------
    // Configura o modelo GPT-3.5 Turbo com temperatura 0 (respostas mais determinísticas).
    // Em um app real, a temperatura pode ser ajustada para criatividade.
    const model = new ChatOpenAI({
        apiKey: apiKey,
        model: "gpt-3.5-turbo", // Ou "gpt-4" se disponível
        temperature: 0,
    });

    // 5. Definição do Template de Prompt
    // -----------------------------------------------------------
    // O prompt é a instrução que guia a IA. Usamos um template com marcadores {input}.
    // Isso separa a lógica da instrução dos dados do usuário.
    const summaryTemplate = `
    Você é um assistente de produtividade focado em eficiência.
    Dada uma lista de tarefas, gere um resumo executivo conciso (máximo de 3 frases)
    destacando a prioridade principal e o foco geral do dia.

    TAREFAS:
    {tarefas}

    RESUMO EXECUTIVO:
    `;

    const prompt = new PromptTemplate({
        template: summaryTemplate,
        inputVariables: ["tarefas"], // Define qual variável será preenchida dinamicamente.
    });

    // 6. Criação da Cadeia de Execução (Chain)
    // -----------------------------------------------------------
    // Encadeamos o prompt ao modelo. O input do prompt vira o input do modelo.
    const chain = new SimpleSequentialChain({
        chains: [prompt, model], // Ordem de execução: Prompt -> Modelo
        verbose: true, // Habilita logs no console para depuração (útil em desenvolvimento)
    });

    // 7. Execução e Tratamento de Dados
    // -----------------------------------------------------------
    // Transforma o array de tarefas em uma única string legível para o LLM.
    const inputTarefas = tasks.join(", ");
    
    try {
        // A invocação da cadeia retorna um objeto de saída.
        const result = await chain.invoke({ input: inputTarefas });
        
        // O resultado do modelo geralmente vem em um campo 'output' ou texto puro.
        // Normalizamos para garantir que retornamos apenas a string.
        return result.output || result.toString();
    } catch (error) {
        console.error("Falha na geração do resumo:", error);
        return "Desculpe, não foi possível gerar o resumo no momento.";
    }
}

// 8. Simulação de Execução (Mock de Request)
// -----------------------------------------------------------
// Bloco para testar a função localmente como se fosse um script isolado.
// Em um app web, esta parte seria controlada por rotas de API (ex: Next.js API Routes).
(async () => {
    console.log("--- Iniciando Gerador de Resumo Executivo ---");
    
    const tarefasDoDia = [
        "Revisar o código do módulo de autenticação.",
        "Preparar a apresentação para o stakeholders às 14h.",
        "Resolver o bug de timeout no servidor de produção.",
        "Reunião de planejamento do sprint."
    ];

    console.log("Entrada:", tarefasDoDia);
    
    try {
        const resumo = await gerarResumoExecutivo(tarefasDoDia);
        console.log("\nResumo Gerado pela IA:");
        console.log("-----------------------------------");
        console.log(resumo);
        console.log("-----------------------------------");
    } catch (err) {
        console.error(err);
    }
})();
