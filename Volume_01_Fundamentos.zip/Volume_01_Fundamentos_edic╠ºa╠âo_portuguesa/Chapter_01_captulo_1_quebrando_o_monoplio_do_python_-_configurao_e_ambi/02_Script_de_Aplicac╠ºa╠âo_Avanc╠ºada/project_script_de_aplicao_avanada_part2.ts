/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada_part2.ts
// Description: Script de Aplicação Avançada
// ==========================================

// src/middleware.ts
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

/**
 * Middleware executado na Edge Runtime.
 * Objetivo: Validar entrada e limitar requisições antes do processamento principal.
 * Isso segue a estratégia "Edge-First" para reduzir custos e latência.
 */
export function middleware(request: NextRequest) {
  // 1. Rate Limiting Simples (Baseado em IP)
  const ip = request.ip ?? '127.0.0.1';
  const limit = 10; // Limite de 10 requisições por minuto
  const window = 60 * 1000; // 1 minuto em ms
  
  // Nota: Em produção, usar Redis ou Upstash para estado distribuído.
  // Aqui simulamos a lógica de proteção.
  
  // 2. Validação de Headers
  const headers = request.headers;
  const userAgent = headers.get('user-agent');
  
  if (!userAgent) {
    return new NextResponse(JSON.stringify({ error: 'User-Agent missing' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  // 3. Aprovação da Requisição
  return NextResponse.next();
}

// Configuração para rotear apenas certas rotas pelo middleware
export const config = {
  matcher: '/api/:path*',
};
