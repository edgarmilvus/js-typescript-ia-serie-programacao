/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada_part4.tsx
// Description: Script de Aplicação Avançada
// ==========================================

// src/app/page.tsx
'use client'; // Marca todo este arquivo como Client Component para usar hooks e estado

import { useState, useTransition } from 'react';
import { generateSummary } from './actions/summaryActions';
import { SummaryResponse } from '@/types/summary';

/**
 * Componente Principal da Aplicação.
 * Utiliza a arquitetura híbrida do Next.js App Router.
 */
export default function HomePage() {
  // Estado local para controlar o input do usuário (Client Component)
  const [inputText, setInputText] = useState('');
  
  // useTransition permite atualizações de UI não bloqueantes enquanto a Server Action processa
  const [isPending, startTransition] = useTransition();
  
  // Estado para armazenar a resposta do servidor
  const [response, setResponse] = useState<SummaryResponse>({ summary: '' });

  /**
   * Handler de submissão do formulário.
   * Otimizado para usar Server Actions sem expor endpoints de API manuais.
   */
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    // Inicia a transição para garantir que a UI permaneça responsiva
    startTransition(async () => {
      const formData = new FormData();
      formData.append('text', inputText);
      
      // Chama a Server Action
      const result = await generateSummary(null, formData);
      
      // Atualiza o estado local com o resultado
      setResponse(result as SummaryResponse);
    });
  };

  return (
    <main className="min-h-screen bg-gray-50 p-8 flex flex-col items-center">
      <div className="w-full max-w-2xl bg-white rounded-lg shadow-lg p-6">
        <h1 className="text-2xl font-bold text-gray-800 mb-4">
          Sumarizador Inteligente (Edge-First)
        </h1>
        
        {/* Formulário controlado pelo Client Component */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="text-input" className="block text-sm font-medium text-gray-700">
              Texto para resumir
            </label>
            <textarea
              id="text-input"
              name="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
              rows={6}
              placeholder="Cole aqui o texto longo..."
              required
              minLength={20}
            />
          </div>

          <button
            type="submit"
            disabled={isPending || inputText.length < 20}
            className={`w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white 
              ${isPending || inputText.length < 20 
                ? 'bg-gray-400 cursor-not-allowed' 
                : 'bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500'
              }`}
          >
            {isPending ? 'Processando...' : 'Gerar Resumo'}
          </button>
        </form>

        {/* Área de Resultado com Feedback Visual */}
        <div className="mt-6 p-4 bg-gray-100 rounded-md min-h-[100px]">
          <h2 className="text-lg font-semibold text-gray-700 mb-2">Resultado:</h2>
          
          {isPending && (
            <div className="flex items-center space-x-2 text-indigo-600">
              <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
              <span>Analisando texto e gerando resumo...</span>
            </div>
          )}

          {!isPending && response.summary && (
            <p className="text-gray-800 whitespace-pre-wrap">{response.summary}</p>
          )}

          {!isPending && response.error && (
            <p className="text-red-600 font-medium">{response.error}</p>
          )}

          {!isPending && !response.summary && !response.error && (
            <p className="text-gray-400 italic">O resumo aparecerá aqui...</p>
          )}
        </div>

        {/* Info de Arquitetura */}
        <div className="mt-6 text-xs text-gray-500 border-t pt-4">
          <p><strong>Arquitetura:</strong> Edge Middleware (Validação) → Server Action (Orquestração) → OpenAI Stream.</p>
          <p><strong>Segurança:</strong> Chaves de API protegidas no ambiente server-side.</p>
        </div>
      </div>
    </main>
  );
}
