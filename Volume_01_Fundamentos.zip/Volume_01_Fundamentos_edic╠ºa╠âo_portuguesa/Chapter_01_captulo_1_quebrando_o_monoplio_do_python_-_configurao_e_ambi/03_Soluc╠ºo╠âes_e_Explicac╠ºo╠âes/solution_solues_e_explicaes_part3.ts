/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.ts
// Description: Soluções e Explicações
// ==========================================

// 1. src/types/index.ts
export type Role = 'user' | 'assistant' | 'system';

export interface Message {
  role: Role;
  content: string;
}

// 2. src/services/openaiService.ts (Atualizado)
import OpenAI from 'openai';
import { Message } from '../types'; // Importando tipo compartilhado

export interface ChatCompletionParams {
  model: string;
  messages: Message[]; // Usando o tipo Message[]
}

// ... (Resto da classe OpenAIService igual ao exercício anterior)

// 3. src/utils/parser.ts
export function parseResponse(rawResponse: string): string[] {
  // Simulação simples: divide por frases ou retorna como array de uma linha
  if (!rawResponse) return [];
  return rawResponse.split('.').filter(s => s.trim().length > 0).map(s => s.trim() + '.');
}

// 4. src/utils/validator.ts
import { Message } from '../types';

// Função de validação em tempo de execução
export function validateMessages(messages: Message[]): boolean {
  if (messages.length === 0) return false;
  if (!['user', 'system'].includes(messages[0].role)) return false;
  return messages.every(m => m.content && m.content.trim().length > 0);
}

// 5. Tipos Avançados (Generics e Condicionais)
// Este tipo garante estaticamente que a propriedade content não é vazia.
// Nota: O TypeScript não consegue inferir runtime checks estaticamente sem assertion functions,
// mas podemos definir um tipo que representa a validade.
export type NonEmptyString = string & { readonly __nonEmpty: unique symbol };

// Um tipo condicional que verifica se T extends Message com content não vazio
export type ValidatedMessage<T extends Message> = T['content'] extends '' 
  ? never 
  : T;

// 6. src/index.ts
import { OpenAIService } from './services/openaiService';
import { parseResponse } from './utils/parser';
import { validateMessages } from './utils/validator';
import { Message } from './types';

async function main() {
  const service = OpenAIService.getInstance();

  // Construindo um array de mensagens tipado
  const conversation: Message[] = [
    { role: 'system', content: 'Você é um assistente útil.' },
    { role: 'user', content: 'Explique TypeScript.' }
  ];

  // Validação antes do envio
  if (validateMessages(conversation)) {
    try {
      // Como a interface do serviço espera Message[], o tipo é compatível
      const response = await service.getResponse({
        model: 'gpt-3.5-turbo',
        messages: conversation
      });
      
      const parts = parseResponse(response);
      console.log('Resposta parseada:', parts);
    } catch (error) {
      console.error('Erro:', (error as Error).message);
    }
  } else {
    console.error('Falha na validação das mensagens.');
  }
}

main();
