/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.ts
// Description: Soluções e Explicações
// ==========================================

// 1. src/simulations/processor.ts
export interface ProcessingTask {
  id: string;
  input: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
}

// Função auxiliar de delay
const wait = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export async function* processBatch(inputs: string[]): AsyncGenerator<ProcessingTask, void, unknown> {
  for (const input of inputs) {
    const task: ProcessingTask = {
      id: Math.random().toString(36).substr(2, 9),
      input,
      status: 'processing'
    };
    
    yield task; // Emite o estado 'processing'

    // Simula I/O intensivo (ex: chamada à API ou DB)
    await wait(1000); 

    task.status = 'completed';
    yield task; // Emite o estado 'completed'
  }
}

// 2. src/index.ts (Simulação do Pipeline)
import { processBatch } from './simulations/processor';

async function runPipeline() {
  const inputs = ['Texto 1', 'Texto 2', 'Texto 3'];
  
  console.log('Iniciando pipeline...');
  for await (const task of processBatch(inputs)) {
    console.log(`Task ${task.id}: [${task.status}] - Input: ${task.input}`);
  }
  console.log('Pipeline finalizado.');
}

// 3. Simulação de Condição de Corrida e Mutex
// Mutex simulado simples
class SimpleMutex {
  private locked = false;
  private queue: (() => void)[] = [];

  async acquire(): Promise<() => void> {
    if (this.locked) {
      await new Promise<void>(resolve => this.queue.push(resolve));
    }
    this.locked = true;
    // Retorna uma função de release
    return () => {
      this.locked = false;
      const next = this.queue.shift();
      if (next) next();
    };
  }
}

let sharedResource = 0;

async function incrementResource(mutex: SimpleMutex) {
  const release = await mutex.acquire();
  try {
    // Simula uma operação não atômica sem mutex
    const current = sharedResource;
    await new Promise(r => setTimeout(r, 10)); // Delay simula processamento
    sharedResource = current + 1;
  } finally {
    release();
  }
}

async function runRaceConditionDemo() {
  const mutex = new SimpleMutex();
  const promises = Array(100).fill(null).map(() => incrementResource(mutex));
  
  await Promise.all(promises);
  console.log(`Resultado final com Mutex: ${sharedResource}`); // Deve ser 100
}

// Execução principal
(async () => {
  await runPipeline();
  console.log('---');
  await runRaceConditionDemo();
})();
