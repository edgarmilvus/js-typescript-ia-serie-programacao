/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.ts
// Description: Soluções e Explicações
// ==========================================

// 1. Instruções de Instalação (Executar no terminal):
// npm init -y
// npm install typescript ts-node dotenv @types/node
// npm install --save-dev @types/node

// 2. Arquivo tsconfig.json
// {
//   "compilerOptions": {
//     "target": "ES2020",
//     "module": "CommonJS",
//     "rootDir": "./src",
//     "outDir": "./dist",
//     "esModuleInterop": true,
//     "strict": true,
//     "baseUrl": ".",
//     "paths": {
//       "@config/*": ["src/config/*"]
//     }
//   },
//   "include": ["src/**/*"]
// }

// 3. Arquivo .env (na raiz)
// OPENAI_API_KEY="sk-test-key-123"

// 4. Arquivo src/config.ts
import dotenv from 'dotenv';

// Carrega as variáveis do .env para process.env
dotenv.config();

interface Config {
  openaiApiKey: string | undefined;
}

const config: Config = {
  openaiApiKey: process.env.OPENAI_API_KEY,
};

export default config;

// 5. Arquivo src/index.ts (Demonstração do Alias)
// Para executar com suporte a paths via ts-node, use:
// ts-node -r tsconfig-paths/register src/index.ts
// (Nota: É necessário instalar 'tsconfig-paths' globalmente ou localmente para alias funcionar na execução direta)

import config from '@config/config'; // Usando o alias configurado

console.log('Configuração carregada:', config.openaiApiKey ? 'Chave encontrada' : 'Chave ausente');
