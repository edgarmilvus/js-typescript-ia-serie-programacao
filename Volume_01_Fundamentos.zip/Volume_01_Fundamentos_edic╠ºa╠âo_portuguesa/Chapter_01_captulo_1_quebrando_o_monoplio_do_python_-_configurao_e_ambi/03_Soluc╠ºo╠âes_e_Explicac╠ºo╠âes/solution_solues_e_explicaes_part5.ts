/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part5.ts
// Description: Soluções e Explicações
// ==========================================

digraph ArquiteturaIA {
    rankdir=TB; // Top to Bottom
    node [shape=box, style="rounded,filled", fillcolor="#e0e0e0"];
    
    // Nodos Principais
    Env [label=".env (Config)", shape=note, fillcolor="#fff8dc"];
    TsConfig [label="tsconfig.json", shape=note, fillcolor="#fff8dc"];
    ConfigLoader [label="Config Loader\n(dotenv)", fillcolor="#add8e6"];
    
    Service [label="OpenAI Service\n(Singleton)", fillcolor="#90ee90"];
    Logic [label="Logic Layer\n(Index.ts)", fillcolor="#f08080"];
    Output [label="Output\n(Console)", shape=cylinder, fillcolor="#ffffff"];

    // Fluxo Principal
    Env -> ConfigLoader [label="Carrega variáveis"];
    TsConfig -> ConfigLoader [label="Define Paths/Types"];
    ConfigLoader -> Service [label="Injeta API Key"];
    Service -> Logic [label="Método getResponse()"];
    Logic -> Output [label="Resultado"];

    // Fluxo de Erro e Retry
    Service -> ErrorCheck [label="Falha na API", style=dashed, color=red];
    
    subgraph cluster_retry {
        label="Lógica de Retry";
        style=dashed;
        color=blue;
        
        ErrorCheck [label="Erro Detectado?", shape=diamond, fillcolor="#ffcccb"];
        Log [label="Log de Erro", fillcolor="#f5f5f5"];
        Delay [label="Delay (Exponential\nBackoff)", fillcolor="#f5f5f5"];
        
        ErrorCheck -> Log [label="Sim"];
        Log -> Delay;
        Delay -> Service [label="Tentar Novamente", constraint=false];
    }

    ErrorCheck -> Output [label="Não (Sucesso)", style=invis]; // Apenas para alinhamento
}
