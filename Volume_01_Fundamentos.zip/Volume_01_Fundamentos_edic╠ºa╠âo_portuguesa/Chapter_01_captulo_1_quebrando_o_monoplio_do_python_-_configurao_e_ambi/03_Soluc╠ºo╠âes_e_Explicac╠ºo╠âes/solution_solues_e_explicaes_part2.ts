/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part2.ts
// Description: Soluções e Explicações
// ==========================================

// 1. Instalação: npm install openai

// 2. src/services/openaiService.ts
import OpenAI from 'openai';
import config from '@config/config'; // Assumindo alias configurado

// Interface para garantir que 'model' e 'messages' sejam obrigatórios
export interface ChatCompletionParams {
  model: string;
  messages: Array<{ role: 'user' | 'assistant' | 'system'; content: string }>;
}

export class OpenAIService {
  private static instance: OpenAIService;
  private openai: OpenAI;

  // Construtor privado para evitar instanciação direta (Singleton)
  private constructor() {
    if (!config.openaiApiKey) {
      throw new Error('API Key não encontrada nas variáveis de ambiente.');
    }
    this.openai = new OpenAI({
      apiKey: config.openaiApiKey,
    });
  }

  public static getInstance(): OpenAIService {
    if (!OpenAIService.instance) {
      OpenAIService.instance = new OpenAIService();
    }
    return OpenAIService.instance;
  }

  public async getResponse(params: ChatCompletionParams): Promise<string> {
    try {
      const completion = await this.openai.chat.completions.create(params);
      
      const content = completion.choices[0]?.message?.content;
      
      if (!content) {
        throw new Error('A resposta da API está vazia.');
      }

      return content;
    } catch (error) {
      // Tratamento de erro amigável
      if (error instanceof OpenAI.APIError) {
        const msg = error.message || 'Erro desconhecido da API';
        throw new Error(`Erro da OpenAI: ${msg}`);
      }
      throw error;
    }
  }
}

// 3. Função de Delay (Utilitário)
export const delay = (ms: number): Promise<void> => new Promise(resolve => setTimeout(resolve, ms));

// 4. src/index.ts
import { OpenAIService, delay } from './services/openaiService';

async function main() {
  const service = OpenAIService.getInstance();

  try {
    // Simulação de falha intencional (se a chave for 'sk-test-key-123', a API real falhará)
    console.log('Tentando enviar mensagem...');
    const response = await service.getResponse({
      model: 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: 'Olá, explique a diferença entre Node.js e Python para IA' }]
    });
    console.log('Resposta:', response);
  } catch (error) {
    console.error('Falha capturada:', (error as Error).message);
    console.log('Iniciando lógica de retry após delay...');
    
    // Simulação de retry
    await delay(2000); // Espera 2 segundos
    console.log('Nova tentativa (simulada)...');
  }
}

main();
