/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada_part2.ts
// Description: Script de Aplicação Avançada
// ==========================================

// Arquivo: pages/api/analyze-feedback.ts (ou app/api/analyze-feedback/route.ts no App Router)

import type { NextApiRequest, NextApiResponse } from 'next';
import { OpenAI } from '@langchain/openai';
import { LLMChain } from 'langchain/chains';
import { PromptTemplate } from '@langchain/core/prompts';

// --- Definição da Arquitetura de Agente Supervisor ---

// 1. Inicialização do LLM (O "Cérebro" central)
// Nota: Em produção, a chave API deve vir de variáveis de ambiente (process.env.OPENAI_API_KEY)
const llm = new OpenAI({ 
  temperature: 0.7, 
  modelName: 'gpt-3.5-turbo-instruct' 
});

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // --- 2. Validação e Segurança ---
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const { text } = req.body;

  if (!text || typeof text !== 'string') {
    return res.status(400).json({ error: 'Texto inválido ou ausente.' });
  }

  // --- 3. Orquestração de Chains (Consensus Pattern) ---
  // Definimos dois "workers" (chains) que atacam problemas diferentes com o mesmo LLM
  
  // Worker 1: Análise de Sentimento
  const sentimentPrompt = new PromptTemplate({
    template: `Analise o sentimento do seguinte feedback do cliente. Responda apenas com uma palavra: Positivo, Negativo ou Neutro.\n\nFeedback: {input_feedback}`,
    inputVariables: ['input_feedback'],
  });
  const sentimentChain = new LLMChain({ llm, prompt: sentimentPrompt });

  // Worker 2: Geração de Resposta
  const replyPrompt = new PromptTemplate({
    template: `Você é um suporte ao cliente. Escreva uma resposta empática e profissional para o seguinte feedback. Mantenha a resposta concisa.\n\nFeedback: {input_feedback}`,
    inputVariables: ['input_feedback'],
  });
  const replyChain = new LLMChain({ llm, prompt: replyPrompt });

  try {
    // --- 4. Execução Assíncrona Resiliente ---
    // Promise.all permite execução paralela para melhorar latência (quando não há dependência)
    // Neste caso, processamos sequencialmente para garantir a extração de tópicos após o sentimento,
    // simulando um fluxo de trabalho de "Supervisor".
    
    // A. Execução do Worker de Sentimento
    const sentimentResult = await sentimentChain.call({ input_feedback: text });
    
    // B. Execução do Worker de Resposta
    const replyResult = await replyChain.call({ input_feedback: text });

    // --- 5. Síntese do Consenso (Finalização) ---
    // O Supervisor compila os resultados em um objeto único
    const finalResponse = {
      sentiment: (sentimentResult.text as string).trim(),
      topics: extractKeywords(text), // Função auxiliar simples para extração de tópicos
      suggestedReply: replyResult.text,
      confidence: 0.95, // Mock de pontuação de confiança baseada na temperatura do LLM
    };

    // Envio da resposta estruturada ao Frontend
    res.status(200).json(finalResponse);

  } catch (err) {
    // --- 6. Tratamento de Erros e Degração Graceful ---
    console.error('Erro na Orquestração de IA:', err);
    
    // Garante que o frontend receba um erro legível, não um crash do servidor
    res.status(500).json({ 
      error: 'Falha na orquestração do modelo de linguagem.',
      details: process.env.NODE_ENV === 'development' ? (err as Error).message : undefined
    });
  } finally {
    // --- 7. Limpeza de Recursos ---
    // Em cenários com conexões persistentes (ex: Vector Stores), fecharia conexões aqui.
    // Para API Stateless, este bloco garante que o fluxo de execução termine corretamente.
    console.log('Requisição processada:', new Date().toISOString());
  }
}

// Função auxiliar simples para simular extração de tópicos (Regex)
function extractKeywords(text: string): string[] {
  const stopWords = ['o', 'a', 'e', 'de', 'para', 'com'];
  const words = text.toLowerCase().match(/\b\w+\b/g) || [];
  return [...new Set(words.filter(w => w.length > 3 && !stopWords.includes(w)))].slice(0, 3);
}
