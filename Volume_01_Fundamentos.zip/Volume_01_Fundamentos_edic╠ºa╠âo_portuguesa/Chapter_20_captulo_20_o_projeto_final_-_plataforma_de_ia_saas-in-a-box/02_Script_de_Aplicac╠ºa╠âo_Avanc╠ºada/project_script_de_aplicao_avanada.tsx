/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_script_de_aplicao_avanada.tsx
// Description: Script de Aplicação Avançada
// ==========================================

/**
 * Página de Dashboard de Feedback do Cliente.
 * 
 * Contexto: SaaS de Monitoramento de Suporte.
 * Funcionalidade: Interface para submeter feedback e receber análise estruturada de IA.
 * 
 * Tecnologias: Next.js (App Router ou Pages), TypeScript, LangChain.js (Server-side).
 */

import { useState } from 'react';
import type { NextPage } from 'next';

// Tipagem estruturada para a resposta consolidada do Supervisor
interface AnalysisResult {
  sentiment: 'Positivo' | 'Negativo' | 'Neutro';
  topics: string[];
  suggestedReply: string;
  confidence: number;
}

const FeedbackAnalyzer: NextPage = () => {
  // --- 1. Gestão de Estado e UX ---
  // Gerencia o input do usuário e o estado de carregamento para feedback visual imediato
  const [feedback, setFeedback] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  /**
   * Função principal acionada pelo formulário.
   * Atua como o "Supervisor" da aplicação, orquestrando as chamadas assíncronas.
   */
  const handleAnalyze = async () => {
    if (!feedback.trim()) return;

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      // --- 2. Comunicação Backend-Frontend ---
      // Chamada à API Route do Next.js (server-side) para proteger chaves de API e orquestrar a IA
      const response = await fetch('/api/analyze-feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: feedback }),
      });

      if (!response.ok) {
        throw new Error('Erro ao processar a análise. Tente novamente.');
      }

      const data: AnalysisResult = await response.json();
      setResult(data);
    } catch (err) {
      // --- 3. Tratamento de Erros (Resiliência) ---
      console.error('Falha na operação assíncrona:', err);
      setError(err instanceof Error ? err.message : 'Erro desconhecido');
    } finally {
      // Garante que o estado de carregamento seja resetado, independentemente do sucesso ou falha
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>IA SaaS-in-a-Box: Analisador de Feedback</h1>
      
      <div style={{ marginBottom: '1rem' }}>
        <label htmlFor="feedback" style={{ display: 'block', marginBottom: '0.5rem' }}>
          Insira o feedback do cliente:
        </label>
        <textarea
          id="feedback"
          rows={5}
          value={feedback}
          onChange={(e) => setFeedback(e.target.value)}
          style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid #ccc' }}
          placeholder="Ex: O produto chegou atrasado, mas o suporte foi excelente..."
        />
      </div>

      <button
        onClick={handleAnalyze}
        disabled={loading}
        style={{
          padding: '0.75rem 1.5rem',
          backgroundColor: loading ? '#ccc' : '#0070f3',
          color: 'white',
          border: 'none',
          borderRadius: '4px',
          cursor: loading ? 'not-allowed' : 'pointer',
        }}
      >
        {loading ? 'Processando IA...' : 'Analizar Feedback'}
      </button>

      {error && (
        <div style={{ marginTop: '1rem', padding: '1rem', backgroundColor: '#fee', color: '#c00', borderRadius: '4px' }}>
          {error}
        </div>
      )}

      {result && (
        <div style={{ marginTop: '2rem', padding: '1rem', backgroundColor: '#f5f5f5', borderRadius: '4px' }}>
          <h3>Relatório da Análise:</h3>
          <p><strong>Sentimento:</strong> {result.sentiment} (Confiança: {result.confidence})</p>
          <p><strong>Tópicos:</strong> {result.topics.join(', ')}</p>
          <div style={{ marginTop: '1rem', padding: '0.5rem', backgroundColor: '#fff', borderLeft: '4px solid #0070f3' }}>
            <strong>Sugestão de Resposta:</strong>
            <p style={{ fontStyle: 'italic', marginTop: '0.5rem' }}>{result.suggestedReply}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default FeedbackAnalyzer;
