/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_exemplo_de_cdigo_bsico.ts
// Description: Exemplo de Código Básico
// ==========================================

/**
 * EXEMPLO: Serviço de Análise de Sentimento SaaS com Resiliência Assíncrona
 * 
 * Contexto: Backend Node.js (TypeScript) simulando uma chamada à API da OpenAI.
 * Objetivo: Demonstrar o ciclo completo de tratamento de erros e limpeza de recursos.
 */

// Simulação de um Pool de Conexões (ex: conexão com Banco de Dados ou Redis)
// Em um cenário real, isso seria um cliente MongoDB ou PostgreSQL.
class ConnectionPool {
    private isConnected: boolean = false;

    async connect(): Promise<void> {
        console.log("[Pool] Tentando conectar ao banco de dados...");
        // Simula um tempo de conexão
        await new Promise(resolve => setTimeout(resolve, 100));
        this.isConnected = true;
        console.log("[Pool] Conexão estabelecida com sucesso.");
    }

    async close(): Promise<void> {
        console.log("[Pool] Fechando conexões e liberando recursos...");
        this.isConnected = false;
        await new Promise(resolve => setTimeout(resolve, 50));
        console.log("[Pool] Recursos liberados.");
    }
}

/**
 * Função auxiliar para simular uma chamada à API da OpenAI.
 * @param text - O texto a ser analisado.
 * @returns - Uma Promise que resolve com o resultado da análise.
 * @throws - Erro simulado se o texto contiver palavras proibidas.
 */
async function callOpenAIApi(text: string): Promise<{ sentiment: string; confidence: number }> {
    console.log(`[API] Enviando texto para análise: "${text}"`);
    
    // Simulação de latência de rede
    await new Promise(resolve => setTimeout(resolve, 200));

    // Simulação de falha crítica (Hallucination ou API Error)
    if (text.toLowerCase().includes("erro")) {
        throw new Error("API Error: 500 Internal Server Error - OpenAI Service Unavailable");
    }

    // Simulação de sucesso
    return {
        sentiment: text.toLowerCase().includes("bom") ? "positive" : "neutral",
        confidence: 0.95
    };
}

/**
 * Função principal do Controller SaaS.
 * Aplica o padrão de Resiliência Exaustiva.
 * 
 * @param inputText - Texto recebido do frontend.
 * @returns - O objeto de resultado processado ou uma mensagem de erro amigável.
 */
async function analyzeSentimentSaaS(inputText: string): Promise<any> {
    const dbConnection = new ConnectionPool();
    
    // Variável para garantir que o retorno seja válido mesmo em caso de erro
    let result = null;

    try {
        // 1. Estabelecer conexão (Simulação de dependência externa)
        await dbConnection.connect();

        // 2. Tentativa de chamada à API Externa (Operação Crítica)
        // Poderíamos adicionar um loop de retry aqui se necessário.
        const apiResponse = await callOpenAIApi(inputText);
        
        // 3. Processamento bem-sucedido
        console.log("[App] Análise concluída.");
        result = { 
            status: 'success', 
            data: apiResponse 
        };

    } catch (error: any) {
        // 4. Captura Exaustiva de Erros
        // NUNCA deixe um erro de Promise escapar sem tratamento em uma API.
        console.error("[App] ERRO CAPTURADO:", error.message);

        // Decisão de negócio baseada no erro (Circuit Breaker lógico)
        if (error.message.includes("500")) {
            result = { 
                status: 'error', 
                message: 'Serviço temporariamente indisponível. Tente novamente mais tarde.', 
                code: 500 
            };
        } else {
            result = { 
                status: 'error', 
                message: 'Falha na validação do texto.', 
                code: 400 
            };
        }

    } finally {
        // 5. Garantia de Limpeza de Recursos (Resource Cleanup)
        // Esta bloco executa SUCESSO ou FALHA.
        // É CRÍTICO para evitar vazamento de memória (memory leaks) em servidores Node.js.
        try {
            await dbConnection.close();
        } catch (cleanupError) {
            // Se a limpeza falhar, logamos, mas não quebramos a aplicação
            console.error("[App] FALHA CRÍTICA AO LIMPAR RECURSOS:", cleanupError);
        }
    }

    return result;
}

// --- EXECUÇÃO DO EXEMPLO ---

// Simulando uma requisição HTTP real (como se viesse do Express.js)
(async () => {
    console.log("=== INÍCIO DO TESTE DE RESILIÊNCIA ===\n");

    // Cenário 1: Sucesso
    console.log("--- Cenário 1: Fluxo Feliz ---");
    const successResult = await analyzeSentimentSaaS("O produto é bom e a entrega foi rápida.");
    console.log("Resposta Final:", successResult);
    console.log("\n");

    // Cenário 2: Falha na API (Erro Controlado)
    console.log("--- Cenário 2: Falha na API Externa ---");
    const errorResult = await analyzeSentimentSaaS("Ocorreu um erro grave no sistema.");
    console.log("Resposta Final:", errorResult);
    console.log("\n");

    console.log("=== FIM DO TESTE ===");
})();
