/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes.ts
// Description: Soluções e Explicações
// ==========================================

import { RecursiveCharacterTextSplitter } from "langchain/text_splitter";
import { OpenAIEmbeddings } from "@langchain/openai";
import { MemoryVectorStore } from "langchain/vectorstores/memory";
import { ChatOpenAI } from "@langchain/openai";
import { PromptTemplate } from "@langchain/core/prompts";
import { Document } from "@langchain/core/documents";

export class RAGPipeline {
    private embeddings: OpenAIEmbeddings;
    private vectorStore: MemoryVectorStore | null;
    private llm: ChatOpenAI;
    private chunkSize: number;
    private chunkOverlap: number;

    constructor(chunkSize: number = 1000, chunkOverlap: number = 200) {
        this.embeddings = new OpenAIEmbeddings();
        this.llm = new ChatOpenAI({ model: "gpt-3.5-turbo" });
        this.vectorStore = null;
        this.chunkSize = chunkSize;
        this.chunkOverlap = chunkOverlap;
    }

    /**
     * Lógica de Chunking Híbrido:
     * 1. Divide o texto baseado em marcadores de seção (ex: ## Título ou linhas em branco).
     * 2. Para cada seção, verifica o tamanho.
     * 3. Se maior que chunkSize, aplica o RecursiveCharacterTextSplitter internamente.
     */
    private async hybridChunk(text: string): Promise<Document[]> {
        // 1. Divisão inicial por marcadores de seção (Markdown ou texto simples)
        // Usamos um regex para dividir por "## " ou "\n\n" mantendo o delimitador
        const sectionRegex = /(\n\n|## .+?\n)/g;
        const parts = text.split(sectionRegex).filter((part) => part.trim() !== "");

        const documents: Document[] = [];
        const splitter = new RecursiveCharacterTextSplitter({
            chunkSize: this.chunkSize,
            chunkOverlap: this.chunkOverlap,
        });

        // 2. Processamento de cada parte
        for (let i = 0; i < parts.length; i++) {
            const part = parts[i];
            
            // Se a parte for um marcador de seção (ex: "## Introdução"), 
            // anexamos ao conteúdo da próxima parte para preservar contexto.
            if (part.startsWith("## ") || part === "\n\n") {
                if (i + 1 < parts.length) {
                    parts[i + 1] = part + parts[i + 1];
                }
                continue;
            }

            // 3. Se a seção for maior que o limite, quebramos internamente
            if (part.length > this.chunkSize) {
                const subDocs = await splitter.createDocuments([part]);
                documents.push(...subDocs);
            } else {
                // Se couber, criamos o documento diretamente
                documents.push(new Document({ pageContent: part }));
            }
        }

        return documents;
    }

    /**
     * Método de ingestão que utiliza o chunking híbrido.
     */
    public async ingest(textContent: string): Promise<void> {
        console.log("Iniciando ingestão com chunking híbrido...");
        
        // 1. Gerar chunks híbridos
        const documents = await this.hybridChunk(textContent);

        // 2. Gerar Embeddings e Armazenar no Vector Store
        // O MemoryVectorStore cria a indexação vetorial automaticamente
        this.vectorStore = await MemoryVectorStore.fromDocuments(
            documents,
            this.embeddings
        );
        
        console.log(`Indexados ${documents.length} documentos.`);
    }

    public async retrieve(query: string): Promise<Document[]> {
        if (!this.vectorStore) {
            throw new Error("Vector store não inicializado. Chame ingest() primeiro.");
        }
        // top-k = 4 conforme requisito
        return this.vectorStore.similaritySearch(query, 4);
    }

    public async generateAnswer(query: string): Promise<string> {
        if (!this.vectorStore) {
            throw new Error("Vector store não inicializado.");
        }

        // Recuperação de contexto
        const docs = await this.retrieve(query);
        const context = docs.map(doc => doc.pageContent).join("\n\n---\n\n");

        // Prompt de síntese
        const promptTemplate = PromptTemplate.fromTemplate(
            `Você é um assistente útil. Use apenas o contexto abaixo para responder à pergunta do usuário.
            Se a resposta não estiver no contexto, diga que não sabe.
            
            Contexto:
            {context}
            
            Pergunta: {question}
            
            Resposta:`
        );

        const chain = promptTemplate.pipe(this.llm);
        const response = await chain.invoke({ context, question: query });

        return response.content as string;
    }
}
