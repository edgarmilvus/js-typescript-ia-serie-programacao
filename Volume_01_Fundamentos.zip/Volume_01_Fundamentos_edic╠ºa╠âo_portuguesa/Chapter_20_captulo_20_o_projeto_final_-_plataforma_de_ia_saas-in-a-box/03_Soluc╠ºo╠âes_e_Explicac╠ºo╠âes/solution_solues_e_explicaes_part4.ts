/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part4.ts
// Description: Soluções e Explicações
// ==========================================

import express, { Request, Response } from 'express';
import { ChatOpenAI } from "@langchain/openai";
import jwt from 'jsonwebtoken';

// Middleware de Autenticação
export const authMiddleware = (req: Request, res: Response, next: Function) => {
    const token = req.headers.authorization?.split(' ')[1]; // Bearer <token>
    if (!token) return res.status(401).json({ error: 'Acesso negado. Token não fornecido.' });

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET!);
        req.user = decoded; // Adiciona ao request para uso posterior
        next();
    } catch (error) {
        res.status(401).json({ error: 'Token inválido.' });
    }
};

// Rota de Chat com Streaming
app.post('/api/chat', authMiddleware, async (req: Request, res: Response) => {
    const { message } = req.body;
    
    // Configuração do LLM com stream ativado
    const llm = new ChatOpenAI({
        model: "gpt-3.5-turbo",
        streaming: true // Habilita o callback de stream
    });

    // Configuração dos headers para streaming
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Transfer-Encoding', 'chunked');
    res.setHeader('Cache-Control', 'no-cache');

    try {
        // Invocação do modelo com callback de stream
        await llm.invoke([new HumanMessage(message)], {
            callbacks: [{
                handleLLMNewToken: (token) => {
                    // Envia cada token/token chunk para o cliente
                    res.write(token);
                }
            }]
        });

        // Fecha o stream
        res.end();
    } catch (error) {
        console.error(error);
        res.status(500).write("Erro no processamento.");
        res.end();
    }
});
