/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part3.ts
// Description: Soluções e Explicações
// ==========================================

import { ChatOpenAI } from "@langchain/openai";
import { HumanMessage, SystemMessage } from "@langchain/core/messages";

// 1. Definição dos Agentes com Personalidades
const creativeAgent = new ChatOpenAI({ temperature: 0.9, model: "gpt-3.5-turbo" });
const technicalAgent = new ChatOpenAI({ temperature: 0.1, model: "gpt-3.5-turbo" });
const criticAgent = new ChatOpenAI({ temperature: 0.2, model: "gpt-3.5-turbo" });

// 2. Função de Classificação Dinâmica
async function classifyQuery(query: string): Promise<'coding' | 'creative' | 'general'> {
    const classifier = new ChatOpenAI({ temperature: 0 }); // Temperatura baixa para precisão
    
    const systemPrompt = `
        Classifique a consulta do usuário em uma das seguintes categorias:
        - 'coding': Se envolve programação, algoritmos, código, bugs.
        - 'creative': Se envolve escrita, marketing, ideias, poesia, histórias.
        - 'general': Para qualquer outra coisa.
        
        Responda APENAS com a palavra da categoria.
    `;

    const response = await classifier.invoke([
        new SystemMessage(systemPrompt),
        new HumanMessage(query)
    ]);

    const content = response.content as string;
    
    // Validação simples da resposta
    if (content.includes('coding')) return 'coding';
    if (content.includes('creative')) return 'creative';
    return 'general';
}

// 3. Função Principal de Orquestração
export async function runConsensusWorkflow(query: string) {
    console.log(`Analisando consulta: "${query}"`);
    const category = await classifyQuery(query);
    console.log(`Categoria detectada: ${category}`);

    // Promessas dos agentes ativos
    const agentPromises: Promise<any>[] = [];

    // Lógica de Roteamento Condicional
    if (category === 'coding') {
        // Técnico (foco em código) + Crítico (revisão)
        console.log("Ativando agentes: Técnico e Crítico");
        agentPromises.push(
            technicalAgent.invoke([new SystemMessage("Você é um especialista técnico preciso."), new HumanMessage(query)]),
            criticAgent.invoke([new SystemMessage("Revise a resposta técnica apontando falhas de segurança ou boas práticas."), new HumanMessage(query)])
        );
    } else if (category === 'creative') {
        // Criativo (foco em estilo) + Crítico (revisão)
        console.log("Ativando agentes: Criativo e Crítico");
        agentPromises.push(
            creativeAgent.invoke([new SystemMessage("Escreva uma resposta engajadora e criativa."), new HumanMessage(query)]),
            criticAgent.invoke([new SystemMessage("Revise a resposta criativa melhorando a fluidez e impacto."), new HumanMessage(query)])
        );
    } else {
        // General: Todos os agentes para um consenso completo
        console.log("Ativando todos os agentes");
        agentPromises.push(
            creativeAgent.invoke([new SystemMessage("Seja criativo."), new HumanMessage(query)]),
            technicalAgent.invoke([new SystemMessage("Seja técnico."), new HumanMessage(query)]),
            criticAgent.invoke([new SystemMessage("Seja crítico."), new HumanMessage(query)])
        );
    }

    // Aguarda as respostas paralelas
    const results = await Promise.all(agentPromises);
    
    // 4. Síntese Final (Reviewer Node)
    const synthesisPrompt = `
        Combine as insights das respostas abaixo para gerar uma resposta final coesa.
        Resolva contradições e mantenha a qualidade.
        
        Respostas:
        ${results.map((r, i) => `[Agente ${i + 1}]: ${r.content}`).join('\n\n')}
    `;

    const finalAgent = new ChatOpenAI({ temperature: 0.7 });
    const finalResponse = await finalAgent.invoke([new HumanMessage(synthesisPrompt)]);

    return {
        category,
        finalAnswer: finalResponse.content,
        sourcesUsed: results.length
    };
}
