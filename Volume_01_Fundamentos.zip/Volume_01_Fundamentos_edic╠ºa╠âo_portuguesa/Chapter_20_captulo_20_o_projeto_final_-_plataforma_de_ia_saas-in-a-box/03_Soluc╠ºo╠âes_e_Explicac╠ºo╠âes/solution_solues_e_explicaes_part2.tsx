/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solues_e_explicaes_part2.tsx
// Description: Soluções e Explicações
// ==========================================

import React, { useState, useRef, useEffect } from 'react';

// Definições de tipos
interface SourceDocument {
    content: string;
    metadata: { source: string; page?: number };
    score: number;
}

interface ContextViewerProps {
    sources: SourceDocument[];
    answer: string;
}

export const ContextViewer: React.FC<ContextViewerProps> = ({ sources, answer }) => {
    const [activeSourceIndex, setActiveSourceIndex] = useState<number | null>(null);
    // Refs para os elementos DOM das fontes (para rolagem)
    const sourceRefs = useRef<(HTMLDivElement | null)[]>([]);

    // Efeito para rolar automaticamente quando uma fonte ativa é selecionada
    useEffect(() => {
        if (activeSourceIndex !== null && sourceRefs.current[activeSourceIndex]) {
            sourceRefs.current[activeSourceIndex]?.scrollIntoView({
                behavior: 'smooth',
                block: 'center'
            });
        }
    }, [activeSourceIndex]);

    // Função para extrair frases da resposta e torná-las clicáveis
    // (Simplificação: dividimos por pontuação para criar spans clicáveis)
    const renderAnswerWithCitations = () => {
        const sentences = answer.split(/(?<=[.!?])\s+/);
        return sentences.map((sentence, idx) => (
            <span 
                key={idx}
                onClick={() => handleCitationClick(idx)}
                style={{ 
                    cursor: 'pointer', 
                    backgroundColor: activeSourceIndex === idx ? '#e3f2fd' : 'transparent',
                    borderRadius: '4px',
                    padding: '2px'
                }}
            >
                {sentence}{" "}
            </span>
        ));
    };

    // Lógica de clique: associa uma frase da resposta a um documento fonte
    // Nota: Em um cenário real, você teria um mapeamento exato (citation index) vindo do backend.
    // Aqui simulamos mapeando o índice da frase para o índice da fonte (cíclico se houver mais frases que fontes).
    const handleCitationClick = (sentenceIndex: number) => {
        if (sources.length === 0) return;
        const sourceIndex = sentenceIndex % sources.length;
        setActiveSourceIndex(sourceIndex);
    };

    return (
        <div className="context-viewer-container" style={{ display: 'flex', gap: '20px', marginTop: '20px' }}>
            
            {/* Painel da Resposta */}
            <div className="answer-panel" style={{ flex: 2, border: '1px solid #ddd', padding: '15px', borderRadius: '8px' }}>
                <h3>Resposta da IA</h3>
                <div style={{ lineHeight: '1.6' }}>
                    {renderAnswerWithCitations()}
                </div>
            </div>

            {/* Painel das Fontes */}
            <div className="sources-panel" style={{ flex: 1, border: '1px solid #ddd', padding: '15px', borderRadius: '8px', maxHeight: '400px', overflowY: 'auto' }}>
                <h3>Fontes Utilizadas</h3>
                {sources.map((source, index) => (
                    <div 
                        key={index}
                        ref={el => sourceRefs.current[index] = el}
                        style={{ 
                            marginBottom: '15px', 
                            padding: '10px', 
                            borderLeft: activeSourceIndex === index ? '4px solid #2196f3' : '4px solid #ccc',
                            backgroundColor: activeSourceIndex === index ? '#f5f9ff' : '#f9f9f9',
                            transition: 'all 0.3s'
                        }}
                    >
                        <div style={{ fontSize: '0.85rem', color: '#666', marginBottom: '5px' }}>
                            Fonte: {source.metadata.source} (Score: {source.score.toFixed(2)})
                        </div>
                        <div style={{ fontSize: '0.95rem' }}>
                            {source.content}
                        </div>
                    </div>
                ))}
                {sources.length === 0 && <p>Nenhuma fonte recuperada.</p>}
            </div>
        </div>
    );
};
